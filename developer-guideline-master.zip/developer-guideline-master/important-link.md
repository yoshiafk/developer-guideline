## Github
- [text](https://github.axa.com/aii)

## Jenkins
- [text](https://jenkins-jenkins-prod-axa-magi-id.shared-prod-lpl-int.grey.ap-southeast-3.aws.openpaas.axa-cloud.com/)

## SonarQube
- [text](https://sonar-sonarqube-developer-prod-axa-magi-id.shared-prod-lpl-int.grey.ap-southeast-3.aws.openpaas.axa-cloud.com/)

## OpenShift Console
- [text](https://osconsole.grey.ap-southeast-3.aws.openpaas.axa-cloud.com/)

## Jfrog Artifactory
- [text](https://artifactory.asia.axa-cloud.com/)

## AWS Console
- [text](https://awslogin.axa-cloud.com/)

## OpenPaaS Portal
- [text](https://portal.axa-cloud.com/)

## OpenPaaS Confluence
- [text](https://confluence.axa.com/confluence/spaces/OPENPAAS/pages/10551499/OpenPaaS)

## Jira ASIAREQ
- [text](https://jira.axa.com/jira/browse/ASIAREQ)