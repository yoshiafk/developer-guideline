import React, { useRef } from 'react';
import {
  Row,
  Col,
  Card,
  Typography,
  Button,
  Space,
  Tag,
  Table
} from 'antd';
import { motion } from 'framer-motion';
import {
  BookOutlined,
  ExperimentOutlined,
  CheckCircleOutlined,
  GlobalOutlined,
  HeartOutlined,
  LinkOutlined,
  ApartmentOutlined,
  CloseOutlined,
  CodeOutlined
} from '@ant-design/icons';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import PageHero from '../components/PageHero';
import TableOfContents from '../components/TableOfContents';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import StaggerContainer from '../components/StaggerContainer';
import HoverCard from '../components/HoverCard';
import CodeSnippet from '../components/CodeSnippet';
import FeatureCard from '../components/FeatureCard';

const { Title, Paragraph, Text } = Typography;

const CodingStandardPage: React.FC = () => {
  const contentRef = useRef<HTMLElement>(null);
  return (
    <Layout>
      <PageTransition>
        <PageHero
          title="Coding Standard Guide"
          subtitle="C# .NET Coding Standards for New Developers"
          breadcrumbs={[
            { label: 'Home', href: '/' },
            { label: 'Coding Standard Guide', href: '/coding-standard' }
          ]}
        />

        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '48px 16px 0 16px' }}>
          <Row gutter={[32, 32]}>
            {/* Main Content */}
            <Col xs={24} lg={18}>
              <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                {/* Introduction */}
                <section id="introduction" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    {/* Key Features Grid */}
                    <StaggerContainer>
                      <Row gutter={[24, 24]} style={{ marginBottom: '32px' }}>
                        <Col xs={24} md={8}>
                          <FeatureCard
                            icon={<CheckCircleOutlined />}
                            title="Enterprise Standards"
                            description="Comprehensive coding standards and best practices for enterprise-level .NET development with real-world examples."
                          />
                        </Col>

                        <Col xs={24} md={8}>
                          <FeatureCard
                            icon={<ExperimentOutlined />}
                            title="Real-World Examples"
                            description="Practical code examples taken directly from the AR Reconcile Service project codebase for immediate application."
                          />
                        </Col>

                        <Col xs={24} md={8}>
                          <FeatureCard
                            icon={<GlobalOutlined />}
                            title="Quality Assurance"
                            description="Rigorous testing strategies and validation patterns for reliable, maintainable, and scalable code."
                          />
                        </Col>
                      </Row>
                    </StaggerContainer>
                  </ScrollReveal>
                </section>

          {/* Project Overview */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Project Overview</Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                The AR Reconcile Service is a .NET 8.0 web API built using Clean Architecture principles with the following layers:
              </Paragraph>

              <StaggerContainer>
                <Row gutter={[24, 24]} style={{ marginBottom: '32px' }}>
                  <Col xs={24} md={8}>
                    <HoverCard>
                      <div style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #0033A0',
                        padding: '32px'
                      }}>
                        <div style={{
                          width: '64px',
                          height: '64px',
                          borderRadius: '50%',
                          backgroundColor: '#0033A0',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          margin: '0 auto 24px auto'
                        }}>
                          <CodeOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                        </div>
                        <Title level={4} style={{ marginBottom: '16px' }}>API Layer</Title>
                        <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                          Controllers, endpoints, middleware, and API presentation logic.
                        </Paragraph>
                      </div>
                    </HoverCard>
                  </Col>

                  <Col xs={24} md={8}>
                    <HoverCard>
                      <div style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00A3E0',
                        padding: '32px'
                      }}>
                        <div style={{
                          width: '64px',
                          height: '64px',
                          borderRadius: '50%',
                          backgroundColor: '#00A3E0',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          margin: '0 auto 24px auto'
                        }}>
                          <ExperimentOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                        </div>
                        <Title level={4} style={{ marginBottom: '16px' }}>Application Layer</Title>
                        <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                          Business logic, use cases, DTOs, and application services.
                        </Paragraph>
                      </div>
                    </HoverCard>
                  </Col>

                  <Col xs={24} md={8}>
                    <HoverCard>
                      <div style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00B894',
                        padding: '32px'
                      }}>
                        <div style={{
                          width: '64px',
                          height: '64px',
                          borderRadius: '50%',
                          backgroundColor: '#00B894',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          margin: '0 auto 24px auto'
                        }}>
                          <CheckCircleOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                        </div>
                        <Title level={4} style={{ marginBottom: '16px' }}>Domain Layer</Title>
                        <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                          Core entities, business rules, and domain services.
                        </Paragraph>
                      </div>
                    </HoverCard>
                  </Col>
                </Row>
              </StaggerContainer>

              <Card style={{ backgroundColor: '#f9fafb', marginBottom: '24px' }}>
                <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>Key Technologies</Title>
                <Row gutter={[16, 8]}>
                  <Col xs={24} md={12}>
                    <ul style={{ color: '#374151', paddingLeft: '20px', margin: 0 }}>
                      <li>• .NET 8.0 with ASP.NET Core</li>
                      <li>• Entity Framework Core with PostgreSQL</li>
                      <li>• MediatR for application messaging</li>
                      <li>• FluentValidation for input validation</li>
                    </ul>
                  </Col>
                  <Col xs={24} md={12}>
                    <ul style={{ color: '#374151', paddingLeft: '20px', margin: 0 }}>
                      <li>• Standard API controllers</li>
                      <li>• Mapster for object mapping</li>
                      <li>• Serilog for logging</li>
                    </ul>
                  </Col>
                </Row>
              </Card>
            </ScrollReveal>
          </section>

          {/* Architecture Design Choices */}
          <section id="architecture" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Architecture Design Choices</Title>

              <Space direction="vertical" size="large" style={{ width: '100%' }}>
                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>1. Clean Architecture vs Vertical Slice Architecture</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Choosing between Clean Architecture and Vertical Slice Architecture depends on your project's complexity and requirements.
                  </Paragraph>
                  
                  <Row gutter={[24, 24]} style={{ marginBottom: '24px' }}>
                    <Col xs={24}>
                      <Card style={{ borderLeft: '4px solid #16a34a' }}>
                        <Title level={4} style={{ color: '#16a34a', marginBottom: '16px' }}>✅ Clean Architecture (Layered Approach)</Title>
                        <Paragraph style={{ color: '#374151', marginBottom: '16px' }}>
                          Use Clean Architecture for complex domains with rich business logic
                        </Paragraph>
                        <div style={{ marginTop: '16px' }}>
                          <Text strong>Use Clean Architecture when:</Text>
                          <ul style={{ marginTop: '8px' }}>
                            <li>Rich domain logic with complex business rules</li>
                            <li>Multiple applications sharing the same domain</li>
                            <li>Long-term project with evolving business requirements</li>
                            <li>Team prefers strong separation of concerns</li>
                            <li>Need for extensive unit testing of business logic</li>
                          </ul>
                        </div>
                      </Card>
                    </Col>

                    <Col xs={24}>
                      <HoverCard>
                        <Card className="success-card">
                        <Title level={4} style={{ marginBottom: '16px' }}>✅ Vertical Slice Architecture (Feature-Based)</Title>
                        <Paragraph style={{ color: '#374151', marginBottom: '16px' }}>
                          Use Vertical Slice for CRUD-heavy applications or when features are independent
                        </Paragraph>
                        <div style={{ marginTop: '16px' }}>
                          <Text strong>Use Vertical Slice when:</Text>
                          <ul style={{ marginTop: '8px' }}>
                            <li>CRUD-heavy applications</li>
                            <li>Features are largely independent</li>
                            <li>Rapid development is prioritized</li>
                            <li>Smaller team or project</li>
                            <li>Business logic is primarily data manipulation</li>
                          </ul>
                        </div>
                      </Card>
                      </HoverCard>
                    </Col>

                    <Col xs={24}>
                      <HoverCard>
                        <Card className="error-card">
                        <Title level={4} style={{ marginBottom: '16px' }}>❌ DON'T: Mix Architectural Approaches</Title>
                        <Paragraph style={{ color: '#374151' }}>
                          Mixing Clean Architecture with Vertical Slice creates confusion about where to put business logic.
                        </Paragraph>
                      </Card>
                      </HoverCard>
                    </Col>
                  </Row>
                </div>
              </Space>
            </ScrollReveal>
          </section>

          {/* Design Patterns */}
          <section id="design-patterns" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Design Patterns</Title>

              <Space direction="vertical" size="large" style={{ width: '100%' }}>
                <div style={{ borderLeft: '4px solid #8b5cf6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>CQRS with MediatR vs Direct Service Pattern</Title>
                  
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <HoverCard>
                        <Card className="minimal-card" style={{ height: '100%' }}>
                        <Title level={4} style={{ marginBottom: '16px' }}>✅ CQRS with MediatR</Title>
                        <Paragraph style={{ color: '#374151', marginBottom: '16px' }}>
                          Use CQRS with MediatR for complex applications with different read/write requirements
                        </Paragraph>
                        <div style={{ marginBottom: '16px' }}>
                          <Text strong>Use when:</Text>
                          <ul style={{ marginTop: '8px' }}>
                            <li>Complex business workflows</li>
                            <li>Different models for reads and writes</li>
                            <li>Cross-cutting concerns (logging, validation, caching) via pipeline behaviors</li>
                            <li>Event-driven architecture</li>
                            <li>Team prefers request/response messaging patterns</li>
                          </ul>
                        </div>
                      </Card>
                      </HoverCard>
                    </Col>

                    <Col xs={24} md={12}>
                      <HoverCard>
                        <Card className="minimal-card" style={{ height: '100%' }}>
                        <Title level={4} style={{ marginBottom: '16px' }}>✅ Direct Service Pattern</Title>
                        <Paragraph style={{ color: '#374151', marginBottom: '16px' }}>
                          Use Direct Services for simpler applications or when MediatR overhead isn't justified
                        </Paragraph>
                        <div style={{ marginBottom: '16px' }}>
                          <Text strong>Use when:</Text>
                          <ul style={{ marginTop: '8px' }}>
                            <li>Simple CRUD operations</li>
                            <li>Single models for reads and writes</li>
                            <li>Smaller applications</li>
                            <li>Team prefers traditional service layers</li>
                            <li>Performance is critical (less abstraction overhead)</li>
                          </ul>
                        </div>
                      </Card>
                      </HoverCard>
                    </Col>
                  </Row>
                </div>
              </Space>
            </ScrollReveal>
          </section>

          {/* Data Access Patterns */}
          <section id="data-access" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Data Access Patterns</Title>

              <Space direction="vertical" size="large" style={{ width: '100%' }}>
                <div style={{ borderLeft: '4px solid #f59e0b', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Repository Pattern vs Direct DbContext</Title>
                  
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card style={{ height: '100%' }}>
                        <Title level={4} style={{ color: '#16a34a', marginBottom: '16px' }}>✅ Repository Pattern</Title>
                        <Paragraph style={{ marginBottom: '12px' }}>Use when you need abstraction over data access</Paragraph>
                        <ul>
                          <li>Need to abstract data access for testing</li>
                          <li>Complex domain logic that requires repository methods</li>
                          <li>Multiple data sources</li>
                          <li>Clean Architecture with domain-driven design</li>
                        </ul>
                      </Card>
                    </Col>

                    <Col xs={24} md={12}>
                      <Card style={{ height: '100%' }}>
                        <Title level={4} style={{ color: '#16a34a', marginBottom: '16px' }}>✅ Generic Repository Pattern</Title>
                        <Paragraph style={{ marginBottom: '12px' }}>Use when you have many entities with similar CRUD operations</Paragraph>
                        <ul>
                          <li>Reduce code duplication across repositories</li>
                          <li>Consistent data access patterns</li>
                          <li>Working with Unit of Work pattern for transactions</li>
                          <li>Many simple entities with standard operations</li>
                        </ul>
                      </Card>
                    </Col>

                    <Col xs={24} md={12}>
                      <Card style={{ height: '100%' }}>
                        <Title level={4} style={{ color: '#16a34a', marginBottom: '16px' }}>✅ Direct DbContext</Title>
                        <Paragraph style={{ marginBottom: '12px' }}>Use for simpler applications</Paragraph>
                        <ul>
                          <li>Simple CRUD operations</li>
                          <li>Vertical Slice Architecture</li>
                          <li>Performance is important (less abstraction)</li>
                          <li>Small to medium applications</li>
                          <li>Working with complex queries that don't fit repository patterns</li>
                        </ul>
                      </Card>
                    </Col>

                    <Col xs={24} md={12}>
                      <Card style={{ height: '100%' }}>
                        <Title level={4} style={{ color: '#2563eb', marginBottom: '16px' }}>Entity Framework Core vs Dapper</Title>
                        <Paragraph style={{ marginBottom: '12px' }}><strong>EF Core:</strong></Paragraph>
                        <ul style={{ marginBottom: '12px' }}>
                          <li>Complex object relationships</li>
                          <li>Need change tracking</li>
                          <li>Rich domain models</li>
                          <li>CRUD-heavy applications</li>
                        </ul>
                        <Paragraph style={{ marginBottom: '12px' }}><strong>Dapper:</strong></Paragraph>
                        <ul>
                          <li>Performance-critical scenarios</li>
                          <li>Stored procedures and database functions</li>
                          <li>Bulk operations and data processing</li>
                          <li>Read-heavy scenarios</li>
                        </ul>
                      </Card>
                    </Col>
                  </Row>

                  <Card style={{ marginTop: '24px', backgroundColor: '#fef3c7', borderLeft: '4px solid #f59e0b' }}>
                    <Title level={4} style={{ color: '#92400e', marginBottom: '16px' }}>⚠️ Best Practice: Database Operations</Title>
                    <Paragraph>Prefer stored procedures and database functions over inline SQL:</Paragraph>
                    <ul>
                      <li><strong>Stored Procedures:</strong> For complex business operations, data modifications, and multi-step processes</li>
                      <li><strong>Database Functions:</strong> For calculations, data transformations, and reusable business logic</li>
                      <li><strong>Views:</strong> For complex data retrieval and reporting</li>
                      <li><strong>Simple Parameterized Queries:</strong> Only for very basic operations where stored procedures would be overkill</li>
                    </ul>
                  </Card>
                </div>
              </Space>
            </ScrollReveal>
          </section>

          {/* API Implementation */}
          <section id="api-implementation" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>API Implementation Approaches</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card className="minimal-card" style={{ height: '100%' }}>
                    <Title level={4} style={{ marginBottom: '16px' }}>✅ Standard Controllers</Title>
                    <Paragraph>Use for complex APIs with many endpoints</Paragraph>
                    <ul>
                      <li>Complex APIs with many endpoints</li>
                      <li>Need extensive use of filters and middleware</li>
                      <li>Team is familiar with traditional MVC patterns</li>
                      <li>Rich model binding and validation requirements</li>
                      <li>Extensive use of attributes for configuration</li>
                    </ul>
                  </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card className="minimal-card" style={{ height: '100%' }}>
                    <Title level={4} style={{ marginBottom: '16px' }}>✅ Minimal APIs</Title>
                    <Paragraph>Use for simple APIs or microservices</Paragraph>
                    <ul>
                      <li>Simple APIs or microservices</li>
                      <li>Performance is critical (less overhead)</li>
                      <li>Modern, functional programming style preferred</li>
                      <li>Quick prototyping</li>
                      <li>Cloud-native applications</li>
                    </ul>
                  </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card className="error-card">
                    <Title level={4} style={{ marginBottom: '16px' }}>❌ DON'T: Mix Approaches Inconsistently</Title>
                    <Paragraph>Don't have some student endpoints as controllers and others as minimal APIs in the same feature area. Choose one approach and use it consistently.</Paragraph>
                  </Card>
                  </HoverCard>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Naming Conventions */}
          <section id="naming" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Naming Conventions</Title>

              <div style={{ marginBottom: '24px', overflowX: 'auto' }}>
                <Table
                  columns={[
                    {
                      title: 'Element',
                      dataIndex: 'element',
                      key: 'element',
                      width: 150
                    },
                    {
                      title: 'Convention',
                      dataIndex: 'convention',
                      key: 'convention',
                      width: 200
                    },
                    {
                      title: 'Example',
                      dataIndex: 'example',
                      key: 'example'
                    }
                  ]}
                  dataSource={[
                    {
                      key: '1',
                      element: 'Classes',
                      convention: 'PascalCase',
                      example: <code>Student</code>
                    },
                    {
                      key: '2',
                      element: 'Interfaces',
                      convention: 'PascalCase with \'I\' prefix',
                      example: <code>ISchoolDbContext</code>
                    },
                    {
                      key: '3',
                      element: 'Methods',
                      convention: 'PascalCase',
                      example: <code>SaveChangesAsync</code>
                    },
                    {
                      key: '4',
                      element: 'Properties',
                      convention: 'PascalCase',
                      example: <code>FirstName</code>
                    },
                    {
                      key: '5',
                      element: 'Fields (private)',
                      convention: 'camelCase with underscore',
                      example: <code>_dbContext</code>
                    },
                    {
                      key: '6',
                      element: 'Constants',
                      convention: 'PascalCase',
                      example: <code>MaxRetryAttempts</code>
                    },
                    {
                      key: '7',
                      element: 'Parameters',
                      convention: 'camelCase',
                      example: <code>request</code>
                    }
                  ]}
                  pagination={false}
                  size="small"
                  bordered
                />
              </div>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Descriptive Names</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good: Clear and descriptive
public async Task<GetStudentListResult> Handle(
    GetStudentListQuery request,
    CancellationToken cancellationToken)

public async Task<Employee> GetEmployeeWithDepartmentAsync(int employeeId)
public async Task UpdateEmployeeSalaryAsync(int employeeId, decimal newSalary)`}
                      language="csharp"
                      title="Descriptive Method Names"
                      showLineNumbers={true}
                      showCopyButton={true}
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ DON'T: Abbreviated Names</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Bad: Abbreviated and unclear
public async Task<GetListRes> Handle(GetListReq req, CancellationToken ct)

public async Task<List<Emp>> GetEmpsAsync()
public async Task UpdEmpAsync(int id, decimal sal)

// Bad: Generic names
public async Task ProcessData(object data)
public void DoStuff(int id)
public string GetValue() // What value?`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Async Method Suffix</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// ✅ CORRECT: Async suffix
public async Task<List<Car>> GetCarsAsync()
public async Task SaveChangesAsync(CancellationToken cancellationToken)
public async Task<bool> ValidateStudentAsync(Student student)`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ DON'T: Missing/Inconsistent Async</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// ❌ WRONG: Missing async suffix
public async Task<List<Car>> GetCars() // Should be GetCarsAsync

// ❌ WRONG: Async suffix on non-async method
public List<Car> GetCarsAsync() // No async, shouldn't have Async suffix

// ❌ WRONG: Inconsistent naming
public async Task SaveData() // Should be SaveDataAsync
public async Task UpdateAsync() // Too generic, should be UpdateWhatAsync`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* File and Project Organization */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>File and Project Organization</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Feature-Based Organization</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good - organized by feature
Controllers/Students/GetStudentListController.cs
Services/Students/GetStudentListService.cs

// Good - match file names with class names
GetStudentList.cs              # Contains GetStudentList class
Student.cs                     # Contains Student entity
CreateEmployeeHandler.cs       # Contains CreateEmployeeHandler class`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ DON'T: Type-Based Organization</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Bad - organized by type
Controllers/StudentController.cs
Handlers/GetStudentListHandler.cs

// Bad - unclear purpose
public class DataService
public class ProcessService
public class StudentService // Does what exactly?
public class CarProcessor // Process how?`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Card style={{ backgroundColor: '#f9fafb', marginTop: '24px' }}>
                <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Project Structure</Title>

                {/* Modern File Tree Visualization */}
                <div style={{
                  backgroundColor: '#ffffff',
                  borderRadius: '12px',
                  border: '2px solid #e5e7eb',
                  padding: '24px',
                  fontFamily: 'JetBrains Mono, Consolas, Monaco, "Courier New", monospace',
                  fontSize: '14px',
                  lineHeight: '1.6',
                  overflow: 'auto'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                    <div style={{
                      width: '16px',
                      height: '16px',
                      borderRadius: '2px',
                      backgroundColor: '#0033A0',
                      marginRight: '8px'
                    }}></div>
                    <span style={{ fontWeight: 'bold', color: '#111827' }}>src/</span>
                    <span style={{ color: '#6b7280', marginLeft: '8px' }}>Project root directory</span>
                  </div>

                  {/* School API Layer */}
                  <div style={{ marginLeft: '24px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '2px',
                        backgroundColor: '#0033A0',
                        marginRight: '8px'
                      }}></div>
                      <span style={{ fontWeight: 'bold', color: '#0033A0' }}>school.api/</span>
                      <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Presentation layer</span>
                    </div>

                    {/* Controllers */}
                    <div style={{ marginLeft: '32px', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '6px' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#2563eb',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#2563eb' }}>Controllers/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>API controllers by feature</span>
                      </div>

                      <div style={{ marginLeft: '40px', marginBottom: '4px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#059669', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#059669' }}>Students/</span>
                        </div>
                      </div>
                      <div style={{ marginLeft: '40px', marginBottom: '4px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#059669', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#059669' }}>Courses/</span>
                        </div>
                      </div>
                      <div style={{ marginLeft: '40px', marginBottom: '4px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#059669', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#059669' }}>Enrollments/</span>
                        </div>
                      </div>
                    </div>

                    {/* Middlewares */}
                    <div style={{ marginLeft: '32px', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#7c3aed',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#7c3aed' }}>Middlewares/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Custom middleware</span>
                      </div>
                    </div>

                    {/* Extensions */}
                    <div style={{ marginLeft: '32px' }}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#7c3aed',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#7c3aed' }}>Extensions/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Extension methods</span>
                      </div>
                    </div>
                  </div>

                  {/* Application Layer */}
                  <div style={{ marginLeft: '24px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '2px',
                        backgroundColor: '#00A3E0',
                        marginRight: '8px'
                      }}></div>
                      <span style={{ fontWeight: 'bold', color: '#00A3E0' }}>arreconcile.application/</span>
                      <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Application layer</span>
                    </div>

                    <div style={{ marginLeft: '32px', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '6px' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#0891b2',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#0891b2' }}>Services/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Application services (use cases)</span>
                      </div>
                    </div>

                    <div style={{ marginLeft: '32px', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '6px' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#0891b2',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#0891b2' }}>Entities/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>DTOs and requests</span>
                      </div>

                      <div style={{ marginLeft: '40px', marginBottom: '4px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#dc2626', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#dc2626' }}>Dtos/</span>
                        </div>
                      </div>
                      <div style={{ marginLeft: '40px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#dc2626', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#dc2626' }}>Requests/</span>
                        </div>
                      </div>
                    </div>

                    <div style={{ marginLeft: '32px' }}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#0891b2',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#0891b2' }}>Abstractions/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Interfaces</span>
                      </div>
                    </div>
                  </div>

                  {/* Domain Layer */}
                  <div style={{ marginLeft: '24px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '2px',
                        backgroundColor: '#00B894',
                        marginRight: '8px'
                      }}></div>
                      <span style={{ fontWeight: 'bold', color: '#00B894' }}>arreconcile.domain/</span>
                      <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Domain layer</span>
                    </div>

                    <div style={{ marginLeft: '32px' }}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#059669',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#059669' }}>Models/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Domain entities</span>
                      </div>
                    </div>
                  </div>

                  {/* Infrastructure Layer */}
                  <div style={{ marginLeft: '24px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '2px',
                        backgroundColor: '#FF6B35',
                        marginRight: '8px'
                      }}></div>
                      <span style={{ fontWeight: 'bold', color: '#FF6B35' }}>arreconcile.infrastructure/</span>
                      <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Infrastructure layer</span>
                    </div>

                    <div style={{ marginLeft: '32px', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '6px' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#ea580c',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#ea580c' }}>Data/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>DbContext and configurations</span>
                      </div>

                      <div style={{ marginLeft: '40px' }}>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                          <span style={{ color: '#dc2626', marginRight: '4px' }}>📁</span>
                          <span style={{ color: '#dc2626' }}>Configurations/</span>
                          <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Entity configurations</span>
                        </div>
                      </div>
                    </div>

                    <div style={{ marginLeft: '32px' }}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '2px',
                          backgroundColor: '#ea580c',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontWeight: '600', color: '#ea580c' }}>Migrations/</span>
                        <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>EF migrations</span>
                      </div>
                    </div>
                  </div>

                  {/* Test Project */}
                  <div style={{ marginLeft: '24px' }}>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '2px',
                        backgroundColor: '#8B5CF6',
                        marginRight: '8px'
                      }}></div>
                      <span style={{ fontWeight: 'bold', color: '#8B5CF6' }}>arreconcile.unittests/</span>
                      <span style={{ color: '#6b7280', marginLeft: '8px', fontSize: '12px' }}>Test project</span>
                    </div>
                  </div>
                </div>

                {/* Legend */}
                <div style={{
                  marginTop: '16px',
                  padding: '16px',
                  backgroundColor: '#f8fafc',
                  borderRadius: '8px',
                  border: '1px solid #e2e8f0'
                }}>
                  <Title level={4} style={{ marginBottom: '12px', color: '#374151' }}>Legend</Title>
                  <Row gutter={[16, 8]}>
                    <Col xs={12} sm={6}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '12px',
                          height: '12px',
                          borderRadius: '2px',
                          backgroundColor: '#0033A0',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontSize: '12px', color: '#374151' }}>Presentation</span>
                      </div>
                    </Col>
                    <Col xs={12} sm={6}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '12px',
                          height: '12px',
                          borderRadius: '2px',
                          backgroundColor: '#00A3E0',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontSize: '12px', color: '#374151' }}>Application</span>
                      </div>
                    </Col>
                    <Col xs={12} sm={6}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '12px',
                          height: '12px',
                          borderRadius: '2px',
                          backgroundColor: '#00B894',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontSize: '12px', color: '#374151' }}>Domain</span>
                      </div>
                    </Col>
                    <Col xs={12} sm={6}>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{
                          width: '12px',
                          height: '12px',
                          borderRadius: '2px',
                          backgroundColor: '#FF6B35',
                          marginRight: '8px'
                        }}></div>
                        <span style={{ fontSize: '12px', color: '#374151' }}>Infrastructure</span>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Card>
            </ScrollReveal>
          </section>

          {/* Code Structure and Formatting */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Code Structure and Formatting</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Indentation & Spacing</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class Employee
{
    public int Id { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }

    public static Employee Create(int id, string? firstName, string? lastName)
    {
        return new Employee
        {
            Id = id,
            FirstName = firstName,
            LastName = lastName
        };
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Allman Brace Style</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Correct
if (condition)
{
    DoSomething();
}

// Wrong
if (condition) {
    DoSomething();
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Language-Specific Guidelines */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Language-Specific Guidelines</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: String Interpolation</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good
var message = $"Currency {currency.CurrencyCode} not found";

// Bad
var message = "Currency " + currency.CurrencyCode + " not found";`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Null Handling</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good: Nullable reference types
public class MstCurrency
{
    public string? CurrencyCode { get; set; }
    public string Description { get; set; } = string.Empty;
}

// Good: Null-conditional operators
var length = currency?.CurrencyCode?.Length ?? 0;`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Collection Expressions (C# 12)</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Preferred
List<string> currencies = ["USD", "EUR", "GBP"];

// Traditional (still acceptable)
var currencies = new List<string> { "USD", "EUR", "GBP" };`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Pattern Matching</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good - using pattern matching
public string GetStatusMessage(string status) => status switch
{
    "Pending" => "Request is pending approval",
    "Approved" => "Request has been approved",
    "Rejected" => "Request was rejected",
    _ => "Unknown status"
};`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Raw String Literals</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`var sql = """
    SELECT c.Id, c.CurrencyCode
    FROM MstCurrencies c
    WHERE c.IsActive = true
    ORDER BY c.CurrencyCode
    """;`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Primary Constructors</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Primary constructor (C# 12)
public class GetStudentListHandler(ISchoolDbContext dbContext)
    : IQueryHandler<GetStudentListQuery, GetStudentListResult>
{
    public async Task<GetListMstCurrencyResult> Handle(
        GetStudentListQuery request,
        CancellationToken cancellationToken)
    {
        return await dbContext.Students.ToListAsync(cancellationToken);
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Validation and Error Handling */}
          <section id="validation" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Validation and Error Handling</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: FluentValidation</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class CreateEmployeeCommandValidator : AbstractValidator<CreateEmployeeCommand>
{
    public CreateEmployeeCommandValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .WithMessage("Employee name is required")
            .MaximumLength(100)
            .WithMessage("Name cannot exceed 100 characters");

        RuleFor(x => x.Email)
            .NotEmpty()
            .WithMessage("Email address is required")
            .EmailAddress()
            .WithMessage("Please provide a valid email address");
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ WRONG: No Validation</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class CreateEmployeeHandler
{
    public async Task<CreateEmployeeResult> Handle(CreateEmployeeCommand request)
    {
        // No validation - accepting any input!
        var employee = new Employee
        {
            Name = request.Name,     // Could be null or empty
            Email = request.Email,   // Could be invalid format
            Age = request.Age        // Could be negative
        };
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Meaningful Error Messages</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`RuleFor(x => x.StudentId)
    .GreaterThan(0)
    .WithMessage("Student ID must be greater than 0");

RuleFor(x => x.Email)
    .NotEmpty()
    .WithMessage("Email address is required")
    .EmailAddress()
    .WithMessage("Please provide a valid email address format");

RuleFor(x => x.VehicleNumber)
    .NotEmpty()
    .WithMessage("Vehicle number is required")
    .Matches(@"^[A-Z]{2}\\d{2}[A-Z]{2}\\d{4}$")
    .WithMessage("Vehicle number must be in format: 2 letters, 2 digits, 2 letters, 4 digits (e.g., AB12CD3456)");`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ DON'T: Generic/Confusing Messages</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// ❌ BAD: Generic and unhelpful messages
RuleFor(x => x.StudentId)
    .GreaterThan(0)
    .WithMessage("Invalid ID"); // Not specific enough

RuleFor(x => x.Email)
    .EmailAddress()
    .WithMessage("Bad email"); // Too terse

RuleFor(x => x.VehicleNumber)
    .Matches(@"^[A-Z]{2}\\d{2}[A-Z]{2}\\d{4}$")
    .WithMessage("Invalid format"); // User doesn't know what format is expected

// ❌ WRONG: Technical messages for business users
RuleFor(x => x.Salary)
    .Must(x => x != null && x.Value > 0)
    .WithMessage("Property Salary failed validation rule Must(x => x != null && x.Value > 0)");`}
                      language="csharp"
                      title="Poor Error Messages"
                      showLineNumbers={true}
                      showWordWrapToggle={true}
                      showCopyButton={true}
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Dependency Injection and Services */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Dependency Injection and Services</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Appropriate Service Lifetimes</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Singleton - expensive to create, stateless
services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

// Scoped - per request lifetime
services.AddScoped<ISchoolDbContext, SchoolDbContext>();

// Transient - lightweight, stateless
services.AddTransient<IValidator<GetStudentByIdQuery>, GetStudentByIdQueryValidator>();`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Extension Methods for Registration</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public static class DependencyInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddScoped<IStudentService, StudentService>();
        services.AddScoped<IStudentRepository, StudentRepository>();
        services.AddTransient<IValidator<CreateStudentCommand>, CreateStudentCommandValidator>();
        
        return services;
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Primary Constructors</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Primary constructor (C# 12)
public class GetStudentListHandler(ISchoolDbContext dbContext)
    : IQueryHandler<GetStudentListQuery, GetStudentListResult>
{
    public async Task<GetListMstCurrencyResult> Handle(
        GetStudentListQuery request,
        CancellationToken cancellationToken)
    {
        return await dbContext.Students.ToListAsync(cancellationToken);
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Traditional Constructor Injection</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class TraditionalHandler : IQueryHandler<SomeQuery, SomeResult>
{
    private readonly IArRecDbContext _dbContext;
    private readonly ILogger<TraditionalHandler> _logger;

    public TraditionalHandler(
        IArRecDbContext dbContext,
        ILogger<TraditionalHandler> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Database and Entity Framework */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Database and Entity Framework</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Entity Design</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class Currency : AuditedEntity
{
    public int Id { get; set; }
    public string? CurrencyCode { get; set; }
    public string? Description { get; set; }

    // Navigation properties
    public ICollection<Account>? Accounts { get; set; }
    public ICollection<Transaction>? Transactions { get; set; }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Fluent API Configuration</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public class MstCurrencyConfiguration : IEntityTypeConfiguration<MstCurrency>
{
    public void Configure(EntityTypeBuilder<MstCurrency> builder)
    {
        builder.ToTable("MstCurrencies");

        builder.HasKey(e => e.Id);

        builder.Property(e => e.CurrencyCode)
            .HasMaxLength(10)
            .IsRequired();

        builder.HasIndex(e => e.CurrencyCode)
            .IsUnique();
    }
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Testing Guidelines */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Testing Guidelines</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Test Structure</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`[Test]
public async Task Handle_WithValidRequest_ReturnsSuccess()
{
    // Arrange
    var request = new UpsertMstDetailReassuradurRequest
    {
        ReasId = 12345,
        COB = "COB123",
        EmailPic = "test@example.com",
        Department = "Finance"
    };

    // Act
    var result = await service.UpsertAsync(request, CancellationToken.None);

    // Assert
    Assert.That(result.Result.IsSuccess, Is.True);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Arrange-Act-Assert</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`[Test]
public async Task InsertNewRecord_ReturnsSuccess()
{
    // Arrange
    var mockDbContext = new Mock<IArRecDbContext>();
    var request = new UpsertMstDetailReassuradurRequest { ... };

    // Act
    var result = await service.UpsertAsync(request, CancellationToken.None);

    // Assert
    Assert.That(result.Result.IsSuccess, Is.True);
    mockDbContext.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Performance and Best Practices */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Performance and Best Practices</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ CORRECT: Async/Await</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public async Task<GetListMstCurrencyResult> GetListAsync(
    GetListMstCurrencyRequest request,
    CancellationToken cancellationToken)
{
    var result = await dbContext.MstCurrencies
        .Where(x => x.IsActive)
        .ToListAsync(cancellationToken);

    return new GetListMstCurrencyResult(result);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#dc2626', marginBottom: '24px' }}>❌ WRONG: Blocking Async</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public GetListMstCurrencyResult Handle(GetListMstCurrencyQuery request)
{
    var result = dbContext.MstCurrencies
        .Where(x => x.IsActive)
        .ToListAsync()
        .Result; // DEADLOCK RISK!

    return new GetListMstCurrencyResult(result);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Use Cancellation Tokens</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public async Task<List<MstCurrency>> GetCurrenciesAsync(
    CancellationToken cancellationToken)
{
    return await dbContext.MstCurrencies
        .Where(x => x.IsActive)
        .ToListAsync(cancellationToken);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Proper Resource Disposal</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Using statement for automatic disposal
using var scope = serviceScopeFactory.CreateScope();
var context = scope.ServiceProvider.GetRequiredService<ArRecDbContext>();

// Or in async context
await using var context = scope.ServiceProvider.GetRequiredService<ArRecDbContext>();`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>

              <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Projection to DTOs</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Good - select only needed data
.Select(x => new MstCurrencyDto
{
    Id = x.Id,
    CurrencyCode = x.CurrencyCode
})

// Bad - loading full entity
.Select(x => x) // Loads all properties`}
                      language="csharp"
                    />
                  </Card>
                </Col>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Appropriate Collection Types</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Use List<T> for known size collections
var currencies = new List<MstCurrency>(capacity: expectedCount);

// Use IEnumerable<T> for streaming data
public IEnumerable<MstCurrency> GetCurrenciesLazy()
{
    return dbContext.MstCurrencies.Where(x => x.IsActive);
}`}
                      language="csharp"
                    />
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Documentation and Comments */}
          <section id="documentation" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Documentation and Comments</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: XML Documentation for Public APIs</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`/// <summary>
/// Represents a master currency entity with basic currency information.
/// </summary>
/// <remarks>
/// This entity stores currency codes and descriptions used throughout the system.
/// It inherits audit fields from AuditedEntity for tracking changes.
/// </remarks>
public class MstCurrency : AuditedEntity
{
    /// <summary>
    /// Gets or sets the unique identifier for the currency.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Gets or sets the ISO currency code (e.g., USD, EUR, GBP).
    /// </summary>
    /// <value>
    /// A 3-character ISO currency code, or null if not specified.
    /// </value>
    public string? CurrencyCode { get; set; }
}`}
                      language="csharp"
                      showLineNumbers={true}
                      showCopyButton={true}
                    />
                  </Card>
                </Col>

                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Explain Complex Business Logic</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`// Disable CA1862 warning for Entity Framework Core compatibility
// EF Core cannot translate StringComparison to SQL, so we use ToLower() instead
#pragma warning disable CA1862
queryFilter = queryFilter.And(x => x.CurrencyCode.ToLower().Contains(keywordLower));
#pragma warning restore CA1862`}
                      language="csharp"
                      showLineNumbers={true}
                      showCopyButton={true}
                    />
                  </Card>
                </Col>

                <Col xs={24}>
                  <Title level={3} style={{ color: '#16a34a', marginBottom: '24px' }}>✅ DO: Document Non-Obvious Code</Title>
                  <Card size="small">
                    <CodeSnippet
                      code={`public static WeatherData Create(WeatherData source)
{
    // Create a new instance to avoid reference issues
    // when the original entity is modified elsewhere
    var weatherToCreate = new WeatherData
    {
        Id = source.Id,
        Temperature = source.Temperature,
        City = source.City,
        Humidity = source.Humidity
    };
    
    return weatherToCreate;
}`}
                      language="csharp"
                      showLineNumbers={true}
                      showCopyButton={true}
                    />
                  </Card>
                </Col>

                <Col xs={24}>
                  <Card style={{ backgroundColor: '#fef3c7', borderLeft: '4px solid #f59e0b' }}>
                    <Title level={4} style={{ color: '#92400e', marginBottom: '16px' }}>Documentation Best Practices</Title>
                    <ul>
                      <li>Keep README.md updated with current setup instructions</li>
                      <li>Document API endpoints and their purposes</li>
                      <li>Explain architectural decisions</li>
                      <li>Provide examples for common scenarios</li>
                      <li>Document breaking changes</li>
                    </ul>
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Checklist */}
          <section style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>Checklist for New Developers</Title>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <HoverCard>
                    <Card className="info-card">
                      <Title level={3} style={{ marginBottom: '16px' }}>Architecture Decision Checklist</Title>
                      <Paragraph style={{ marginBottom: '12px' }}>Before starting a new project, decide on:</Paragraph>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Architecture Style: Clean Architecture (layered) vs Vertical Slice (feature-based)</li>
                        <li style={{ marginBottom: '8px' }}>✅ Design Pattern: CQRS with MediatR vs Direct Services</li>
                        <li style={{ marginBottom: '8px' }}>✅ Data Access: Repository Pattern vs Generic Repository vs Direct DbContext</li>
                        <li style={{ marginBottom: '8px' }}>✅ ORM Choice: Entity Framework Core vs Dapper (vs Mixed approach)</li>
                        <li>✅ API Style: Standard Controllers vs Minimal APIs</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card className="warning-card">
                      <Title level={3} style={{ marginBottom: '16px' }}>Before Writing Code</Title>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Understand the chosen architecture and patterns for this project</li>
                        <li style={{ marginBottom: '8px' }}>✅ Review existing similar implementations in the codebase</li>
                        <li style={{ marginBottom: '8px' }}>✅ Plan the structure based on the project's architectural decisions</li>
                        <li style={{ marginBottom: '8px' }}>✅ Identify validation requirements</li>
                        <li style={{ marginBottom: '8px' }}>✅ Consider database impact and performance requirements</li>
                        <li>✅ Check if business logic belongs in domain layer (Clean Arch) or handlers (Vertical Slice)</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card className="success-card">
                      <Title level={3} style={{ marginBottom: '16px' }}>During Development</Title>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Follow the established naming conventions</li>
                        <li style={{ marginBottom: '8px' }}>✅ Use the appropriate design patterns consistently</li>
                        <li style={{ marginBottom: '8px' }}>✅ Add proper validation (FluentValidation)</li>
                        <li style={{ marginBottom: '8px' }}>✅ Handle exceptions appropriately with specific exception types</li>
                        <li style={{ marginBottom: '8px' }}>✅ Use async/await consistently throughout the call stack</li>
                        <li style={{ marginBottom: '8px' }}>✅ Follow the data access pattern chosen for the project</li>
                        <li>✅ Add unit tests that match the architectural style</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card className="error-card" style={{ height: '100%' }}>
                      <Title level={4} style={{ marginBottom: '16px' }}>For Clean Architecture Projects</Title>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Keep domain logic in entities and domain services</li>
                        <li style={{ marginBottom: '8px' }}>✅ Use interfaces for all infrastructure dependencies</li>
                        <li style={{ marginBottom: '8px' }}>✅ Ensure application layer only depends on domain abstractions</li>
                        <li style={{ marginBottom: '8px' }}>✅ Place use cases/application services in Application layer</li>
                        <li>✅ Keep controllers thin - they should only orchestrate</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card className="minimal-card" style={{ height: '100%', borderColor: '#8b5cf6' }}>
                      <Title level={4} style={{ marginBottom: '16px' }}>For Vertical Slice Projects</Title>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Keep related features together in the same folder/namespace</li>
                        <li style={{ marginBottom: '8px' }}>✅ Use handlers that contain all logic for a specific feature</li>
                        <li style={{ marginBottom: '8px' }}>✅ Consider using MediatR for cross-cutting concerns</li>
                        <li style={{ marginBottom: '8px' }}>✅ Ensure features are as independent as possible</li>
                        <li>✅ Share common functionality through shared services</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card className="success-card">
                      <Title level={3} style={{ marginBottom: '16px' }}>Before Committing</Title>
                      <ul style={{ paddingLeft: '20px', margin: 0 }}>
                        <li style={{ marginBottom: '8px' }}>✅ Run all tests and ensure they pass</li>
                        <li style={{ marginBottom: '8px' }}>✅ Check code coverage meets project standards</li>
                        <li style={{ marginBottom: '8px' }}>✅ Verify formatting consistency with project standards</li>
                        <li style={{ marginBottom: '8px' }}>✅ Add/update documentation for any new patterns</li>
                        <li style={{ marginBottom: '8px' }}>✅ Review for performance implications</li>
                        <li style={{ marginBottom: '8px' }}>✅ Ensure proper error handling and logging</li>
                        <li>✅ Verify architectural consistency with rest of project</li>
                      </ul>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <Card className="minimal-card">
                    <Title level={3} style={{ marginBottom: '16px' }}>Key Takeaway</Title>
                    <Paragraph style={{ fontSize: '16px', color: '#374151', marginBottom: '12px' }}>
                      <strong>Consistency is key</strong> - choose the approach that fits your project's needs and apply it consistently throughout the codebase.
                    </Paragraph>
                    <Paragraph style={{ fontSize: '16px', color: '#374151' }}>
                      The patterns and practices in this guide evolve with the .NET ecosystem and project needs. When in doubt, refer to existing code in your project and follow established patterns consistently.
                    </Paragraph>
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          <div style={{ textAlign: 'center', padding: '32px 0' }}>
            <Text style={{ color: '#6b7280', fontSize: '16px' }}>
              This page contains the comprehensive Coding Standard Guide with detailed examples and best practices for .NET development.
            </Text>
          </div>
            </div>
          </Col>

          {/* Sidebar */}
          <Col xs={24} lg={6}>
            <div style={{ position: 'sticky', top: '96px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
              <TableOfContents contentRef={contentRef} />

              {/* Quick Links - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }} disableHover>
                <div>
                  <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>
                    <LinkOutlined style={{ marginRight: '8px' }} />
                    Quick Links
                  </Title>
                  <Space direction="vertical" style={{ width: '100%' }}>
                    <Link to="/dotnet-developer-guideline">
                      <Button type="text" icon={<BookOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        .NET Developer Guideline
                      </Button>
                    </Link>
                    <Link to="/clean-architecture">
                      <Button type="text" icon={<ApartmentOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        Clean Architecture Standards
                      </Button>
                    </Link>
                    <Button type="text" icon={<GlobalOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://docs.microsoft.com/en-us/dotnet/csharp/" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        C# Documentation
                      </a>
                    </Button>
                    <Button type="text" icon={<HeartOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://github.com/jasontaylordev/CleanArchitecture" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        Clean Architecture Template
                      </a>
                    </Button>
                  </Space>
                </div>
              </HoverCard>

              {/* Technology Stack - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }} disableHover>
                <div>
                  <Title level={4}>Technology Stack</Title>
                  <Space wrap style={{ marginTop: '12px' }}>
                    <Tag color="geekblue">.NET 8.0</Tag>
                    <Tag color="geekblue">C# 12</Tag>
                    <Tag color="geekblue">Entity Framework</Tag>
                    <Tag color="geekblue">FluentValidation</Tag>
                    <Tag color="geekblue">MediatR</Tag>
                    <Tag color="geekblue">Clean Architecture</Tag>
                    <Tag color="geekblue">DDD</Tag>
                    <Tag color="geekblue">PostgreSQL</Tag>
                  </Space>
                </div>
              </HoverCard>
            </div>
          </Col>
        </Row>
      </div>
      </PageTransition>
    </Layout>
  );
};

export default CodingStandardPage;