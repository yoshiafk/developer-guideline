import React, { useRef } from 'react';
import { Row, Col, Card, Typography, Button, Space, Tag, Divider, List, Timeline } from 'antd';
import { motion } from 'framer-motion';
import {
  BookOutlined,
  ArrowRightOutlined,
  CodeOutlined,
  SafetyOutlined,
  ExperimentOutlined,
  AppstoreOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  TeamOutlined,
  BulbOutlined,
  SearchOutlined,
  TrophyOutlined,
  UserOutlined,
  GlobalOutlined,
  HeartOutlined,
  LinkOutlined,
  FileTextOutlined,
  RocketOutlined,
  ApartmentOutlined,
  SyncOutlined,
  QuestionCircleOutlined,
  BranchesOutlined,
  HistoryOutlined,
  BarChartOutlined
} from '@ant-design/icons';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import PageHero from '../components/PageHero';
import TableOfContents from '../components/TableOfContents';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import StaggerContainer from '../components/StaggerContainer';
import HoverCard from '../components/HoverCard';
import FeatureCard from '../components/FeatureCard';
import DocumentCard from '../components/DocumentCard';

const { Title, Paragraph, Text } = Typography;
const { Meta } = Card;

const DotNetDeveloperGuidelinePage: React.FC = () => {
  const contentRef = useRef<HTMLDivElement>(null);
  const breadcrumbs = [
    { label: 'Home', href: '/' },
    { label: '.NET Developer Guideline' }
  ];

  return (
    <PageTransition>
      <Layout>
      <PageHero
        title=".NET Developer Guideline"
        subtitle="Your comprehensive guide to .NET development at AII using Clean Architecture principles, Domain-Driven Design patterns, and enterprise-grade coding standards."
        breadcrumbs={breadcrumbs}
      />

      {/* Main Content Area */}
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 16px 64px 16px' }}>
        <Row gutter={[32, 32]}>
          <Col xs={24} lg={18}>
            <div ref={contentRef} style={{ textAlign: 'center' }}>
              <section id="overview">
                <Title level={2}>Overview</Title>
                <Paragraph style={{ fontSize: '16px', lineHeight: '1.6' }}>
                  Welcome to the comprehensive .NET Developer Guidelines for AII. This central hub provides access to all coding standards, architectural patterns, and best practices for .NET development using Clean Architecture principles.
                </Paragraph>

                <Paragraph style={{ fontSize: '16px', lineHeight: '1.6' }}>
                  This documentation is designed to help new developers quickly understand and adopt AII's development standards. Each section includes practical examples, clear explanations, and actionable guidance.
                </Paragraph>

                <Row gutter={[24, 24]} style={{ marginTop: '32px' }}>
                  <Col xs={24} md={8}>
                    <FeatureCard
                      icon={<BookOutlined />}
                      title="Comprehensive Coverage"
                      description="Complete guide covering Clean Architecture, DDD patterns, coding standards, and enterprise best practices."
                    />
                  </Col>

                  <Col xs={24} md={8}>
                    <FeatureCard
                      icon={<ExperimentOutlined />}
                      title="Practical Examples"
                      description="Real-world code examples from actual projects with clear explanations and best practices."
                    />
                  </Col>

                  <Col xs={24} md={8}>
                    <FeatureCard
                      icon={<TeamOutlined />}
                      title="Team Collaboration"
                      description="Standardized practices that ensure consistency across all AII development teams and projects."
                    />
                  </Col>

                  <Col xs={24} md={8}>
                    <FeatureCard
                      icon={<TrophyOutlined />}
                      title="Proven Excellence"
                      description="Battle-tested patterns and practices that have been refined through years of enterprise development."
                    />
                  </Col>
                </Row>

                <Card className="minimal-card" style={{ marginTop: '32px' }}>
                  <Title level={3} style={{ marginBottom: '16px' }}>Why Follow These Guidelines?</Title>
                  <List
                    size="small"
                    dataSource={[
                      { icon: <CheckCircleOutlined />, text: 'Consistency: Standardized approach across all AII .NET projects' },
                      { icon: <CheckCircleOutlined />, text: 'Maintainability: Clean Architecture ensures long-term code health' },
                      { icon: <CheckCircleOutlined />, text: 'Scalability: DDD patterns support growing business needs' },
                      { icon: <CheckCircleOutlined />, text: 'Quality: Comprehensive testing and validation practices' },
                      { icon: <CheckCircleOutlined />, text: 'Efficiency: Proven patterns reduce development time' }
                    ]}
                    renderItem={(item) => (
                      <List.Item>
                        <Space>
                          <Text style={{ color: '#52c41a' }}>{item.icon}</Text>
                          <Text strong>{item.text.split(':')[0]}:</Text>
                          <Text>{item.text.split(':')[1]}</Text>
                        </Space>
                      </List.Item>
                    )}
                  />
                </Card>
              </section>

              <Divider />

              <section id="available-guidelines">
                <ScrollReveal>
                  <Title level={2}>
                    <BookOutlined style={{ marginRight: '8px' }} />
                    Available Guidelines
                  </Title>

                  <Paragraph style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '32px' }}>
                    Choose your learning path based on your experience level and current needs. Each guide builds upon the previous one for a comprehensive understanding.
                  </Paragraph>

                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <HoverCard>
                        <Card
                          style={{
                            height: '100%',
                            borderRadius: '12px',
                            border: '2px solid #0033A0',
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                            position: 'relative',
                            overflow: 'hidden'
                          }}
                          bodyStyle={{ padding: '32px' }}
                        >
                          {/* Priority Badge */}
                          <div style={{
                            position: 'absolute',
                            top: '16px',
                            right: '16px',
                            backgroundColor: '#0033A0',
                            color: '#ffffff',
                            padding: '4px 12px',
                            borderRadius: '12px',
                            fontSize: '12px',
                            fontWeight: 'bold'
                          }}>
                            START HERE
                          </div>

                          <Meta
                            avatar={
                              <div style={{
                                width: '48px',
                                height: '48px',
                                borderRadius: '50%',
                                backgroundColor: '#0033A0',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}>
                                <ApartmentOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                              </div>
                            }
                            title={
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <Text strong style={{ fontSize: '18px' }}>Clean Architecture Standards</Text>
                              </div>
                            }
                            description="Essential naming conventions, DDD patterns, Entity Framework best practices, and code formatting standards for building maintainable .NET applications."
                          />
                          <div style={{ marginTop: '20px' }}>
                            <Space wrap>
                              <Tag color="blue">SOLID Principles</Tag>
                              <Tag color="blue">Dependency Injection</Tag>
                              <Tag color="blue">Repository Pattern</Tag>
                              <Tag color="blue">Entity Framework</Tag>
                            </Space>
                          </div>
                          <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Text style={{ color: '#666', fontSize: '14px' }}>
                              <ClockCircleOutlined style={{ marginRight: '4px' }} />
                              45 min read
                            </Text>
                            <Link to="/clean-architecture">
                              <Button type="primary" icon={<ArrowRightOutlined />}>
                                Read Standards
                              </Button>
                            </Link>
                          </div>
                        </Card>
                      </HoverCard>
                    </Col>

                    <Col xs={24} md={12}>
                      <HoverCard>
                        <Card
                          style={{
                            height: '100%',
                            borderRadius: '12px',
                            border: '2px solid #00A3E0',
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                            position: 'relative',
                            overflow: 'hidden'
                          }}
                          bodyStyle={{ padding: '32px' }}
                        >
                          {/* Advanced Badge */}
                          <div style={{
                            position: 'absolute',
                            top: '16px',
                            right: '16px',
                            backgroundColor: '#00A3E0',
                            color: '#ffffff',
                            padding: '4px 12px',
                            borderRadius: '12px',
                            fontSize: '12px',
                            fontWeight: 'bold'
                          }}>
                            ADVANCED
                          </div>

                          <Meta
                            avatar={
                              <div style={{
                                width: '48px',
                                height: '48px',
                                borderRadius: '50%',
                                backgroundColor: '#00A3E0',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}>
                                <CodeOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                              </div>
                            }
                            title={
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <Text strong style={{ fontSize: '18px' }}>Coding Standard Guide</Text>
                              </div>
                            }
                            description="Detailed documentation with advanced patterns, performance guidelines, validation examples, and enterprise-level coding practices."
                          />
                          <div style={{ marginTop: '20px' }}>
                            <Space wrap>
                              <Tag color="green">Advanced DDD</Tag>
                              <Tag color="green">FluentValidation</Tag>
                              <Tag color="green">Async/Await</Tag>
                              <Tag color="green">Testing Strategies</Tag>
                            </Space>
                          </div>
                          <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Text style={{ color: '#666', fontSize: '14px' }}>
                              <ClockCircleOutlined style={{ marginRight: '4px' }} />
                              90 min read
                            </Text>
                            <Link to="/coding-standard">
                              <Button type="primary" icon={<CodeOutlined />}>
                                View Standards
                              </Button>
                            </Link>
                          </div>
                        </Card>
                      </HoverCard>
                    </Col>
                  </Row>

                  {/* Learning Path Indicator */}
                  <Card className="minimal-card" style={{ marginTop: '32px' }}>
                    <Title level={4} style={{ marginBottom: '16px' }}>
                      <BranchesOutlined style={{ marginRight: '8px' }} />
                      Recommended Learning Path
                    </Title>
                    <Timeline
                      mode="left"
                      items={[
                        {
                          label: 'Foundation',
                          children: 'Start with Clean Architecture Standards to understand the core principles and patterns.',
                          color: 'blue',
                          dot: <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#0033A0'
                          }} />
                        },
                        {
                          label: 'Implementation',
                          children: 'Apply the patterns in your projects while following the coding standards.',
                          color: 'blue',
                          dot: <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#00A3E0'
                          }} />
                        },
                        {
                          label: 'Mastery',
                          children: 'Dive deep into advanced patterns and enterprise-level practices.',
                          color: 'blue',
                          dot: <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#00B894'
                          }} />
                        }
                      ]}
                    />
                  </Card>
                </ScrollReveal>
              </section>

              <Divider />

              <section id="quick-start">
                <ScrollReveal>
                  <Title level={2}>
                    <RocketOutlined style={{ marginRight: '8px' }} />
                    Quick Start for New Developers
                  </Title>
                  <Paragraph style={{ fontSize: '16px', lineHeight: '1.6' }}>
                    Follow these steps to get productive quickly with AII's .NET development standards:
                  </Paragraph>

                  <Timeline
                    mode="left"
                    items={[
                      {
                        label: 'Start with Clean Architecture Standards',
                        children: (
                          <div>
                            <Paragraph>
                              Begin with <Link to="/clean-architecture">Clean Architecture Standards</Link> for immediate productivity. Learn the fundamental patterns and conventions used across all AII .NET projects.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue'
                      },
                      {
                        label: 'Explore Advanced Patterns',
                        children: (
                          <div>
                            <Paragraph>
                              Dive deeper with the <Link to="/coding-standard">Coding Standard Guide</Link> for complex scenarios, performance optimization, and enterprise-level practices.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue'
                      },
                      {
                        label: 'Follow Project Patterns',
                        children: (
                          <div>
                            <Paragraph>
                              Study existing codebase implementations and use provided templates for consistent development.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue'
                      },
                      {
                        label: 'Get Help When Needed',
                        children: (
                          <div>
                            <Paragraph>
                              Review unit tests for usage patterns, check README files, and consult team members for project-specific guidance.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue'
                      }
                    ]}
                  />
                </ScrollReveal>
              </section>

              <Divider />

              <section id="key-principles">
                <ScrollReveal>
                  <Title level={2}>
                    <AppstoreOutlined style={{ marginRight: '8px' }} />
                    Key Principles
                  </Title>
                  <Paragraph style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '32px' }}>
                    Our .NET development approach is built on these core principles that ensure consistency, maintainability, and scalability across all projects.
                  </Paragraph>

                  <StaggerContainer>
                    <Row gutter={[24, 24]}>
                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#0033A0',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <ApartmentOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Clean Architecture</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Maintain clear separation of concerns with proper layering and dependency management for testable, maintainable code.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="blue" style={{ marginRight: '8px' }}>SOLID</Tag>
                              <Tag color="blue">Layering</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#00A3E0',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <AppstoreOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Domain-Driven Design</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Focus on domain modeling with aggregates, entities, value objects, and domain services that reflect business needs.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="cyan" style={{ marginRight: '8px' }}>Aggregates</Tag>
                              <Tag color="cyan">Entities</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#00B894',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <ClockCircleOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Async/Await Patterns</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Use async/await consistently for all I/O operations to ensure responsive applications and proper resource management.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="green" style={{ marginRight: '8px' }}>Performance</Tag>
                              <Tag color="green">Scalability</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#722ED1',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <SafetyOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Comprehensive Validation</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Implement robust validation using FluentValidation with clear, actionable error messages for better user experience.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="purple" style={{ marginRight: '8px' }}>FluentValidation</Tag>
                              <Tag color="purple">User Experience</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#FA8C16',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <ExperimentOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Test-Driven Development</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Write comprehensive unit tests following established naming conventions and patterns for reliable, maintainable code.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="orange" style={{ marginRight: '8px' }}>Unit Tests</Tag>
                              <Tag color="orange">Quality Assurance</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12} lg={8}>
                        <HoverCard>
                          <Card
                            style={{
                              height: '100%',
                              borderRadius: '12px',
                              border: '1px solid #e8e8e8',
                              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                              transition: 'all 0.3s ease'
                            }}
                            bodyStyle={{ padding: '32px', textAlign: 'center' }}
                          >
                            <div style={{
                              width: '64px',
                              height: '64px',
                              borderRadius: '50%',
                              backgroundColor: '#F5222D',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 24px auto'
                            }}>
                              <FileTextOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                            </div>
                            <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>Clear Documentation</Title>
                            <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                              Document complex business logic and maintain up-to-date README files and code comments for team collaboration.
                            </Paragraph>
                            <div style={{ marginTop: '16px' }}>
                              <Tag color="red" style={{ marginRight: '8px' }}>Documentation</Tag>
                              <Tag color="red">Knowledge Sharing</Tag>
                            </div>
                          </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </StaggerContainer>
                </ScrollReveal>
              </section>

              <Divider />

              <section id="architecture-overview">
                <ScrollReveal>
                  <Title level={2}>
                    <ApartmentOutlined style={{ marginRight: '8px' }} />
                    Architecture Overview
                  </Title>

                  <Card>
                    <Row gutter={[32, 24]}>
                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card className="minimal-card" style={{ textAlign: 'center', height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '8px' }}>API Layer</Title>
                          <Paragraph style={{ fontSize: '14px', marginBottom: '12px' }}>
                            Controllers, endpoints, middleware, API versioning
                          </Paragraph>
                          <Space direction="vertical" size="small">
                            <Tag color="blue">ASP.NET Core</Tag>
                            <Tag color="blue">Swagger/OpenAPI</Tag>
                            <Tag color="blue">Serilog</Tag>
                          </Space>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card className="minimal-card" style={{ textAlign: 'center', height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '8px' }}>Application Layer</Title>
                          <Paragraph style={{ fontSize: '14px', marginBottom: '12px' }}>
                            Business logic, use cases, DTOs, commands/queries
                          </Paragraph>
                          <Space direction="vertical" size="small">
                            <Tag color="cyan">MediatR</Tag>
                            <Tag color="cyan">Mapster</Tag>
                            <Tag color="cyan">FluentValidation</Tag>
                          </Space>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card className="minimal-card" style={{ textAlign: 'center', height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '8px' }}>Domain Layer</Title>
                          <Paragraph style={{ fontSize: '14px', marginBottom: '12px' }}>
                            Core business entities, rules, aggregates, domain services
                          </Paragraph>
                          <Space direction="vertical" size="small">
                            <Tag color="blue">Domain Entities</Tag>
                            <Tag color="blue">Value Objects</Tag>
                            <Tag color="blue">Domain Events</Tag>
                          </Space>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card className="minimal-card" style={{ textAlign: 'center', height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '8px' }}>Infrastructure Layer</Title>
                          <Paragraph style={{ fontSize: '14px', marginBottom: '12px' }}>
                            Data access, external services, email, file storage
                          </Paragraph>
                          <Space direction="vertical" size="small">
                            <Tag color="cyan">Entity Framework</Tag>
                            <Tag color="cyan">PostgreSQL</Tag>
                            <Tag color="cyan">Redis</Tag>
                          </Space>
                        </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </Card>
                </ScrollReveal>
              </section>

              <Divider />

              <section id="development-workflow">
                <ScrollReveal>
                  <Title level={2}>
                    <SyncOutlined style={{ marginRight: '8px' }} />
                    Development Workflow
                  </Title>

                  <Timeline
                    mode="left"
                    items={[
                      {
                        label: '1. Understand Requirements',
                        children: (
                          <div>
                            <Paragraph>
                              Review business requirements, acceptance criteria, and identify impacted domains.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue',
                        dot: <BulbOutlined style={{ fontSize: '16px' }} />
                      },
                      {
                        label: '2. Analyze Existing Code',
                        children: (
                          <div>
                            <Paragraph>
                              Study similar implementations and identify appropriate architectural patterns.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue',
                        dot: <SearchOutlined style={{ fontSize: '16px' }} />
                      },
                      {
                        label: '3. Design Domain Model',
                        children: (
                          <div>
                            <Paragraph>
                              Define aggregates, entities, value objects, and domain services.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue',
                        dot: <AppstoreOutlined style={{ fontSize: '16px' }} />
                      },
                      {
                        label: '4. Implement Solution',
                        children: (
                          <div>
                            <Paragraph>
                              Follow coding standards, implement validation, and write comprehensive tests.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue',
                        dot: <CodeOutlined style={{ fontSize: '16px' }} />
                      },
                      {
                        label: '5. Code Review & Testing',
                        children: (
                          <div>
                            <Paragraph>
                              Ensure all tests pass, follow standards, and get peer review approval.
                            </Paragraph>
                          </div>
                        ),
                        color: 'blue',
                        dot: <CheckCircleOutlined style={{ fontSize: '16px' }} />
                      }
                    ]}
                  />
                </ScrollReveal>
              </section>

              <Divider />

              <section id="getting-help">
                <ScrollReveal>
                  <Title level={2}>
                    <QuestionCircleOutlined style={{ marginRight: '8px' }} />
                    Getting Help
                  </Title>

                  <StaggerContainer>
                    <Row gutter={[24, 24]}>
                      <Col xs={24} md={8}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<FileTextOutlined style={{ fontSize: '24px', color: '#0033A0' }} />}
                              title="Documentation First"
                              description={
                                <List size="small">
                                  <List.Item>Review existing code in the project for practical examples</List.Item>
                                  <List.Item>Check unit tests for usage patterns and edge cases</List.Item>
                                  <List.Item>Read the project's README.md for setup and architecture info</List.Item>
                                  <List.Item>Refer to the detailed guides linked above</List.Item>
                                </List>
                              }
                            />
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={8}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<TeamOutlined style={{ fontSize: '24px', color: '#0033A0' }} />}
                              title="Team Collaboration"
                              description={
                                <List size="small">
                                  <List.Item>Ask team members for clarification on project-specific patterns</List.Item>
                                  <List.Item>Join code reviews to learn from experienced developers</List.Item>
                                  <List.Item>Participate in technical discussions and knowledge sharing</List.Item>
                                  <List.Item>Contribute to improving these guidelines</List.Item>
                                </List>
                              }
                            />
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={8}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<GlobalOutlined style={{ fontSize: '24px', color: '#0033A0' }} />}
                              title="External Resources"
                              description={
                                <List size="small">
                                  <List.Item>
                                    <a href="https://docs.microsoft.com/en-us/dotnet/" target="_blank" rel="noopener noreferrer">
                                      Microsoft .NET Documentation
                                    </a>
                                  </List.Item>
                                  <List.Item>
                                    <a href="https://docs.microsoft.com/en-us/ef/" target="_blank" rel="noopener noreferrer">
                                      Entity Framework Documentation
                                    </a>
                                  </List.Item>
                                  <List.Item>
                                    <a href="https://github.com/jasontaylordev/CleanArchitecture" target="_blank" rel="noopener noreferrer">
                                      Clean Architecture Template
                                    </a>
                                  </List.Item>
                                  <List.Item>
                                    <a href="https://martinfowler.com/tags/domain%20driven%20design.html" target="_blank" rel="noopener noreferrer">
                                      DDD Resources
                                    </a>
                                  </List.Item>
                                </List>
                              }
                            />
                          </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </StaggerContainer>
                </ScrollReveal>
              </section>

              <Divider />

              <section id="contributing">
                <ScrollReveal>
                  <Title level={2}>
                    <UserOutlined style={{ marginRight: '8px' }} />
                    Contributing to Standards
                  </Title>
                  <Paragraph style={{ fontSize: '16px', lineHeight: '1.6' }}>
                    These documents evolve with our projects and best practices. When contributing:
                  </Paragraph>

                  <StaggerContainer>
                    <Row gutter={[24, 24]}>
                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<CheckCircleOutlined style={{ fontSize: '24px', color: '#52c41a' }} />}
                              title="Use Real Examples"
                              description="Ensure all code examples are taken from actual, working project code that compiles and runs correctly."
                            />
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<CheckCircleOutlined style={{ fontSize: '24px', color: '#52c41a' }} />}
                              title="Follow Microsoft Conventions"
                              description="Keep standards aligned with official Microsoft guidelines and industry best practices."
                            />
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<CheckCircleOutlined style={{ fontSize: '24px', color: '#52c41a' }} />}
                              title="Update All Related Documents"
                              description="When making significant changes, update both the standards and guide documents for consistency."
                            />
                          </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={6}>
                        <HoverCard>
                          <Card hoverable style={{ height: '100%' }}>
                            <Meta
                              avatar={<CheckCircleOutlined style={{ fontSize: '24px', color: '#52c41a' }} />}
                              title="Validate Examples"
                              description="Test that all code examples actually compile, work as expected, and demonstrate best practices."
                            />
                          </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </StaggerContainer>
                </ScrollReveal>
              </section>

              <Divider />

              <section id="version-history">
                <ScrollReveal>
                  <Title level={2}>
                    <HistoryOutlined style={{ marginRight: '8px' }} />
                    Version History
                  </Title>

                  <Card>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                      <Tag color="blue" style={{ fontSize: '14px', padding: '4px 12px' }}>v1.0.0</Tag>
                      <Text style={{ marginLeft: '12px', color: '#666' }}>January 2025</Text>
                    </div>
                    <Title level={4} style={{ marginBottom: '12px' }}>Initial Release</Title>
                    <List
                      size="small"
                      dataSource={[
                        'Complete restructuring with modern design',
                        'Comprehensive Clean Architecture standards',
                        'Detailed coding standard guide',
                        'Enhanced navigation and search functionality',
                        'Accessibility improvements'
                      ]}
                      renderItem={(item) => (
                        <List.Item>
                          <Text>• {item}</Text>
                        </List.Item>
                      )}
                    />
                  </Card>
                </ScrollReveal>
              </section>
            </div>
          </Col>

          <Col xs={24} lg={6}>
            <div style={{ position: 'sticky', top: '96px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
              <TableOfContents contentRef={contentRef} />

              {/* Quick Links - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }} disableHover>
                <div>
                  <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>
                    <LinkOutlined style={{ marginRight: '8px' }} />
                    Quick Links
                  </Title>
                  <Space direction="vertical" style={{ width: '100%' }}>
                    <Link to="/clean-architecture">
                      <Button type="text" icon={<ApartmentOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        Clean Architecture Standards
                      </Button>
                    </Link>
                    <Link to="/coding-standard">
                      <Button type="text" icon={<CodeOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        Coding Standard Guide
                      </Button>
                    </Link>
                    <Button type="text" icon={<GlobalOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://docs.microsoft.com/en-us/dotnet/" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        Microsoft .NET Docs
                      </a>
                    </Button>
                    <Button type="text" icon={<HeartOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://github.com/jasontaylordev/CleanArchitecture" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        Clean Architecture Template
                      </a>
                    </Button>
                  </Space>
                </div>
              </HoverCard>

              {/* Technology Stack - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }} disableHover>
                <div>
                  <Title level={4}>Key Technologies</Title>
                  <Space wrap style={{ marginTop: '12px' }}>
                    <Tag color="geekblue">.NET 8.0</Tag>
                    <Tag color="geekblue">ASP.NET Core</Tag>
                    <Tag color="geekblue">Entity Framework</Tag>
                    <Tag color="geekblue">PostgreSQL</Tag>
                    <Tag color="geekblue">MediatR</Tag>
                    <Tag color="geekblue">FluentValidation</Tag>
                    <Tag color="geekblue">Clean Architecture</Tag>
                    <Tag color="geekblue">Domain-Driven Design</Tag>
                  </Space>
                </div>
              </HoverCard>
            </div>
          </Col>
        </Row>
      </div>
    </Layout>
    </PageTransition>
  );
};

export default DotNetDeveloperGuidelinePage;