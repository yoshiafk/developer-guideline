import React from 'react';
import { Row, Col, Card, Typography, Button, Space, Tag } from 'antd';
import { motion } from 'framer-motion';
import {
  BookOutlined,
  ArrowRightOutlined,
  CodeOutlined,
  SafetyOutlined,
  AppstoreOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  TeamOutlined,
  BulbOutlined,
  TrophyOutlined,
  UserOutlined,
  RocketOutlined,
  ThunderboltOutlined,
  StarOutlined
} from '@ant-design/icons';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import Hero from '../components/Hero';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import StaggerContainer, { StaggerItem } from '../components/StaggerContainer';
import HoverCard from '../components/HoverCard';
import StepCard from '../components/StepCard';
import FeatureCard from '../components/FeatureCard';
import ContentSection from '../components/ContentSection';
import DocumentCard from '../components/DocumentCard';

const { Title, Paragraph } = Typography;

const HomePage: React.FC = () => {
  return (
    <PageTransition>
      <Layout showSidebar={false}>
        {/* Hero Section */}
        <Hero />

        {/* Quick Start Section - Redesigned */}
        <ContentSection
          id="quick-start"
          title="Quick Start Guide"
          subtitle="Get productive in under 5 minutes with our streamlined onboarding process"
          icon={<RocketOutlined />}
          background="gradient"
        >
          <div style={{ maxWidth: '900px', margin: '0 auto' }}>
            <Space direction="vertical" size="large" style={{ width: '100%' }}>
              <StepCard
                number={1}
                title="Learn GitHub Standards"
                description="Master AII's GitHub workflow including branching, pull requests, and code review processes."
                action={
                  <Link to="/github-axa-usage">
                    <Button type="primary" icon={<ArrowRightOutlined />}>
                      View GitHub Standards
                    </Button>
                  </Link>
                }
              />
              <StepCard
                number={2}
                title="Read the Overview"
                description="Start with our .NET Developer Guideline to understand the big picture and architectural principles."
                action={
                  <Link to="/dotnet-developer-guideline">
                    <Button type="primary" icon={<ArrowRightOutlined />}>
                      View Guidelines
                    </Button>
                  </Link>
                }
              />
              <StepCard
                number={3}
                title="Master Clean Architecture"
                description="Learn the fundamental patterns and practices that form the foundation of our development approach."
                action={
                  <Link to="/clean-architecture">
                    <Button type="primary" icon={<ArrowRightOutlined />}>
                      Learn Architecture
                    </Button>
                  </Link>
                }
              />
              <StepCard
                number={4}
                title="Apply Coding Standards"
                description="Follow our detailed coding standards and best practices for consistent, maintainable code."
                action={
                  <Link to="/coding-standard">
                    <Button type="primary" icon={<ArrowRightOutlined />}>
                      View Standards
                    </Button>
                  </Link>
                }
              />
            </Space>
          </div>
        </ContentSection>

      {/* Enhanced Features Section - Redesigned */}
      <ContentSection
        title="Why AII Developer Guidelines?"
        subtitle="Built specifically for AII's development teams with enterprise-grade standards"
        icon={<StarOutlined />}
        background="white"
      >
        <StaggerContainer>
          <Row gutter={[24, 24]}>
            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<SafetyOutlined />}
                  title="Enterprise Security"
                  description="Built-in security practices and compliance standards that meet AII's rigorous requirements."
                />
              </StaggerItem>
            </Col>

            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<TeamOutlined />}
                  title="GitHub Collaboration"
                  description="Standardized workflows, branching strategies, and code review processes for teams."
                />
              </StaggerItem>
            </Col>

            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<AppstoreOutlined />}
                  title="Multi-Platform Support"
                  description="Comprehensive standards for .NET, web technologies, and enterprise applications."
                />
              </StaggerItem>
            </Col>

            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<CheckCircleOutlined />}
                  title="Quality Assurance"
                  description="Comprehensive testing strategies and quality gates for reliable software."
                />
              </StaggerItem>
            </Col>

            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<ThunderboltOutlined />}
                  title="CI/CD Integration"
                  description="Automated pipelines, deployment standards, and monitoring practices."
                />
              </StaggerItem>
            </Col>

            <Col xs={24} sm={12} lg={8}>
              <StaggerItem>
                <FeatureCard
                  icon={<BulbOutlined />}
                  title="Knowledge Sharing"
                  description="Documentation standards and collaborative practices that promote learning."
                />
              </StaggerItem>
            </Col>
          </Row>
        </StaggerContainer>
      </ContentSection>

      {/* Content Showcase - Redesigned */}
      <ContentSection
        title="Explore Our Documentation"
        subtitle="Dive deep into specific topics with our comprehensive guides covering development standards, GitHub workflows, and best practices"
        background="white"
      >
        <StaggerContainer>
          <Row gutter={[24, 24]}>
            <Col xs={24} lg={12}>
              <StaggerItem>
                <DocumentCard
                  icon={<CodeOutlined />}
                  title="GitHub AII Usage Standards"
                  description="Complete guide to AII's GitHub workflow including branching strategies, pull request processes, code review standards, and collaboration best practices."
                  tags={[
                    { text: 'Branching Strategy', color: 'blue' },
                    { text: 'Pull Requests', color: 'blue' },
                    { text: 'Code Review', color: 'blue' }
                  ]}
                  readTime="30 min read"
                  linkTo="/github-axa-usage"
                  buttonText="Start Reading"
                />
              </StaggerItem>
            </Col>

            <Col xs={24} lg={12}>
              <Row gutter={[0, 24]}>
                <Col span={24}>
                  <StaggerItem>
                    <DocumentCard
                      icon={<CodeOutlined />}
                      title=".NET Developer Guideline"
                      description="Complete guide for .NET development including Clean Architecture standards, coding practices, and best practices."
                      tags={[
                        { text: 'Clean Architecture', color: 'green' },
                        { text: 'Coding Standards', color: 'green' },
                        { text: 'DDD Patterns', color: 'green' }
                      ]}
                      linkTo="/dotnet-developer-guideline"
                      buttonText="View Guidelines"
                    />
                  </StaggerItem>
                </Col>

                <Col span={24}>
                  <StaggerItem>
                    <DocumentCard
                      icon={<AppstoreOutlined />}
                      title="Clean Architecture Standards"
                      description="Essential naming conventions, DDD patterns, Entity Framework best practices, and code formatting standards."
                      tags={[
                        { text: 'SOLID Principles', color: 'orange' },
                        { text: 'Repository Pattern', color: 'orange' },
                        { text: 'Dependency Injection', color: 'orange' }
                      ]}
                      linkTo="/clean-architecture"
                      buttonText="Explore Architecture"
                    />
                  </StaggerItem>
                </Col>
              </Row>
            </Col>
          </Row>
        </StaggerContainer>
      </ContentSection>

      {/* Community Section - Redesigned */}
      <section 
        style={{ 
          padding: '80px 0', 
          background: 'linear-gradient(135deg, #f8fafc 0%, #e8f4ff 100%)',
          borderTop: '1px solid var(--neutral-200)'
        }}
      >
        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 16px' }}>
          <ScrollReveal>
            <Row align="middle" gutter={[48, 48]}>
              <Col xs={24} lg={12} style={{ textAlign: 'center' }}>
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, type: "spring" }}
                  style={{
                    width: '240px',
                    height: '240px',
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, var(--axa-blue-primary), var(--axa-blue-light))',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto',
                    color: '#ffffff',
                    boxShadow: '0 12px 48px rgba(0, 51, 160, 0.2)'
                  }}
                >
                  <UserOutlined style={{ fontSize: '96px' }} />
                </motion.div>
              </Col>

              <Col xs={24} lg={12}>
                <motion.div
                  initial={{ x: 50, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <Title level={2} style={{ marginBottom: '16px' }}>
                    Join the AII Development Community
                  </Title>
                  <Paragraph style={{ 
                    fontSize: '18px', 
                    color: 'var(--neutral-600)', 
                    marginBottom: '32px',
                    lineHeight: '1.7'
                  }}>
                    Connect with fellow developers across all technologies, share knowledge, and contribute to our growing collection of best practices and standards.
                  </Paragraph>

                  <Space direction="vertical" size="large" style={{ width: '100%' }}>
                    <motion.div
                      whileHover={{ x: 8 }}
                      style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '16px',
                        padding: '12px 16px',
                        background: '#ffffff',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
                      }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #f0f7ff, #e8f4ff)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <TeamOutlined style={{ fontSize: '24px', color: 'var(--axa-blue-primary)' }} />
                      </div>
                      <div>
                        <strong style={{ display: 'block', marginBottom: '4px' }}>Cross-Platform Collaboration</strong>
                        <span style={{ color: 'var(--neutral-500)', fontSize: '14px' }}>Work together across .NET, Web, and Cloud</span>
                      </div>
                    </motion.div>

                    <motion.div
                      whileHover={{ x: 8 }}
                      style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '16px',
                        padding: '12px 16px',
                        background: '#ffffff',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
                      }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #f0f7ff, #e8f4ff)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <BulbOutlined style={{ fontSize: '24px', color: 'var(--axa-blue-primary)' }} />
                      </div>
                      <div>
                        <strong style={{ display: 'block', marginBottom: '4px' }}>Knowledge Sharing</strong>
                        <span style={{ color: 'var(--neutral-500)', fontSize: '14px' }}>Share insights, best practices, and lessons learned</span>
                      </div>
                    </motion.div>

                    <motion.div
                      whileHover={{ x: 8 }}
                      style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '16px',
                        padding: '12px 16px',
                        background: '#ffffff',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)'
                      }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #f0f7ff, #e8f4ff)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <TrophyOutlined style={{ fontSize: '24px', color: 'var(--axa-blue-primary)' }} />
                      </div>
                      <div>
                        <strong style={{ display: 'block', marginBottom: '4px' }}>Quality Standards</strong>
                        <span style={{ color: 'var(--neutral-500)', fontSize: '14px' }}>Maintain excellence across all projects</span>
                      </div>
                    </motion.div>
                  </Space>

                  <div style={{ marginTop: '40px' }}>
                    <Button
                      type="primary"
                      size="large"
                      icon={<UserOutlined />}
                      style={{
                        height: '48px',
                        padding: '0 32px',
                        fontSize: '16px',
                        fontWeight: 500,
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(0, 51, 160, 0.2)'
                      }}
                    >
                      Join Community
                    </Button>
                  </div>
                </motion.div>
              </Col>
            </Row>
          </ScrollReveal>
        </div>
      </section>
    </Layout>
    </PageTransition>
  );
};

export default HomePage;