import React, { useRef } from 'react';
import { Row, Col, Card, Typography, Button, Space, Tag } from 'antd';
import { motion } from 'framer-motion';
import {
  BookOutlined,
  BranchesOutlined,
  PullRequestOutlined,
  LinkOutlined,
  EyeOutlined,
  CheckCircleOutlined,
  ApartmentOutlined,
  SyncOutlined,
  CloseOutlined,
  StarOutlined,
  DeploymentUnitOutlined,
  GithubOutlined,
  SafetyOutlined,
  TeamOutlined,
  FileTextOutlined,
  LockOutlined,
  MergeOutlined,
  MessageOutlined,
  RobotOutlined,
  SecurityScanOutlined,
  ExperimentOutlined,
  TagOutlined,
  NumberOutlined
} from '@ant-design/icons';
import Layout from '../components/Layout';
import PageHero from '../components/PageHero';
import TableOfContents from '../components/TableOfContents';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import StaggerContainer from '../components/StaggerContainer';
import HoverCard from '../components/HoverCard';
import FeatureCard from '../components/FeatureCard';
import StepCard from '../components/StepCard';
import QuickReferenceCard from '../components/QuickReferenceCard';

const { Title, Paragraph, Text } = Typography;

const GitHubAxaUsagePage: React.FC = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  return (
    <PageTransition>
      <Layout>
        <PageHero
          title="AII Organization GitHub Guidelines"
          subtitle="Comprehensive branching, pull request, and code review rules for quality software development"
          breadcrumbs={[
            { label: 'Home', href: '/' },
            { label: 'GitHub Guidelines', href: '/github-axa-usage' }
          ]}
        />

        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 16px' }}>
          {/* Table of Contents - Mobile Only (shown only on small screens) */}
          <Row>
            <Col xs={24} lg={0} style={{ marginBottom: 16 }}>
              <TableOfContents contentRef={contentRef} />
            </Col>
          </Row>

          {/* Main Content - Centered like homepage, no sidebar */}
          <Row justify="center">
            <Col xs={24} style={{ maxWidth: 800, margin: '0 auto' }}>
              {/* Quick Reference Cards */}
              <ScrollReveal>
                <div style={{ marginBottom: '64px' }}>
                  <Title level={2} style={{ textAlign: 'center', marginBottom: '32px' }}>
                    Quick Reference Guide
                  </Title>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} sm={12} lg={6}>
                      <QuickReferenceCard
                        icon={<BranchesOutlined />}
                        title="Branching Rules"
                        description="Mandatory naming patterns with protected master, development, and release branches"
                        tags={[
                          { text: 'feature/*', color: 'blue' },
                          { text: 'bugfix/*', color: 'red' },
                          { text: 'hotfix/*', color: 'orange' }
                        ]}
                        borderColor="#0033A0"
                        delay={0}
                      />
                    </Col>

                    <Col xs={24} sm={12} lg={6}>
                      <QuickReferenceCard
                        icon={<PullRequestOutlined />}
                        title="Pull Request Rules"
                        description="Mandatory PRs for all locked branches with code owner approval"
                        tags={[
                          { text: 'Code Owner Review', color: 'green' },
                          { text: 'Mandatory PR', color: 'orange' }
                        ]}
                        borderColor="#52c41a"
                        delay={0.1}
                      />
                    </Col>

                    <Col xs={24} sm={12} lg={6}>
                      <QuickReferenceCard
                        icon={<EyeOutlined />}
                        title="Code Review Rules"
                        description="Quality gates with security focus and automated checks"
                        tags={[
                          { text: 'Quality & Security', color: 'orange' },
                          { text: 'CI/CD Required', color: 'purple' }
                        ]}
                        borderColor="#fa8c16"
                        delay={0.2}
                      />
                    </Col>

                    <Col xs={24} sm={12} lg={6}>
                      <QuickReferenceCard
                        icon={<SafetyOutlined />}
                        title="Best Practices"
                        description="Testing requirements, security guidelines, and documentation standards"
                        tags={[
                          { text: 'Security First', color: 'purple' },
                          { text: 'Testing Required', color: 'cyan' }
                        ]}
                        borderColor="#722ed1"
                        delay={0.3}
                      />
                    </Col>
                  </Row>
                </div>
              </ScrollReveal>

              <div style={{ maxWidth: '800px', margin: '0 auto' }}>
                <div ref={contentRef} style={{ maxWidth: '800px', margin: '0 auto' }}>

                {/* Typical Git Workflow */}
                <section id="git-workflow" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <BranchesOutlined style={{ fontSize: '32px', color: '#0033A0', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Git Workflow with PRs and Merges
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Step-by-step process for feature development, releases, and production deployment
                        </Text>
                      </div>
                    </div>

                    <StaggerContainer>
                      <HoverCard>
                      <Card className="info-card" style={{ marginBottom: '24px' }}>
                        <Title level={4} style={{ marginBottom: '24px', textAlign: 'center' }}>
                          <BranchesOutlined style={{ marginRight: '8px' }} />
                          Development Workflow Overview
                        </Title>

                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', gap: '32px' }}>
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0 }}
                            whileHover={{ scale: 1.05, transition: { duration: 0.15 } }}
                            style={{ textAlign: 'center', maxWidth: '150px' }}
                          >
                            <div style={{
                              width: '60px',
                              height: '60px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, #0033A0, #0050B3)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 12px',
                              color: 'white',
                              fontSize: '24px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 12px rgba(0, 51, 160, 0.3)'
                            }}>
                              1
                            </div>
                            <Text strong style={{ color: '#0033A0', display: 'block', marginBottom: '8px' }}>Feature Development</Text>
                            <Text type="secondary" style={{ fontSize: '12px', lineHeight: '1.4' }}>
                              Create feature branches from development, implement changes, and open PRs for review.
                            </Text>
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: 0.1 }}
                            style={{ fontSize: '32px', color: '#91d5ff' }}
                          >
                            →
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0.2 }}
                            whileHover={{ scale: 1.05, transition: { duration: 0.15 } }}
                            style={{ textAlign: 'center', maxWidth: '150px' }}
                          >
                            <div style={{
                              width: '60px',
                              height: '60px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, #0033A0, #0050B3)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 12px',
                              color: 'white',
                              fontSize: '24px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 12px rgba(0, 51, 160, 0.3)'
                            }}>
                              2
                            </div>
                            <Text strong style={{ color: '#0033A0', display: 'block', marginBottom: '8px' }}>Preparing a Release</Text>
                            <Text type="secondary" style={{ fontSize: '12px', lineHeight: '1.4' }}>
                              Create release branches from development for final testing and preparation.
                            </Text>
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: 0.3 }}
                            style={{ fontSize: '32px', color: '#91d5ff' }}
                          >
                            →
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0.4 }}
                            whileHover={{ scale: 1.05, transition: { duration: 0.15 } }}
                            style={{ textAlign: 'center', maxWidth: '150px' }}
                          >
                            <div style={{
                              width: '60px',
                              height: '60px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, #0033A0, #0050B3)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 12px',
                              color: 'white',
                              fontSize: '24px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 12px rgba(0, 51, 160, 0.3)'
                            }}>
                              3
                            </div>
                            <Text strong style={{ color: '#0033A0', display: 'block', marginBottom: '8px' }}>Testing in PreProd</Text>
                            <Text type="secondary" style={{ fontSize: '12px', lineHeight: '1.4' }}>
                              Deploy to PreProd for UAT and QA. Fix issues via additional PRs.
                            </Text>
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: 0.5 }}
                            style={{ fontSize: '32px', color: '#91d5ff' }}
                          >
                            →
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0.6 }}
                            whileHover={{ scale: 1.05, transition: { duration: 0.15 } }}
                            style={{ textAlign: 'center', maxWidth: '150px' }}
                          >
                            <div style={{
                              width: '60px',
                              height: '60px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, #0033A0, #0050B3)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 12px',
                              color: 'white',
                              fontSize: '24px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 12px rgba(0, 51, 160, 0.3)'
                            }}>
                              4
                            </div>
                            <Text strong style={{ color: '#0033A0', display: 'block', marginBottom: '8px' }}>Going Live</Text>
                            <Text type="secondary" style={{ fontSize: '12px', lineHeight: '1.4' }}>
                              Merge release into master and development for production deployment.
                            </Text>
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: 0.7 }}
                            style={{ fontSize: '32px', color: '#91d5ff' }}
                          >
                            →
                          </motion.div>

                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0.8 }}
                            whileHover={{ scale: 1.05, transition: { duration: 0.15 } }}
                            style={{ textAlign: 'center', maxWidth: '150px' }}
                          >
                            <div style={{
                              width: '60px',
                              height: '60px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, #0033A0, #0050B3)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              margin: '0 auto 12px',
                              color: 'white',
                              fontSize: '24px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 12px rgba(0, 51, 160, 0.3)'
                            }}>
                              5
                            </div>
                            <Text strong style={{ color: '#0033A0', display: 'block', marginBottom: '8px' }}>Production Deployment</Text>
                            <Text type="secondary" style={{ fontSize: '12px', lineHeight: '1.4' }}>
                              Master triggers automatic production deployment via CI/CD.
                            </Text>
                          </motion.div>
                        </div>

                        <div style={{ marginTop: '24px', padding: '16px', background: '#e6f7ff', borderRadius: '8px', border: '1px solid #91d5ff' }}>
                          <Text strong style={{ color: '#1890ff' }}>
                            💡 <Text strong>Key Principle:</Text> All changes flow through PRs with mandatory reviews and CI checks, ensuring quality at every step.
                          </Text>
                        </div>
                      </Card>
                      </HoverCard>
                    </StaggerContainer>
                  </ScrollReveal>
                </section>

                {/* Branching Rules */}
                <section id="branching-rules" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <BranchesOutlined style={{ fontSize: '32px', color: '#0033A0', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Branching Strategy
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Structured approach to organizing development work
                        </Text>
                      </div>
                    </div>

                    <HoverCard>
                    <Card className="minimal-card" style={{ marginBottom: '32px' }}>
                      <Space direction="vertical" size="large" style={{ width: '100%' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                            <TagOutlined style={{ fontSize: '20px', color: '#0033A0', marginRight: '12px' }} />
                            <Title level={4} style={{ margin: 0 }}>
                              Branch Naming Convention
                            </Title>
                          </div>
                          <Paragraph style={{ marginBottom: '16px', fontSize: '16px', lineHeight: '1.6' }}>
                            <Text strong>Branch names must follow the pattern:</Text> All branches must conform to this regex pattern for consistency:
                          </Paragraph>
                          <div style={{ background: '#f6f8fa', padding: '16px', borderRadius: '8px', border: '1px solid #e1e4e8', marginBottom: '16px' }}>
                            <Text strong style={{ fontFamily: 'monospace', fontSize: '16px', color: '#e67e22' }}>
                              {"^(master|development|refs\\/tags\\/.+|((bugfix|hotfix|playground|defect|feature|release){1}\\/.+))$"}
                            </Text>
                          </div>
                          <Text style={{ color: '#666', marginBottom: '12px', display: 'block' }}>Practical Examples:</Text>
                          <Space wrap size="middle">
                            <Tag color="blue" style={{ padding: '4px 12px', fontSize: '14px' }}>feature/login-page</Tag>
                            <Tag color="red" style={{ padding: '4px 12px', fontSize: '14px' }}>bugfix/login-error</Tag>
                            <Tag color="green" style={{ padding: '4px 12px', fontSize: '14px' }}>playground/test-branch</Tag>
                            <Tag color="purple" style={{ padding: '4px 12px', fontSize: '14px' }}>defect/auth-fix</Tag>
                            <Tag color="cyan" style={{ padding: '4px 12px', fontSize: '14px' }}>release/v1.2.0</Tag>
                            <Tag color="orange" style={{ padding: '4px 12px', fontSize: '14px' }}>hotfix/critical-issue</Tag>
                          </Space>
                        </div>

                        <div style={{ borderTop: '1px solid #e8e8e8', paddingTop: '24px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                            <LockOutlined style={{ fontSize: '20px', color: '#e67e22', marginRight: '12px' }} />
                            <Title level={4} style={{ color: '#e67e22', margin: 0 }}>
                              Protected Branches
                            </Title>
                          </div>
                          <Paragraph style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '16px' }}>
                            Critical branches are protected (locked) to maintain code quality and prevent accidental changes. Each branch serves a specific purpose in our Git workflow:
                          </Paragraph>
                          <Row gutter={[16, 16]}>
                            <Col xs={24} sm={8}>
                              <Card size="small" style={{ border: '2px solid #e67e22', background: '#fff7e6' }}>
                                <div style={{ textAlign: 'center' }}>
                                  <Text strong style={{ color: '#e67e22', fontSize: '18px' }}>master</Text>
                                  <br />
                                  <Text type="secondary" style={{ fontSize: '14px' }}>Production branch - contains only tested, production-ready code deployed to live environment</Text>
                                </div>
                              </Card>
                            </Col>
                            <Col xs={24} sm={8}>
                              <Card size="small" style={{ border: '2px solid #e67e22', background: '#fff7e6' }}>
                                <div style={{ textAlign: 'center' }}>
                                  <Text strong style={{ color: '#e67e22', fontSize: '18px' }}>development</Text>
                                  <br />
                                  <Text type="secondary" style={{ fontSize: '14px' }}>Main development branch - integrates all feature branches and serves as base for releases</Text>
                                </div>
                              </Card>
                            </Col>
                            <Col xs={24} sm={8}>
                              <Card size="small" style={{ border: '2px solid #27ae60', background: '#f0f9e8' }}>
                                <div style={{ textAlign: 'center' }}>
                                  <Text strong style={{ color: '#27ae60', fontSize: '18px' }}>release/**</Text>
                                  <br />
                                  <Text type="secondary" style={{ fontSize: '14px' }}>Release candidate branches - for final testing in PreProd before production deployment</Text>
                                </div>
                              </Card>
                            </Col>
                          </Row>
                          <Paragraph style={{ fontSize: '14px', color: '#666', marginTop: '16px', lineHeight: '1.6' }}>
                            This branching strategy supports our Git workflow: features develop on feature branches, integrate into development, undergo final testing on release branches, and deploy to production via master branch merges.
                          </Paragraph>
                        </div>

                        <Card className="error-card">
                          <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                            <CloseOutlined style={{ color: '#cf1322', fontSize: '20px', marginRight: '12px', marginTop: '2px' }} />
                            <div>
                              <Text strong style={{ fontSize: '16px' }}>
                                🚫 Never commit directly to master, development, or any locked branches
                              </Text>
                              <br />
                              <Text type="secondary" style={{ marginTop: '8px', display: 'block' }}>
                                All changes into locked branches must be submitted via Pull Requests (PRs) with mandatory code review
                              </Text>
                            </div>
                          </div>
                        </Card>
                      </Space>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Pull Request Rules */}
                <section id="pull-request-rules" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <PullRequestOutlined style={{ fontSize: '32px', color: '#52c41a', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Pull Request Process
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Collaborative code integration with mandatory quality gates
                        </Text>
                      </div>
                    </div>

                    <StaggerContainer>
                      <HoverCard>
                      <Card className="success-card" style={{ marginBottom: '24px' }}>
                        <Title level={4} style={{ marginBottom: '24px', textAlign: 'center' }}>
                          <CheckCircleOutlined style={{ marginRight: '8px' }} />
                          PR Creation Checklist
                        </Title>

                        <Row gutter={[24, 24]}>
                          <Col xs={24} md={12}>
                            <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <CheckCircleOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
                                  <Text strong>Clear Title & Description</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  Explain what changes were made and why
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} md={12}>
                            <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <LinkOutlined style={{ color: '#0033A0', marginRight: '8px' }} />
                                  <Text strong>🔗 Link Related Issues</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  Link related issues in the PR description when applicable
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} md={12}>
                            <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <SyncOutlined style={{ color: '#fa8c16', marginRight: '8px' }} />
                                  <Text strong>Up-to-Date Branch</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  Merge latest changes from target branch
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} md={12}>
                            <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <ApartmentOutlined style={{ color: '#722ed1', marginRight: '8px' }} />
                                  <Text strong>Focused Scope</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  One feature, bug fix, or improvement per PR
                                </Text>
                              </Space>
                            </Card>
                          </Col>
                        </Row>

                        <Card className="info-card">
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '12px' }}>
                            <SafetyOutlined style={{ color: '#1890ff', fontSize: '24px', marginRight: '12px' }} />
                            <Text strong style={{ fontSize: '16px' }}>
                              🛡️ Merging Requirements: Code Owner Approval
                            </Text>
                          </div>
                          <Text>
                            Merging into any locked branches (<Text strong>master</Text>, <Text strong>development</Text>) requires a PR and code review from <Text strong>at least 1 code owner</Text>. PRs should be <Text strong>small and focused</Text> on a single purpose.
                          </Text>
                        </Card>
                      </Card>
                      </HoverCard>
                    </StaggerContainer>
                  </ScrollReveal>
                </section>

                {/* Code Review Rules */}
                <section id="code-review-rules" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <EyeOutlined style={{ fontSize: '32px', color: '#fa8c16', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Code Review Standards
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Quality assurance through collaborative peer review
                        </Text>
                      </div>
                    </div>

                    <StaggerContainer>
                      <HoverCard>
                      <Card className="warning-card" style={{ marginBottom: '24px' }}>
                        <Title level={4} style={{ marginBottom: '24px', textAlign: 'center' }}>
                          <EyeOutlined style={{ marginRight: '8px' }} />
                          Review Requirements
                        </Title>

                        <Row gutter={[24, 24]}>
                          <Col xs={24} lg={12}>
                            <Card size="small" style={{ border: '1px solid #ffd591', background: '#fafafa', height: '100%' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <TeamOutlined style={{ color: '#fa8c16', marginRight: '8px' }} />
                                  <Text strong>Code Owner Approval</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  At least one designated code owner must approve changes to main/dev branches
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} lg={12}>
                            <Card size="small" style={{ border: '1px solid #ffd591', background: '#fafafa', height: '100%' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <SafetyOutlined style={{ color: '#fa8c16', marginRight: '8px' }} />
                                  <Text strong>👀 Quality, Security & Standards</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  Reviewers check for code quality, security, and adherence to organization standards
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} lg={12}>
                            <Card size="small" style={{ border: '1px solid #ffd591', background: '#fafafa', height: '100%' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <RobotOutlined style={{ color: '#fa8c16', marginRight: '8px' }} />
                                  <Text strong>Automated Checks</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  CI/CD pipelines, tests, and linters must pass before merging
                                </Text>
                              </Space>
                            </Card>
                          </Col>

                          <Col xs={24} lg={12}>
                            <Card size="small" style={{ border: '1px solid #ffd591', background: '#fafafa', height: '100%' }}>
                              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <MessageOutlined style={{ color: '#fa8c16', marginRight: '8px' }} />
                                  <Text strong>Constructive Feedback</Text>
                                </div>
                                <Text type="secondary" style={{ fontSize: '14px' }}>
                                  Use comments for suggestions; resolve all discussions before merging
                                </Text>
                              </Space>
                            </Card>
                          </Col>
                        </Row>

                        <Card className="error-card">
                          <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                            <CloseOutlined style={{ color: '#cf1322', fontSize: '20px', marginRight: '12px', marginTop: '2px' }} />
                            <div>
                              <Text strong style={{ fontSize: '16px' }}>
                                🙅‍♂️ Do not merge your own PR
                              </Text>
                              <br />
                              <Text type="secondary" style={{ marginTop: '8px', display: 'block' }}>
                                Do not merge your own PR unless explicitly allowed by the team lead.
                              </Text>
                            </div>
                          </div>
                        </Card>
                      </Card>
                      </HoverCard>
                    </StaggerContainer>
                  </ScrollReveal>
                </section>

                {/* Best Practices */}
                <section id="best-practices" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <StarOutlined style={{ fontSize: '32px', color: '#722ed1', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Development Best Practices
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Essential guidelines for maintaining code quality and team collaboration
                        </Text>
                      </div>
                    </div>
                  </ScrollReveal>
                </section>

                {/* Commit Guidelines */}
                <section id="commit-guidelines" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <HoverCard>
                    <Card className="minimal-card">
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '24px' }}>
                        <FileTextOutlined style={{ fontSize: '24px', color: '#722ed1', marginRight: '12px' }} />
                        <Title level={3} style={{ margin: 0 }}>
                          Commit Message Standards
                        </Title>
                      </div>

                      <Row gutter={[24, 24]} align="middle">
                        <Col xs={24} lg={12}>
                          <div style={{ padding: '20px', background: '#fafafa', borderRadius: '12px', border: '1px solid #e8e8e8' }}>
                            <Title level={5} style={{ color: '#722ed1', marginBottom: '12px' }}>✅ Good Examples</Title>
                            <Space direction="vertical" size="small">
                              <Text style={{ fontFamily: 'monospace', background: '#f6f8fa', padding: '4px 8px', borderRadius: '4px' }}>
                                "Add user authentication validation"
                              </Text>
                              <Text style={{ fontFamily: 'monospace', background: '#f6f8fa', padding: '4px 8px', borderRadius: '4px' }}>
                                "Fix login form validation bug"
                              </Text>
                              <Text style={{ fontFamily: 'monospace', background: '#f6f8fa', padding: '4px 8px', borderRadius: '4px' }}>
                                "Update API documentation for v2.1"
                              </Text>
                            </Space>
                          </div>
                        </Col>

                        <Col xs={24} lg={12}>
                          <div style={{ padding: '20px', background: '#fff2f0', borderRadius: '12px', border: '1px solid #ffccc7' }}>
                            <Title level={5} style={{ color: '#cf1322', marginBottom: '12px' }}>❌ Avoid These</Title>
                            <Space direction="vertical" size="small">
                              <Text style={{ fontFamily: 'monospace', background: '#fff2f0', padding: '4px 8px', borderRadius: '4px' }}>
                                "fixed stuff"
                              </Text>
                              <Text style={{ fontFamily: 'monospace', background: '#fff2f0', padding: '4px 8px', borderRadius: '4px' }}>
                                "changes"
                              </Text>
                              <Text style={{ fontFamily: 'monospace', background: '#fff2f0', padding: '4px 8px', borderRadius: '4px' }}>
                                "update"
                              </Text>
                            </Space>
                          </div>
                        </Col>
                      </Row>

                      <div style={{ marginTop: '24px', padding: '16px', background: '#f6f8fa', borderRadius: '8px' }}>
                        <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                          <LinkOutlined style={{ color: '#722ed1', marginRight: '8px', marginTop: '2px' }} />
                          <Text>
                            <Text strong>Pro Tip:</Text> Reference related issues in commit messages using <Text code>#123</Text> format
                          </Text>
                        </div>
                      </div>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Testing Requirements */}
                <section id="testing-requirements" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <HoverCard>
                    <Card className="success-card">
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '24px' }}>
                        <ExperimentOutlined style={{ fontSize: '24px', color: '#52c41a', marginRight: '12px' }} />
                        <Title level={3} style={{ margin: 0 }}>
                          Testing & Quality Assurance
                        </Title>
                      </div>

                      <Row gutter={[24, 24]}>
                        <Col xs={24} md={12}>
                          <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                            <Space direction="vertical" size="small" style={{ width: '100%' }}>
                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <CheckCircleOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
                                <Text strong>Comprehensive Test Coverage</Text>
                              </div>
                              <Text type="secondary" style={{ fontSize: '14px' }}>
                                All new features and bug fixes must include relevant unit, integration, or end-to-end tests
                              </Text>
                            </Space>
                          </Card>
                        </Col>

                        <Col xs={24} md={12}>
                          <Card size="small" style={{ border: '1px solid #b7eb8f', background: '#fafafa' }}>
                            <Space direction="vertical" size="small" style={{ width: '100%' }}>
                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <RobotOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
                                <Text strong>Pre-Review Validation</Text>
                              </div>
                              <Text type="secondary" style={{ fontSize: '14px' }}>
                                Ensure all tests pass locally before requesting code review
                              </Text>
                            </Space>
                          </Card>
                        </Col>
                      </Row>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Security & Documentation */}
                <section id="security-practices" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <Row gutter={[24, 24]}>
                      <Col xs={24} lg={12}>
                        <HoverCard>
                        <Card className="error-card" style={{ height: '100%' }}>
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                            <SecurityScanOutlined style={{ fontSize: '24px', color: '#cf1322', marginRight: '12px' }} />
                            <Title level={4} style={{ margin: 0 }}>
                              Security First
                            </Title>
                          </div>
                          <Card className="error-card" size="small">
                            <Text strong>
                              🚫 Never commit secrets, credentials, API keys, or other sensitive data to the repository
                            </Text>
                          </Card>
                          <Text type="secondary" style={{ marginTop: '12px', display: 'block' }}>
                            Use environment variables, secret management tools, or secure configuration systems instead.
                          </Text>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} lg={12}>
                        <HoverCard>
                        <Card className="minimal-card" style={{ height: '100%' }}>
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                            <BookOutlined style={{ fontSize: '24px', color: '#0033A0', marginRight: '12px' }} />
                            <Title level={4} style={{ margin: 0 }}>
                              Documentation Updates
                            </Title>
                          </div>
                          <Text style={{ lineHeight: '1.6' }}>
                            Keep documentation synchronized with code changes. Update README files, API documentation,
                            and user guides when implementing new features or modifying existing functionality.
                          </Text>
                        </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </ScrollReveal>
                </section>

                {/* Conflict Resolution */}
                <section id="conflict-resolution" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <HoverCard>
                    <Card className="warning-card">
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '24px' }}>
                        <MergeOutlined style={{ fontSize: '24px', color: '#fa8c16', marginRight: '12px' }} />
                        <Title level={3} style={{ margin: 0 }}>
                          Conflict Resolution Best Practice
                        </Title>
                      </div>

                      <Card className="warning-card" size="small">
                        <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                          <SyncOutlined style={{ color: '#fa8c16', fontSize: '24px', marginRight: '16px', marginTop: '4px' }} />
                          <div>
                            <Text strong style={{ fontSize: '16px' }}>
                              Prevention is Better Than Cure
                            </Text>
                            <br />
                            <Text style={{ marginTop: '8px', display: 'block', lineHeight: '1.6' }}>
                              🔄 <Text strong>Always pull the latest changes from the target branch (e.g., master, development, or release/**) before starting work on a feature or creating a PR.</Text>
                              This significantly reduces the likelihood of merge conflicts and ensures you're working with the most recent codebase.
                            </Text>
                          </div>
                        </div>
                      </Card>

                      <Text type="secondary" style={{ marginTop: '16px', display: 'block' }}>
                        If conflicts do occur, resolve them locally before pushing and requesting review.
                      </Text>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* CI/CD Status */}
                <section id="ci-cd-status" style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <HoverCard>
                    <Card className="info-card">
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '24px' }}>
                        <DeploymentUnitOutlined style={{ fontSize: '24px', color: '#1890ff', marginRight: '12px' }} />
                        <Title level={3} style={{ margin: 0 }}>
                          ⚙️ CI/CD Status Requirements
                        </Title>
                      </div>

                      <Row gutter={[16, 16]}>
                        <Col xs={24} sm={8}>
                          <Card size="small" style={{ textAlign: 'center', border: '1px solid #91d5ff', background: '#fafafa' }}>
                            <RobotOutlined style={{ fontSize: '24px', color: '#1890ff', marginBottom: '8px' }} />
                            <Text strong>Automated Tests</Text>
                            <br />
                            <Text type="secondary" style={{ fontSize: '12px' }}>Unit & Integration</Text>
                          </Card>
                        </Col>

                        <Col xs={24} sm={8}>
                          <Card size="small" style={{ textAlign: 'center', border: '1px solid #91d5ff', background: '#fafafa' }}>
                            <SecurityScanOutlined style={{ fontSize: '24px', color: '#1890ff', marginBottom: '8px' }} />
                            <Text strong>Code Quality</Text>
                            <br />
                            <Text type="secondary" style={{ fontSize: '12px' }}>Linting & Analysis</Text>
                          </Card>
                        </Col>

                        <Col xs={24} sm={8}>
                          <Card size="small" style={{ textAlign: 'center', border: '1px solid #91d5ff', background: '#fafafa' }}>
                            <DeploymentUnitOutlined style={{ fontSize: '24px', color: '#1890ff', marginBottom: '8px' }} />
                            <Text strong>Build Status</Text>
                            <br />
                            <Text type="secondary" style={{ fontSize: '12px' }}>Compilation & Deployment</Text>
                          </Card>
                        </Col>
                      </Row>

                      <div style={{ marginTop: '24px', padding: '16px', background: '#e6f7ff', borderRadius: '8px', border: '1px solid #91d5ff' }}>
                        <Text strong style={{ color: '#1890ff' }}>
                          ✅ Check the status of all CI/CD checks and fix any failures before requesting a review. All automated checks (CI/CD, tests, linters) must pass before merging.
                        </Text>
                      </div>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Versioning Guidelines */}
                <section id="versioning-guidelines" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <NumberOutlined style={{ fontSize: '32px', color: '#722ed1', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          Versioning Standards
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Semantic versioning guidelines for releases and version number management
                        </Text>
                      </div>
                    </div>

                    <HoverCard>
                    <Card className="minimal-card">
                      <Space direction="vertical" size="large" style={{ width: '100%' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
                            <NumberOutlined style={{ fontSize: '24px', color: '#722ed1', marginRight: '12px' }} />
                            <Title level={3} style={{ margin: 0 }}>
                              Semantic Versioning (SemVer)
                            </Title>
                          </div>
                          <Paragraph style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '16px' }}>
                            All releases must follow <Text strong>Semantic Versioning 2.0.0</Text> format: <Text code>MAJOR.MINOR.PATCH</Text>
                          </Paragraph>

                          <div style={{ background: '#f6f8fa', padding: '20px', borderRadius: '8px', border: '1px solid #e1e4e8', marginBottom: '24px' }}>
                            <Title level={4} style={{ marginBottom: '16px', color: '#722ed1' }}>
                              Version Format: X.Y.Z
                            </Title>
                            <Row gutter={[24, 24]}>
                              <Col xs={24} md={8}>
                                <Card size="small" style={{ border: '2px solid #722ed1', background: '#fafafa' }}>
                                  <div style={{ textAlign: 'center' }}>
                                    <Text style={{ fontSize: '24px', fontWeight: 'bold', color: '#722ed1' }}>X</Text>
                                    <Title level={5} style={{ margin: '8px 0' }}>MAJOR</Title>
                                    <Text type="secondary" style={{ fontSize: '12px' }}>
                                      Breaking changes
                                    </Text>
                                  </div>
                                </Card>
                              </Col>
                              <Col xs={24} md={8}>
                                <Card size="small" style={{ border: '2px solid #52c41a', background: '#fafafa' }}>
                                  <div style={{ textAlign: 'center' }}>
                                    <Text style={{ fontSize: '24px', fontWeight: 'bold', color: '#52c41a' }}>Y</Text>
                                    <Title level={5} style={{ margin: '8px 0' }}>MINOR</Title>
                                    <Text type="secondary" style={{ fontSize: '12px' }}>
                                      New features
                                    </Text>
                                  </div>
                                </Card>
                              </Col>
                              <Col xs={24} md={8}>
                                <Card size="small" style={{ border: '2px solid #fa8c16', background: '#fafafa' }}>
                                  <div style={{ textAlign: 'center' }}>
                                    <Text style={{ fontSize: '24px', fontWeight: 'bold', color: '#fa8c16' }}>Z</Text>
                                    <Title level={5} style={{ margin: '8px 0' }}>PATCH</Title>
                                    <Text type="secondary" style={{ fontSize: '12px' }}>
                                      Bug fixes
                                    </Text>
                                  </div>
                                </Card>
                              </Col>
                            </Row>
                          </div>
                        </div>

                        <div style={{ borderTop: '1px solid #e8e8e8', paddingTop: '24px' }}>
                          <Title level={4} style={{ marginBottom: '16px', color: '#722ed1' }}>
                            When to Increment Version Numbers
                          </Title>

                          <Row gutter={[24, 24]}>
                            <Col xs={24} lg={12}>
                              <Card size="small" style={{ border: '1px solid #722ed1', background: '#fafafa' }}>
                                <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                  <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <Text style={{ fontSize: '18px', fontWeight: 'bold', color: '#722ed1', marginRight: '8px' }}>MAJOR (X)</Text>
                                    <Text style={{ fontSize: '14px', color: '#722ed1' }}>→ 1.0.0</Text>
                                  </div>
                                  <Text type="secondary" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                                    Increment when you make incompatible API changes, breaking changes, or major rewrites.
                                    Reset MINOR and PATCH to 0.
                                  </Text>
                                </Space>
                              </Card>

                              <Card size="small" style={{ border: '1px solid #52c41a', background: '#fafafa', marginTop: '12px' }}>
                                <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                  <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <Text style={{ fontSize: '18px', fontWeight: 'bold', color: '#52c41a', marginRight: '8px' }}>MINOR (Y)</Text>
                                    <Text style={{ fontSize: '14px', color: '#52c41a' }}>→ 0.1.0</Text>
                                  </div>
                                  <Text type="secondary" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                                    Increment when you add functionality in a backwards compatible manner.
                                    Reset PATCH to 0.
                                  </Text>
                                </Space>
                              </Card>
                            </Col>

                            <Col xs={24} lg={12}>
                              <Card size="small" style={{ border: '1px solid #fa8c16', background: '#fafafa' }}>
                                <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                  <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <Text style={{ fontSize: '18px', fontWeight: 'bold', color: '#fa8c16', marginRight: '8px' }}>PATCH (Z)</Text>
                                    <Text style={{ fontSize: '14px', color: '#fa8c16' }}>→ 0.0.1</Text>
                                  </div>
                                  <Text type="secondary" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                                    Increment when you make backwards compatible bug fixes.
                                    Only change this for bug fixes.
                                  </Text>
                                </Space>
                              </Card>

                              <Card size="small" style={{ border: '1px solid #1890ff', background: '#fafafa', marginTop: '12px' }}>
                                <Space direction="vertical" size="small" style={{ width: '100%' }}>
                                  <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <ExperimentOutlined style={{ color: '#1890ff', marginRight: '8px' }} />
                                    <Text strong style={{ color: '#1890ff' }}>Pre-release Versions</Text>
                                  </div>
                                  <Text type="secondary" style={{ fontSize: '14px', lineHeight: '1.5' }}>
                                    Use suffixes like <Text code>1.0.0-alpha</Text>, <Text code>1.0.0-beta.1</Text>, <Text code>1.0.0-rc.1</Text> for pre-releases.
                                  </Text>
                                </Space>
                              </Card>
                            </Col>
                          </Row>
                        </div>

                        <div style={{ borderTop: '1px solid #e8e8e8', paddingTop: '24px' }}>
                          <Title level={4} style={{ marginBottom: '16px', color: '#722ed1' }}>
                            Practical Examples
                          </Title>

                          <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12}>
                              <Card size="small" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                                <Space direction="vertical" size="small">
                                  <Text strong style={{ color: '#52c41a' }}>✅ Bug Fix Release</Text>
                                  <Text type="secondary" style={{ fontSize: '14px' }}>
                                    Current: v1.2.3 → New: v1.2.4<br/>
                                    Fixed a login validation bug
                                  </Text>
                                </Space>
                              </Card>
                            </Col>

                            <Col xs={24} sm={12}>
                              <Card size="small" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                                <Space direction="vertical" size="small">
                                  <Text strong style={{ color: '#52c41a' }}>✅ New Feature Release</Text>
                                  <Text type="secondary" style={{ fontSize: '14px' }}>
                                    Current: v1.2.3 → New: v1.3.0<br/>
                                    Added user profile management
                                  </Text>
                                </Space>
                              </Card>
                            </Col>

                            <Col xs={24} sm={12}>
                              <Card size="small" style={{ background: '#fff7e6', border: '1px solid #ffd591' }}>
                                <Space direction="vertical" size="small">
                                  <Text strong style={{ color: '#fa8c16' }}>⚠️ Breaking Change Release</Text>
                                  <Text type="secondary" style={{ fontSize: '14px' }}>
                                    Current: v1.2.3 → New: v2.0.0<br/>
                                    Changed authentication API
                                  </Text>
                                </Space>
                              </Card>
                            </Col>

                            <Col xs={24} sm={12}>
                              <Card size="small" style={{ background: '#f0f9ff', border: '1px solid #bae7ff' }}>
                                <Space direction="vertical" size="small">
                                  <Text strong style={{ color: '#1890ff' }}>🔄 Pre-release</Text>
                                  <Text type="secondary" style={{ fontSize: '14px' }}>
                                    Version: v2.0.0-beta.1<br/>
                                    Testing new major version
                                  </Text>
                                </Space>
                              </Card>
                            </Col>
                          </Row>
                        </div>

                        <Card className="info-card">
                          <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                            <NumberOutlined style={{ color: '#1890ff', fontSize: '20px', marginRight: '12px', marginTop: '2px' }} />
                            <div>
                              <Text strong style={{ color: '#1890ff' }}>Version Management Best Practices:</Text>
                              <ul style={{ marginTop: '8px', paddingLeft: '20px' }}>
                                <li>Always update version numbers in package.json, setup.py, or equivalent files</li>
                                <li>Create git tags for each release: <Text code>git tag v1.2.3</Text></li>
                                <li>Update CHANGELOG.md with version details before tagging</li>
                                <li>Use release branches for version bumps and final testing</li>
                                <li>Never modify version numbers manually in production without proper release process</li>
                              </ul>
                            </div>
                          </div>
                        </Card>
                      </Space>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Additional Guidelines */}
                <section id="additional-guidelines" style={{ marginBottom: '64px' }}>
                  <ScrollReveal>
                    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '32px' }}>
                      <BookOutlined style={{ fontSize: '32px', color: '#722ed1', marginRight: '16px' }} />
                      <div>
                        <Title level={2} style={{ color: '#111827', marginBottom: '8px' }}>
                          📋 Changelog & Release Notes
                        </Title>
                        <Text type="secondary" style={{ fontSize: '16px' }}>
                          Keep track of significant changes and user-facing updates
                        </Text>
                      </div>
                    </div>

                    <HoverCard>
                    <Card className="minimal-card">
                      <Paragraph style={{ fontSize: '16px', lineHeight: '1.6', marginBottom: '16px' }}>
                        🗒️ <Text strong>Update the changelog or release notes in your PR</Text> if your changes are user-facing or significant.
                        This helps maintain a clear history of changes and assists with release management.
                      </Paragraph>

                      <Row gutter={[24, 24]} style={{ marginTop: '24px' }}>
                        <Col xs={24} md={12}>
                          <Card size="small" style={{ border: '1px solid #d3f261', background: '#fcffe6' }}>
                            <Space direction="vertical" size="small" style={{ width: '100%' }}>
                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <CheckCircleOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
                                <Text strong>User-Facing Changes</Text>
                              </div>
                              <Text type="secondary" style={{ fontSize: '14px' }}>
                                New features, UI changes, API modifications, breaking changes
                              </Text>
                            </Space>
                          </Card>
                        </Col>

                        <Col xs={24} md={12}>
                          <Card size="small" style={{ border: '1px solid #d3f261', background: '#fcffe6' }}>
                            <Space direction="vertical" size="small" style={{ width: '100%' }}>
                              <div style={{ display: 'flex', alignItems: 'center' }}>
                                <FileTextOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
                                <Text strong>Significant Updates</Text>
                              </div>
                              <Text type="secondary" style={{ fontSize: '14px' }}>
                                Architecture changes, performance improvements, security fixes
                              </Text>
                            </Space>
                          </Card>
                        </Col>
                      </Row>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

                {/* Contact Information */}
                <section style={{ marginBottom: '48px' }}>
                  <ScrollReveal>
                    <div style={{ textAlign: 'center', marginBottom: '48px' }}>
                      <Title level={2} style={{ color: '#111827', marginBottom: '16px' }}>
                        Key Takeaways
                      </Title>
                      <Paragraph style={{ fontSize: '16px', maxWidth: '800px', margin: '0 auto', lineHeight: '1.6' }}>
                        Following these guidelines ensures high-quality, maintainable code and smooth collaboration across the AII development team.
                        Remember: quality over speed, collaboration over isolation, and security over convenience.
                      </Paragraph>
                    </div>

                    <Row gutter={[24, 24]} style={{ marginBottom: '48px' }}>
                      <Col xs={24} sm={8}>
                        <HoverCard>
                        <Card className="minimal-card" style={{ textAlign: 'center' }}>
                          <BranchesOutlined style={{ fontSize: '32px', color: '#0033A0', marginBottom: '12px' }} />
                          <Title level={4}>Structured Workflow</Title>
                          <Text>Use proper branching and never commit directly to master/development</Text>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} sm={8}>
                        <HoverCard>
                        <Card className="minimal-card" style={{ textAlign: 'center' }}>
                          <PullRequestOutlined style={{ fontSize: '32px', color: '#52c41a', marginBottom: '12px' }} />
                          <Title level={4}>Quality Gates</Title>
                          <Text>Code review and automated checks are mandatory</Text>
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} sm={8}>
                        <HoverCard>
                        <Card className="minimal-card" style={{ textAlign: 'center' }}>
                          <SafetyOutlined style={{ fontSize: '32px', color: '#722ed1', marginBottom: '12px' }} />
                          <Title level={4}>Security First</Title>
                          <Text>Never commit secrets or sensitive data</Text>
                        </Card>
                        </HoverCard>
                      </Col>
                    </Row>

                    <HoverCard>
                    <Card className="minimal-card">
                      <div style={{ textAlign: 'center' }}>
                        <GithubOutlined style={{ fontSize: '48px', color: '#0033A0', marginBottom: '16px' }} />
                        <Title level={3} style={{ marginBottom: '16px' }}>
                          Need Help or Have Questions?
                        </Title>
                        <Paragraph style={{ fontSize: '16px', marginBottom: '24px', maxWidth: '600px', margin: '0 auto 24px auto' }}>
                          For more details about these guidelines or if you need clarification on any process,
                          refer to the organization's internal documentation or contact the maintainers.
                        </Paragraph>
                        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
                          <Button
                            type="primary"
                            icon={<MessageOutlined />}
                            href="mailto:yosy.aliffakry@axa.co.id"
                            size="large"
                            style={{
                              backgroundColor: '#0033A0',
                              borderColor: '#0033A0',
                              height: '48px',
                              padding: '0 32px',
                              borderRadius: '8px',
                              fontSize: '16px'
                            }}
                          >
                            Contact: yosy.aliffakry@axa.co.id
                          </Button>

                          <Button
                            type="default"
                            icon={<GithubOutlined />}
                            href="https://github.axa.com/aii"
                            target="_blank"
                            rel="noopener noreferrer"
                            size="large"
                            style={{
                              height: '48px',
                              padding: '0 20px',
                              borderRadius: '8px',
                              fontSize: '16px'
                            }}
                          >
                            View Organization
                          </Button>
                        </div>
                      </div>
                    </Card>
                    </HoverCard>
                  </ScrollReveal>
                </section>

              </div>
              </div>
            </Col>
          </Row>
        </div>
      </Layout>
    </PageTransition>
  );
};

export default GitHubAxaUsagePage;