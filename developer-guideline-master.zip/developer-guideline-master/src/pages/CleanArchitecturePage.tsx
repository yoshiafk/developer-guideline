import React, { useRef } from 'react';
import { Row, Col, Card, Typography, Button, Space, Tag, Table } from 'antd';
import { motion } from 'framer-motion';
import {
  BookOutlined,
  CodeOutlined,
  AppstoreOutlined,
  CheckCircleOutlined,
  GlobalOutlined,
  HeartOutlined,
  LinkOutlined,
  ApartmentOutlined,
  SyncOutlined,
  CloseOutlined,
  DeploymentUnitOutlined,
  ApiOutlined
} from '@ant-design/icons';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import PageHero from '../components/PageHero';
import TableOfContents from '../components/TableOfContents';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import StaggerContainer from '../components/StaggerContainer';
import HoverCard from '../components/HoverCard';
import CodeSnippet from '../components/CodeSnippet';
import ContentSection from '../components/ContentSection';
import ComparisonCard from '../components/ComparisonCard';
import OptionCard from '../components/OptionCard';
import FeatureCard from '../components/FeatureCard';

const { Title, Paragraph, Text } = Typography;

const CleanArchitecturePage: React.FC = () => {
  const contentRef = useRef<HTMLElement>(null);
  return (
    <PageTransition>
      <Layout>
        <PageHero
          title="Clean Architecture Standards"
          subtitle="Modern .NET Development Standards"
          breadcrumbs={[
            { label: 'Home', href: '/' },
            { label: 'Clean Architecture Standards', href: '/clean-architecture' }
          ]}
        />

        <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 16px' }}>
          <Row gutter={[32, 32]}>
            {/* Main Content */}
            <Col xs={24} lg={18}>
              <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
              {/* Quick Reference Note */}
              <section style={{ marginBottom: '32px' }}>
                <Card className="info-card">
                  <Paragraph style={{ fontSize: '16px', marginBottom: 0 }}>
                    📖 <strong>Note:</strong> This is a quick reference guide for essential .NET development standards. For detailed examples and explanations, see the <Link to="/coding-standard">Coding Standard Guide</Link>.
                  </Paragraph>
                </Card>
              </section>

              {/* Architecture Decisions */}
              <section id="architecture-decisions" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ marginBottom: '24px' }}>
                    🏗️ Architecture Decisions (Choose One Approach)
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <ComparisonCard
                        optionNumber={1}
                        title="Clean Architecture (Complex Domains)"
                        code="Domain → Application → Infrastructure → WebApi"
                        codeLanguage="text"
                        useWhen={[
                          'Rich business logic',
                          'Multiple applications',
                          'Long-term projects'
                        ]}
                        variant="primary"
                      />
                    </Col>

                    <Col xs={24} md={12}>
                      <ComparisonCard
                        optionNumber={2}
                        title="Vertical Slice (CRUD Applications)"
                        code="Features/Orders/Create/\nFeatures/Orders/GetById/"
                        codeLanguage="text"
                        useWhen={[
                          'Independent features',
                          'Rapid development',
                          'Smaller teams'
                        ]}
                        variant="secondary"
                      />
                    </Col>
                  </Row>
                </ScrollReveal>
              </section>

              {/* Design Patterns */}
              <section id="design-patterns" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ marginBottom: '24px' }}>
                    🎯 Design Patterns (Choose One Approach)
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24}>
                      <ComparisonCard
                        optionNumber={1}
                        title="CQRS + MediatR"
                        code={`public record CreateOrderCommand(string Product) : IRequest<OrderResult>;
public class CreateOrderHandler : IRequestHandler<CreateOrderCommand, OrderResult>`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Complex workflows',
                          'Cross-cutting concerns',
                          'Event-driven architecture'
                        ]}
                        variant="primary"
                      />
                    </Col>

                    <Col xs={24}>
                      <ComparisonCard
                        optionNumber={2}
                        title="Direct Services"
                        code={`public interface IOrderService { 
  Task<OrderResult> CreateAsync(CreateOrderRequest request); 
}
public class OrderService : IOrderService`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Simple CRUD',
                          'Smaller applications',
                          'Performance-critical'
                        ]}
                        variant="secondary"
                      />
                    </Col>
                  </Row>
                </ScrollReveal>
              </section>

              {/* Data Access Patterns */}
              <section id="data-access-patterns" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ marginBottom: '24px' }}>
                    💾 Data Access (Choose One Approach)
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24} lg={12}>
                      <OptionCard
                        optionNumber={1}
                        title="Repository Pattern"
                        code={`public interface IOrderRepository { 
  Task<Order> GetByIdAsync(int id); 
}`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Testing abstraction needed',
                          'Clean Architecture',
                          'Multiple data sources'
                        ]}
                        compact
                      />
                    </Col>

                    <Col xs={24} lg={12}>
                      <OptionCard
                        optionNumber={2}
                        title="Generic Repository + UoW"
                        code={`public interface IRepository<T> { 
  Task<T> GetByIdAsync(int id); 
}
public interface IUnitOfWork { 
  IOrderRepository Orders { get; } 
}`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Many similar entities',
                          'Consistent patterns',
                          'Transaction coordination'
                        ]}
                        compact
                      />
                    </Col>

                    <Col xs={24} lg={12}>
                      <OptionCard
                        optionNumber={3}
                        title="Direct DbContext"
                        code={`public class OrderHandler { 
  private readonly IAppDbContext _context; 
}`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Simple operations',
                          'Vertical Slice',
                          'Performance important'
                        ]}
                        compact
                      />
                    </Col>
                  </Row>
                </ScrollReveal>
              </section>

              {/* API Approaches */}
              <section id="api-approaches" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ marginBottom: '24px' }}>
                    🌐 API Approaches (Choose One Approach)
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24}>
                      <ComparisonCard
                        optionNumber={1}
                        title="Standard Controllers"
                        code={`[ApiController, Route("api/[controller]")]
public class OrdersController : ControllerBase`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Complex APIs, many endpoints',
                          'Traditional MVC experience'
                        ]}
                        variant="primary"
                      />
                    </Col>

                    <Col xs={24}>
                      <ComparisonCard
                        optionNumber={2}
                        title="Minimal APIs"
                        code={`app.MapPost("/api/orders", 
  async (CreateOrderCommand cmd, ISender sender) => 
    Results.Ok(await sender.Send(cmd)));`}
                        codeLanguage="csharp"
                        useWhen={[
                          'Simple APIs, microservices',
                          'Performance-critical, modern style'
                        ]}
                        variant="secondary"
                      />
                    </Col>
                  </Row>
                </ScrollReveal>
              </section>

              {/* Quick Standards Checklist */}
              <section id="quick-standards" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    📋 Quick Standards Checklist
                  </Title>

                  <Space direction="vertical" size="large" style={{ width: '100%' }}>
                    <Card className="minimal-card">
                      <Title level={3} style={{ marginBottom: '16px' }}>✅ Naming Conventions</Title>
                      <ul style={{ marginBottom: 0 }}>
                        <li><strong>Classes:</strong> <code>PascalCase</code> → <code>OrderService</code>, <code>CreateOrderHandler</code></li>
                        <li><strong>Interfaces:</strong> <code>IPascalCase</code> → <code>IOrderRepository</code>, <code>IEmailService</code></li>
                        <li><strong>Methods:</strong> <code>PascalCase + Async</code> → <code>GetOrderAsync</code>, <code>CreateOrderAsync</code></li>
                        <li><strong>Properties:</strong> <code>PascalCase</code> → <code>OrderId</code>, <code>CustomerName</code></li>
                        <li><strong>Fields:</strong> <code>_camelCase</code> → <code>_dbContext</code>, <code>_logger</code></li>
                        <li><strong>Variables/Parameters:</strong> <code>camelCase</code> → <code>orderId</code>, <code>cancellationToken</code></li>
                      </ul>
                    </Card>

                    <Row gutter={[24, 24]}>
                      <Col xs={24} md={12}>
                        <HoverCard>
                          <Card className="success-card" style={{ height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '16px' }}>✅ DO: Async/Await</Title>
                          <CodeSnippet
                            code={`public async Task<Order> GetOrderAsync(
  int id, 
  CancellationToken cancellationToken)
{
  return await _repository.GetByIdAsync(id, cancellationToken);
}`}
                            language="csharp"
                            showLineNumbers={false}
                          />
                        </Card>
                        </HoverCard>
                      </Col>

                      <Col xs={24} md={12}>
                        <HoverCard>
                          <Card className="error-card" style={{ height: '100%' }}>
                          <Title level={4} style={{ marginBottom: '16px' }}>❌ DON'T: Block Async</Title>
                          <CodeSnippet
                            code={`// DEADLOCK RISK!
var order = GetOrderAsync(id).Result;`}
                            language="csharp"
                            showLineNumbers={false}
                          />
                        </Card>
                        </HoverCard>
                      </Col>
                    </Row>
                  </Space>
                </ScrollReveal>
              </section>

              {/* Overview */}
              <section id="overview" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ marginBottom: '24px' }}>
                    <ApartmentOutlined style={{ marginRight: '8px' }} />
                    Project Structure Templates
                  </Title>
                  <Paragraph style={{ color: 'var(--neutral-600)', marginBottom: '24px', fontSize: '16px' }}>
                    Organize your solution into clear layers with proper separation of concerns.
                  </Paragraph>

                  <StaggerContainer>
                    <Row gutter={[24, 24]} style={{ marginBottom: '32px' }}>
                      <Col xs={24} md={8}>
                        <FeatureCard
                          icon={<ApartmentOutlined />}
                          title="Layered Architecture"
                          description="Clear separation between presentation, business logic, data access, and infrastructure concerns."
                        />
                      </Col>

                      <Col xs={24} md={8}>
                        <FeatureCard
                          icon={<AppstoreOutlined />}
                          title="SOLID Principles"
                          description="Five fundamental principles for building maintainable, extensible software systems."
                        />
                      </Col>

                      <Col xs={24} md={8}>
                        <FeatureCard
                          icon={<SyncOutlined />}
                          title="Dependency Injection"
                          description="Loose coupling through dependency injection for better testability and maintainability."
                        />
                      </Col>
                    </Row>
                  </StaggerContainer>

                  <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>Example Project Structure</Title>
                  <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                    <div style={{
                      backgroundColor: '#f3f4f6',
                      padding: '16px',
                      borderRadius: '8px',
                      fontSize: '12px',
                      fontFamily: 'monospace',
                      overflow: 'auto',
                      margin: 0
                    }}>
                      <pre style={{ margin: 0 }}>{`MySolution/
│
├── build/                  # Build scripts, CI/CD, pipeline configs
├── docs/                   # Documentation, architecture diagrams, specs
├── src/                    # Main source code
│   ├── Core/               # Domain models, interfaces, business logic
│   │   ├── Entities/
│   │   ├── Interfaces/
│   │   ├── Services/
│   │   └── ValueObjects/
│   ├── Application/        # Application layer (use cases, DTOs, validation)
│   │   ├── UseCases/
│   │   ├── DTOs/
│   │   └── Validators/
│   ├── Infrastructure/     # Data access, external services, implementations
│   │   ├── Data/
│   │   ├── Repositories/
│   │   ├── Services/
│   │   └── Migrations/
│   ├── WebApi/             # API controllers, middleware, startup
│   │   ├── Controllers/
│   │   ├── Middleware/
│   │   ├── Filters/
│   │   └── Program.cs
│   └── Shared/             # Shared utilities, constants, helpers
│
├── tests/                  # Test projects
│   ├── Core.Tests/
│   ├── Application.Tests/
│   ├── Infrastructure.Tests/
│   └── WebApi.Tests/
│
├── .editorconfig           # Code style settings
├── .gitignore              # Git ignore rules
├── Directory.Packages.props# Central NuGet package management
├── README.md               # Project overview
└── LICENSE                 # License file`}</pre>
                    </div>
                    <Text style={{ fontSize: '14px', color: '#666666', marginTop: '12px', display: 'block' }}>
                      Adjust and extend folders as needed for your team or solution.
                    </Text>
                  </Card>
                </ScrollReveal>
              </section>

              {/* Essential Code Patterns */}
              <section id="code-patterns" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    🔧 Essential Code Patterns
                  </Title>

                  <Space direction="vertical" size="large" style={{ width: '100%' }}>
                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Entity Framework Configuration
                      </Title>
                      <CodeSnippet
                        code={`// Entity Configuration
public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
  public void Configure(EntityTypeBuilder<Order> builder)
  {
    builder.HasKey(o => o.Id);
    builder.Property(o => o.Total).HasPrecision(18, 2);
    builder.HasMany(o => o.Items).WithOne(i => i.Order);
  }
}

// DbContext Interface
public interface IAppDbContext
{
  DbSet<Order> Orders { get; set; }
  Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Generic Repository (if chosen)
                      </Title>
                      <CodeSnippet
                        code={`public interface IRepository<T> where T : class
{
  Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
  Task<List<T>> GetAllAsync(CancellationToken cancellationToken = default);
  Task AddAsync(T entity, CancellationToken cancellationToken = default);
  void Update(T entity);
  void Delete(T entity);
}

public class Repository<T> : IRepository<T> where T : class
{
  protected readonly DbContext _context;
  protected readonly DbSet<T> _dbSet;
  
  public Repository(DbContext context)
  {
    _context = context;
    _dbSet = context.Set<T>();
  }
  
  public virtual async Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    => await _dbSet.FindAsync(new object[] { id }, cancellationToken);
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Service Registration
                      </Title>
                      <CodeSnippet
                        code={`// Extension method for clean registration
public static class ServiceCollectionExtensions
{
  public static IServiceCollection AddApplicationServices(this IServiceCollection services)
  {
    // MediatR (if using CQRS)
    services.AddMediatR(cfg => 
      cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
    
    // Validation
    services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
    
    // Data Access (choose one approach)
    services.AddScoped<IOrderRepository, OrderRepository>();
    // OR
    services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
    
    // Business Services
    services.AddScoped<IOrderService, OrderService>();
    services.AddScoped<IEmailService, EmailService>();
    
    return services;
  }
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Validation with FluentValidation
                      </Title>
                      <CodeSnippet
                        code={`public class CreateOrderValidator : AbstractValidator<CreateOrderCommand>
{
  public CreateOrderValidator()
  {
    RuleFor(x => x.ProductName)
      .NotEmpty()
      .WithMessage("Product name is required")
      .MaximumLength(100)
      .WithMessage("Product name cannot exceed 100 characters");
    
    RuleFor(x => x.Quantity)
      .GreaterThan(0)
      .WithMessage("Quantity must be greater than 0");
  }
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Error Handling Middleware
                      </Title>
                      <CodeSnippet
                        code={`public class ExceptionMiddleware
{
  public async Task InvokeAsync(HttpContext context)
  {
    try 
    { 
      await _next(context); 
    }
    catch (OrderNotFoundException ex) 
    { 
      context.Response.StatusCode = 404;
      await context.Response.WriteAsJsonAsync(new { error = ex.Message });
    }
    catch (ValidationException ex) 
    { 
      context.Response.StatusCode = 400;
      await context.Response.WriteAsJsonAsync(new { errors = ex.Errors });
    }
  }
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>
                  </Space>
                </ScrollReveal>
              </section>

              {/* Decision Matrix */}
              <section id="decision-matrix" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    🎯 Decision Matrix
                  </Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Use this matrix to quickly decide which approaches to use based on your project scenario.
                  </Paragraph>

                  <Card style={{ overflowX: 'auto' }}>
                    <Table
                      columns={[
                        {
                          title: 'Scenario',
                          dataIndex: 'scenario',
                          key: 'scenario',
                          width: 180,
                          render: (text: string) => <Text strong>{text}</Text>
                        },
                        {
                          title: 'Architecture',
                          dataIndex: 'architecture',
                          key: 'architecture',
                          width: 150
                        },
                        {
                          title: 'Pattern',
                          dataIndex: 'pattern',
                          key: 'pattern',
                          width: 150
                        },
                        {
                          title: 'Data Access',
                          dataIndex: 'dataAccess',
                          key: 'dataAccess',
                          width: 180
                        },
                        {
                          title: 'API Style',
                          dataIndex: 'apiStyle',
                          key: 'apiStyle',
                          width: 130
                        }
                      ]}
                      dataSource={[
                        {
                          key: '1',
                          scenario: 'Complex Business Logic',
                          architecture: 'Clean Architecture',
                          pattern: 'CQRS + MediatR',
                          dataAccess: 'Repository',
                          apiStyle: 'Controllers'
                        },
                        {
                          key: '2',
                          scenario: 'CRUD Application',
                          architecture: 'Vertical Slice',
                          pattern: 'Direct Services',
                          dataAccess: 'Generic Repository',
                          apiStyle: 'Minimal APIs'
                        },
                        {
                          key: '3',
                          scenario: 'Microservice',
                          architecture: 'Vertical Slice',
                          pattern: 'CQRS + MediatR',
                          dataAccess: 'Direct DbContext',
                          apiStyle: 'Minimal APIs'
                        },
                        {
                          key: '4',
                          scenario: 'Enterprise Application',
                          architecture: 'Clean Architecture',
                          pattern: 'CQRS + MediatR',
                          dataAccess: 'Repository + UoW',
                          apiStyle: 'Controllers'
                        },
                        {
                          key: '5',
                          scenario: 'Rapid Prototype',
                          architecture: 'Vertical Slice',
                          pattern: 'Direct Services',
                          dataAccess: 'Direct DbContext',
                          apiStyle: 'Minimal APIs'
                        }
                      ]}
                      pagination={false}
                      size="middle"
                      bordered
                    />
                  </Card>
                </ScrollReveal>
              </section>

              {/* Common Mistakes */}
              <section id="common-mistakes" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    ⚠️ Common Mistakes to Avoid
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24}>
                      <Card style={{ borderLeft: '4px solid #dc2626', backgroundColor: '#fef2f2' }}>
                        <Title level={4} style={{ color: '#dc2626', marginBottom: '16px' }}>
                          ❌ DON'T: Mix Architectural Patterns
                        </Title>
                        <CodeSnippet
                          code={`// ❌ WRONG: Mixing Direct Service with MediatR
public class OrderService : IOrderService  // Direct Service
{
  public async Task<OrderResult> CreateAsync(CreateOrderRequest request)
  {
    return await _sender.Send(new CreateOrderCommand()); // But using MediatR?
  }
}`}
                          language="csharp"
                          showLineNumbers={true}
                        />
                      </Card>
                    </Col>

                    <Col xs={24}>
                      <Card style={{ borderLeft: '4px solid #dc2626', backgroundColor: '#fef2f2' }}>
                        <Title level={4} style={{ color: '#dc2626', marginBottom: '16px' }}>
                          ❌ DON'T: Block Async Calls
                        </Title>
                        <CodeSnippet
                          code={`// DEADLOCK RISK!
var result = CreateOrderAsync().Result;`}
                          language="csharp"
                          showLineNumbers={false}
                        />
                      </Card>
                    </Col>

                    <Col xs={24}>
                      <Card style={{ borderLeft: '4px solid #dc2626', backgroundColor: '#fef2f2' }}>
                        <Title level={4} style={{ color: '#dc2626', marginBottom: '16px' }}>
                          ❌ DON'T: Use Generic Validation Messages
                        </Title>
                        <CodeSnippet
                          code={`// Too vague!
public AccountInquiryInternalRequestValidation()
{
 RuleFor(x => x.BeneficiaryAccountNo)
  .NotEmpty().WithMessage("Empty!");
};

// Better: Be specific
public AccountInquiryInternalRequestValidation()
{
 RuleFor(x => x.BeneficiaryAccountNo)
  .NotEmpty().WithMessage("Beneficiary Account number is required.")
  .MaximumLength(34)
  .WithMessage("Beneficiary Account number cannot exceed 34 characters")
  .Must(ValidatorHelper.BeNumeric)
  .WithMessage("Beneficiary Account number must contain only numeric characters");
}`}
                          language="csharp"
                          showLineNumbers={false}
                        />
                      </Card>
                    </Col>

                    <Col xs={24}>
                      <Card style={{ borderLeft: '4px solid #dc2626', backgroundColor: '#fef2f2' }}>
                        <Title level={4} style={{ color: '#dc2626', marginBottom: '16px' }}>
                          ❌ DON'T: Put Business Logic in Controllers
                        </Title>
                        <CodeSnippet
                          code={`[HttpPost]
public async Task<IActionResult> CreateOrder(CreateOrderRequest request)
{
  // Validation here - WRONG!
  if (string.IsNullOrEmpty(request.ProductName)) 
    return BadRequest();
  
  // Business logic here - WRONG!
  var order = new Order { ProductName = request.ProductName };
  _context.Orders.Add(order);
  await _context.SaveChangesAsync();
  
  return Ok(); // Should be in service/handler!
}`}
                          language="csharp"
                          showLineNumbers={true}
                        />
                      </Card>
                    </Col>
                  </Row>

                  <Card style={{ marginTop: '24px', backgroundColor: '#fef3c7', borderLeft: '4px solid #f59e0b' }}>
                    <Title level={4} style={{ color: '#92400e', marginBottom: '16px' }}>
                      💡 Remember
                    </Title>
                    <Paragraph style={{ color: '#92400e', marginBottom: 0, fontSize: '16px' }}>
                      <strong>Choose one approach per project and apply it consistently.</strong> When in doubt, refer to existing code patterns in your project and follow the established conventions.
                    </Paragraph>
                  </Card>
                </ScrollReveal>
              </section>

              {/* Key Principles Summary */}
              <section id="key-principles" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    📝 Key Principles Summary
                  </Title>

                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={8}>
                      <Card style={{ height: '100%', borderLeft: '4px solid #3b82f6' }}>
                        <Title level={4} style={{ color: '#3b82f6', marginBottom: '16px' }}>
                          SOLID Principles
                        </Title>
                        <ul style={{ paddingLeft: '20px', margin: 0 }}>
                          <li style={{ marginBottom: '8px' }}><strong>S</strong>ingle Responsibility: One class, one reason to change</li>
                          <li style={{ marginBottom: '8px' }}><strong>O</strong>pen/Closed: Open for extension, closed for modification</li>
                          <li style={{ marginBottom: '8px' }}><strong>L</strong>iskov Substitution: Derived classes must be substitutable</li>
                          <li style={{ marginBottom: '8px' }}><strong>I</strong>nterface Segregation: Many specific interfaces &gt; one general</li>
                          <li><strong>D</strong>ependency Inversion: Depend on abstractions, not concretions</li>
                        </ul>
                      </Card>
                    </Col>

                    <Col xs={24} md={8}>
                      <Card style={{ height: '100%', borderLeft: '4px solid #10b981' }}>
                        <Title level={4} style={{ color: '#10b981', marginBottom: '16px' }}>
                          Clean Code Rules
                        </Title>
                        <ul style={{ paddingLeft: '20px', margin: 0 }}>
                          <li style={{ marginBottom: '8px' }}>Use meaningful, descriptive names</li>
                          <li style={{ marginBottom: '8px' }}>Keep methods short and focused (≤ 20 lines)</li>
                          <li style={{ marginBottom: '8px' }}>Avoid magic numbers/strings (use constants)</li>
                          <li style={{ marginBottom: '8px' }}>Write self-documenting code</li>
                          <li>Remove dead code and outdated comments</li>
                        </ul>
                      </Card>
                    </Col>

                    <Col xs={24} md={8}>
                      <Card style={{ height: '100%', borderLeft: '4px solid #f59e0b' }}>
                        <Title level={4} style={{ color: '#f59e0b', marginBottom: '16px' }}>
                          Performance Guidelines
                        </Title>
                        <ul style={{ paddingLeft: '20px', margin: 0 }}>
                          <li style={{ marginBottom: '8px' }}>Use <code>async/await</code> consistently</li>
                          <li style={{ marginBottom: '8px' }}>Include <code>CancellationToken</code> in async methods</li>
                          <li style={{ marginBottom: '8px' }}>Use <code>IQueryable</code> projections for database queries</li>
                          <li style={{ marginBottom: '8px' }}>Consider caching for expensive operations</li>
                          <li>Use appropriate service lifetimes (Scoped/Transient/Singleton)</li>
                        </ul>
                      </Card>
                    </Col>
                  </Row>
                </ScrollReveal>
              </section>

              {/* Testing Patterns */}
              <section id="testing-patterns" style={{ marginBottom: '48px' }}>
                <ScrollReveal>
                  <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                    🧪 Testing Patterns
                  </Title>

                  <Space direction="vertical" size="large" style={{ width: '100%' }}>
                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Unit Test Structure
                      </Title>
                      <Paragraph style={{ color: '#4b5563', marginBottom: '16px' }}>
                        Follow the Arrange-Act-Assert pattern for clear and maintainable tests:
                      </Paragraph>
                      <CodeSnippet
                        code={`[TestFixture]
public class CreateOrderHandlerTests
{
  private Mock<IOrderRepository> _mockRepository;
  private CreateOrderHandler _handler;
  
  [SetUp]
  public void Setup()
  {
    _mockRepository = new Mock<IOrderRepository>();
    _handler = new CreateOrderHandler(_mockRepository.Object);
  }
  
  [Test]
  public async Task Handle_ValidOrder_ReturnsSuccess()
  {
    // Arrange
    var command = new CreateOrderCommand("Product", 10.99m);
    
    // Act
    var result = await _handler.Handle(command, CancellationToken.None);
    
    // Assert
    Assert.That(result.Success, Is.True);
    _mockRepository.Verify(r => r.AddAsync(It.IsAny<Order>(), It.IsAny<CancellationToken>()), Times.Once);
  }
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card>
                      <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>
                        Validation Testing
                      </Title>
                      <Paragraph style={{ color: '#4b5563', marginBottom: '16px' }}>
                        Use FluentValidation's test extensions for comprehensive validation tests:
                      </Paragraph>
                      <CodeSnippet
                        code={`[Test]
public void Validate_EmptyProductName_ShouldFailValidation()
{
  // Arrange
  var command = new CreateOrderCommand("", 10.99m);
  var validator = new CreateOrderValidator();
  
  // Act
  var result = validator.TestValidate(command);
  
  // Assert
  result.ShouldHaveValidationErrorFor(x => x.ProductName)
        .WithErrorMessage("Product name is required");
}`}
                        language="csharp"
                        showLineNumbers={true}
                        showCopyButton={true}
                      />
                    </Card>

                    <Card style={{ backgroundColor: '#eff6ff', borderLeft: '4px solid #3b82f6' }}>
                      <Title level={4} style={{ color: '#1e40af', marginBottom: '12px' }}>
                        💡 Testing Best Practices
                      </Title>
                      <ul style={{ color: '#1e3a8a', margin: 0, paddingLeft: '20px' }}>
                        <li style={{ marginBottom: '8px' }}>Use descriptive test names: <code>Method_Scenario_ExpectedBehavior</code></li>
                        <li style={{ marginBottom: '8px' }}>Mock external dependencies (databases, APIs)</li>
                        <li style={{ marginBottom: '8px' }}>One assertion per test (when possible)</li>
                        <li style={{ marginBottom: '8px' }}>Test both happy path and error scenarios</li>
                        <li>Use test fixtures for setup/teardown logic</li>
                      </ul>
                    </Card>
                  </Space>
                </ScrollReveal>
              </section>

          {/* SOLID Principles */}
          <section id="solid" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <AppstoreOutlined style={{ marginRight: '8px' }} />
                SOLID Principles
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                SOLID Principles: Five fundamental principles for building maintainable, extensible software systems.
              </Paragraph>

              <Space direction="vertical" size="large" style={{ width: '100%' }}>
                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Single Responsibility Principle (SRP)</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Each class should have one responsibility and one reason to change.
                  </Paragraph>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CheckCircleOutlined style={{ color: '#16a34a' }} />
                            <Text strong style={{ color: '#16a34a' }}>CORRECT: Single Responsibility</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #16a34a' }}
                      >
                        <CodeSnippet
                          code={`// Good
public class InvoicePrinter { public void Print(Invoice invoice) { ... } }
public class InvoiceSaver { public void Save(Invoice invoice) { ... } }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CloseOutlined style={{ color: '#dc2626' }} />
                            <Text strong style={{ color: '#dc2626' }}>WRONG: Multiple Responsibilities</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #dc2626' }}
                      >
                        <CodeSnippet
                          code={`// Bad
public class InvoiceManager {
    public void Print(Invoice invoice) { ... }
    public void Save(Invoice invoice) { ... }
}`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                  </Row>
                </div>

                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Open/Closed Principle (OCP)</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Classes should be open for extension, closed for modification.
                  </Paragraph>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CheckCircleOutlined style={{ color: '#16a34a' }} />
                            <Text strong style={{ color: '#16a34a' }}>CORRECT: Extensible Design</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #16a34a' }}
                      >
                        <CodeSnippet
                          code={`// Good
public abstract class Shape { public abstract double Area(); }
public class Circle : Shape { ... }
public class Square : Shape { ... }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CloseOutlined style={{ color: '#dc2626' }} />
                            <Text strong style={{ color: '#dc2626' }}>WRONG: Switch Statements</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #dc2626' }}
                      >
                        <CodeSnippet
                          code={`// Bad
public class AreaCalculator {
    public double Area(object shape) {
        switch (shape) { ... }
    }
}`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                  </Row>
                </div>

                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Liskov Substitution Principle (LSP)</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Derived classes should be substitutable for their base classes.
                  </Paragraph>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CheckCircleOutlined style={{ color: '#16a34a' }} />
                            <Text strong style={{ color: '#16a34a' }}>CORRECT: Substitutable Classes</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #16a34a' }}
                      >
                        <CodeSnippet
                          code={`// Good
public class Bird { public virtual void Fly() { } }
public class Sparrow : Bird { public override void Fly() { } }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CloseOutlined style={{ color: '#dc2626' }} />
                            <Text strong style={{ color: '#dc2626' }}>WRONG: Breaking Substitution</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #dc2626' }}
                      >
                        <CodeSnippet
                          code={`// Bad
public class Ostrich : Bird { public override void Fly() { throw new NotSupportedException(); } }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                  </Row>
                </div>

                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Interface Segregation Principle (ISP)</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Prefer small, specific interfaces over large, general-purpose ones.
                  </Paragraph>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CheckCircleOutlined style={{ color: '#16a34a' }} />
                            <Text strong style={{ color: '#16a34a' }}>CORRECT: Specific Interfaces</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #16a34a' }}
                      >
                        <CodeSnippet
                          code={`// Good
public interface IPrinter { void Print(); }
public interface IScanner { void Scan(); }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CloseOutlined style={{ color: '#dc2626' }} />
                            <Text strong style={{ color: '#dc2626' }}>WRONG: Fat Interfaces</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #dc2626' }}
                      >
                        <CodeSnippet
                          code={`// Bad
public interface IMachine { void Print(); void Scan(); void Fax(); }`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                  </Row>
                </div>

                <div style={{ borderLeft: '4px solid #3b82f6', paddingLeft: '24px' }}>
                  <Title level={3} style={{ color: '#111827', marginBottom: '24px' }}>Dependency Inversion Principle (DIP)</Title>
                  <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                    Depend on abstractions, not concretions.
                  </Paragraph>
                  <Row gutter={[24, 24]}>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CheckCircleOutlined style={{ color: '#16a34a' }} />
                            <Text strong style={{ color: '#16a34a' }}>CORRECT: Abstractions</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #16a34a' }}
                      >
                        <CodeSnippet
                          code={`// Good
public interface IMessageSender { void Send(string message); }
public class EmailSender : IMessageSender { ... }
public class NotificationService {
    private readonly IMessageSender _sender;
    public NotificationService(IMessageSender sender) { _sender = sender; }
}`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                    <Col xs={24} md={12}>
                      <Card
                        title={
                          <Space>
                            <CloseOutlined style={{ color: '#dc2626' }} />
                            <Text strong style={{ color: '#dc2626' }}>WRONG: Concrete Dependencies</Text>
                          </Space>
                        }
                        size="small"
                        style={{ border: '2px solid #dc2626' }}
                      >
                        <CodeSnippet
                          code={`// Bad
public class NotificationService {
    private readonly EmailSender _sender = new EmailSender();
}`}
                          language="csharp"
                        />
                      </Card>
                    </Col>
                  </Row>
                </div>
              </Space>
            </ScrollReveal>
          </section>

          {/* Clean Code Practices */}
          <section id="clean-code" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <CodeOutlined style={{ marginRight: '8px' }} />
                Clean Code Practices
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Clean Code: Writing code that is easy to read, understand, and maintain.
              </Paragraph>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <Card
                    title={
                      <Space>
                        <CheckCircleOutlined style={{ color: '#16a34a' }} />
                        <Text strong style={{ color: '#16a34a' }}>DO: Best Practices</Text>
                      </Space>
                    }
                    style={{ border: '2px solid #16a34a', height: '100%' }}
                  >
                    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Meaningful Names:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Use descriptive and unambiguous names.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Short, Focused Methods:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Keep methods short and focused on a single task.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Avoid Magic Numbers/Strings:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Use named constants.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Self-Documenting Code:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Write code that explains itself.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Remove Dead Code:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Delete unused code and outdated comments.
                        </Text>
                      </div>
                    </Space>
                  </Card>
                </Col>
                <Col xs={24} md={12}>
                  <Card
                    title={
                      <Space>
                        <CloseOutlined style={{ color: '#dc2626' }} />
                        <Text strong style={{ color: '#dc2626' }}>DON'T: Anti-Patterns</Text>
                      </Space>
                    }
                    style={{ border: '2px solid #dc2626', height: '100%' }}
                  >
                    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Vague Names:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Use unclear or misleading names.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Long Methods:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Write methods that do many things.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Magic Literals:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Use unexplained numbers or strings.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Comment-Dependent Code:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Rely on comments to explain unclear code.
                        </Text>
                      </div>
                      <div>
                        <Text strong style={{ color: '#111827' }}>Dead Code:</Text>
                        <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                          Leave commented-out or unused code.
                        </Text>
                      </div>
                    </Space>
                  </Card>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Dependency Injection */}
          <section id="dependency-injection" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <DeploymentUnitOutlined style={{ marginRight: '8px' }} />
                Dependency Injection (DI)
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Dependency Injection (DI) is a core principle in modern .NET development, enabling loose coupling,
                easier testing, and better maintainability.
              </Paragraph>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>DI Best Practices</Title>
              <Card style={{ marginBottom: '24px', borderRadius: '12px' }}>
                <Space direction="vertical" size="small">
                  <Text style={{ color: '#374151' }}>
                    • Register services, repositories, and interfaces in the DI container (usually in Program.cs or Startup.cs).
                  </Text>
                  <Text style={{ color: '#374151' }}>
                    • Use constructor injection for dependencies.
                  </Text>
                  <Text style={{ color: '#374151' }}>
                    • Prefer abstractions (interfaces) over concrete implementations.
                  </Text>
                  <Text style={{ color: '#374151' }}>
                    • Use appropriate service lifetimes.
                  </Text>
                </Space>
              </Card>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Service Lifetimes"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                        <div>
                          <Text strong style={{ color: '#0033A0' }}>AddScoped:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px', fontSize: '14px' }}>
                            One instance per request. Use for repositories and business logic services.
                          </Text>
                        </div>
                        <div>
                          <Text strong style={{ color: '#00A3E0' }}>AddTransient:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px', fontSize: '14px' }}>
                            New instance every time. Use for lightweight, stateless helpers.
                          </Text>
                        </div>
                        <div>
                          <Text strong style={{ color: '#00B894' }}>AddSingleton:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px', fontSize: '14px' }}>
                            Single instance for the app. Use for configuration, logging, or cache.
                          </Text>
                        </div>
                      </Space>
                    </Card>
                  </HoverCard>
                </Col>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Example Registration"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`// In Program.cs or Startup.cs
services.AddScoped<IUserRepository, UserRepository>();
services.AddTransient<IEmailSender, EmailSender>();
services.AddSingleton<ILogger, Logger>();`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Middleware */}
          <section id="middleware" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <SyncOutlined style={{ marginRight: '8px' }} />
                Middleware for Logging, Security, Health
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Use middleware for logging, security headers, and health checks to ensure robust application monitoring and security.
              </Paragraph>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #0033A0'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#0033A0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <BookOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>Logging Middleware</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Implement request logging with Serilog or NLog for comprehensive application monitoring.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00A3E0'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#00A3E0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <SyncOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>Security Headers</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Add security headers like HSTS, HTTPS redirection, and authentication middleware.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00B894'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#00B894',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <HeartOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>Health Checks</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Implement health check endpoints to monitor application and dependency health.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Example Middleware Configuration</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`app.UseMiddleware<RequestLoggingMiddleware>();
app.UseAuthentication();
app.UseAuthorization();
app.UseHealthChecks("/health");`}
                  language="csharp"
                />
              </Card>
            </ScrollReveal>
          </section>

          {/* Mapster Mapping */}
          <section id="mapster" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <DeploymentUnitOutlined style={{ marginRight: '8px' }} />
                Mapping Entities to DTOs with Mapster
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Use Mapster for efficient, type-safe mapping between entities and DTOs in Clean Architecture.
              </Paragraph>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>Installation</Title>
              <Card style={{ marginBottom: '24px', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`dotnet add package Mapster`}
                  language="bash"
                />
              </Card>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Entity and DTO Example"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`public class User
{
  public int Id { get; set; }
  public string Name { get; set; }
  public string Email { get; set; }
}

public class UserDto
{
  public int Id { get; set; }
  public string Name { get; set; }
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Mapping in Service"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`using Mapster;

public async Task<UserDto> GetUserByIdAsync(int id)
{
  var user = await _userRepository.GetByIdAsync(id);
  if (user == null) return null;
  return user.Adapt<UserDto>();
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Advanced Configuration</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`TypeAdapterConfig<User, UserDto>.NewConfig()
  .Map(dest => dest.Name, src => src.Name.ToUpper());`}
                  language="csharp"
                />
              </Card>
            </ScrollReveal>
          </section>

          {/* Example Flow */}
          <section id="example-flow" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <ApartmentOutlined style={{ marginRight: '8px' }} />
                Example Flow: Controller → Service (Use Case) → GenericRepository
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                In a typical Clean Architecture project, the flow for a request is: Controller receives the HTTP request and calls the appropriate service (use case). Service contains business logic and interacts with repositories. GenericRepository handles data access operations.
              </Paragraph>

              <Row gutter={[24, 24]}>
                <Col xs={24}>
                  <HoverCard>
                    <Card
                      title="Controller (WebApi Layer)"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
  private readonly IUserService _userService;
  public UsersController(IUserService userService)
    => _userService = userService;

  [HttpGet("{id}")]
  public async Task<IActionResult> GetUser(int id)
  {
    var user = await _userService.GetUserByIdAsync(id);
    if (user == null) return NotFound();
    return Ok(user);
  }
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card
                      title="Service (Application Layer)"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`public interface IUserService
{
  Task<UserDto> GetUserByIdAsync(int id);
}

public class UserService : IUserService
{
  private readonly IUserRepository _userRepository;
  public UserService(IUserRepository userRepository)
    => _userRepository = userRepository;

  public async Task<UserDto> GetUserByIdAsync(int id)
  {
    var user = await _userRepository.GetByIdAsync(id);
    if (user == null) return null;
    return user.Adapt<UserDto>();
  }
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24}>
                  <HoverCard>
                    <Card
                      title="Repository (Infrastructure Layer)"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`public class Repository<T> : IRepository<T> where T : class
{
  protected readonly DbContext _context;
  public Repository(DbContext context) => _context = context;

  public async Task<T> GetByIdAsync(int id)
    => await _context.Set<T>().FindAsync(id);
  public async Task<IEnumerable<T>> GetAllAsync()
    => await _context.Set<T>().ToListAsync();
  // ... other CRUD operations
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
              </Row>
            </ScrollReveal>
          </section>

          {/* Database Migration */}
          <section id="database-migration" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <SyncOutlined style={{ marginRight: '8px' }} />
                Database Migration: Code-First Approach
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Use Entity Framework Core for code-first migrations. Define your entity classes and DbContext in the Core and Infrastructure layers.
              </Paragraph>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>EF Core Tools Installation</Title>
              <Card style={{ marginBottom: '24px', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`dotnet add package Microsoft.EntityFrameworkCore.Design`}
                  language="bash"
                  title="Package Manager Command"
                  showCopyButton={true}
                />
              </Card>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Create Migration"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`dotnet ef migrations add InitialCreate \\
  --project src/Infrastructure \\
  --startup-project src/WebApi`}
                        language="bash"
                      />
                      <Text style={{ color: '#666666', marginTop: '12px', display: 'block' }}>
                        Add the EF Core tools package to your project first.
                      </Text>
                    </Card>
                  </HoverCard>
                </Col>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Apply Migrations"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`dotnet ef database update \\
  --project src/Infrastructure \\
  --startup-project src/WebApi`}
                        language="bash"
                      />
                      <Text style={{ color: '#666666', marginTop: '12px', display: 'block' }}>
                        Apply migrations to the database.
                      </Text>
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Migration Best Practices</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <Space direction="vertical" size="small">
                  <Text>• Store migration files in the Migrations/ folder under Infrastructure</Text>
                  <Text>• Use environment-based connection strings for different environments</Text>
                  <Text>• Run migrations as part of your CI/CD pipeline</Text>
                  <Text>• Keep your database schema in sync with your code</Text>
                </Space>
              </Card>
            </ScrollReveal>
          </section>

          {/* Repository Pattern */}
          <section id="repository-pattern" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <ApartmentOutlined style={{ marginRight: '8px' }} />
                Repository Pattern
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Define generic repository interfaces in Core for common CRUD operations. Implement repositories in Infrastructure for each entity or aggregate as needed.
              </Paragraph>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>Generic Repository Interface</Title>
              <Card style={{ marginBottom: '24px', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`// Core
public interface IRepository<T> where T : class
{
  Task<T> GetByIdAsync(int id);
  Task<IEnumerable<T>> GetAllAsync();
  Task AddAsync(T entity);
  void Update(T entity);
  void Delete(T entity);
}

// Example of a specific repository interface
public interface IUserRepository : IRepository<User>
{
  Task<User> GetByEmailAsync(string email);
}`}
                  language="csharp"
                  title="Repository Interfaces"
                  showLineNumbers={true}
                  showCopyButton={true}
                />
              </Card>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Generic Repository Implementation"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`// Infrastructure
public class Repository<T> : IRepository<T> where T : class
{
  protected readonly DbContext _context;
  public Repository(DbContext context) => _context = context;

  public async Task<T> GetByIdAsync(int id)
    => await _context.Set<T>().FindAsync(id);
  public async Task<IEnumerable<T>> GetAllAsync()
    => await _context.Set<T>().ToListAsync();
  public async Task AddAsync(T entity)
    => await _context.Set<T>().AddAsync(entity);
  public void Update(T entity)
    => _context.Set<T>().Update(entity);
  public void Delete(T entity)
    => _context.Set<T>().Remove(entity);
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Specific Repository Implementation"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`public class UserRepository : Repository<User>, IUserRepository
{
  public UserRepository(DbContext context) : base(context) { }

  public async Task<User> GetByEmailAsync(string email)
    => await _context.Set<User>()
      .FirstOrDefaultAsync(u => u.Email == email);
}`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Usage with Dependency Injection</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`// Register in DI container
services.AddScoped<IUserRepository, UserRepository>();

// Use in services
public class UserService : IUserService
{
  private readonly IUserRepository _userRepository;
  public UserService(IUserRepository userRepository)
    => _userRepository = userRepository;
}`}
                  language="csharp"
                />
              </Card>
            </ScrollReveal>
          </section>

          {/* Unit Testing */}
          <section id="unit-testing" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <CheckCircleOutlined style={{ marginRight: '8px' }} />
                Unit Testing (Moq & NUnit)
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Use NUnit for test framework and Moq for mocking dependencies to ensure robust, maintainable unit tests.
              </Paragraph>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px' }}>Test Example</Title>
              <Card style={{ marginBottom: '24px', borderRadius: '12px' }}>
                <CodeSnippet
                  code={`[Test]
public void GetUser_ReturnsUser()
{
  var mockRepo = new Mock<IUserRepository>();
  mockRepo.Setup(r => r.GetById(1)).Returns(new User { Id = 1 });
  var service = new UserService(mockRepo.Object);
  var result = service.GetUser(1);
  Assert.IsNotNull(result);
  Assert.AreEqual(1, result.Id);
}`}
                  language="csharp"
                  title="Unit Test Example"
                  showLineNumbers={true}
                  showWordWrapToggle={true}
                  showCopyButton={true}
                />
              </Card>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Test Structure"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                        <div>
                          <Text strong style={{ color: '#0033A0' }}>Arrange:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                            Set up test data and mocks
                          </Text>
                        </div>
                        <div>
                          <Text strong style={{ color: '#00A3E0' }}>Act:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                            Execute the method under test
                          </Text>
                        </div>
                        <div>
                          <Text strong style={{ color: '#00B894' }}>Assert:</Text>
                          <Text style={{ color: '#374151', display: 'block', marginTop: '4px' }}>
                            Verify the expected behavior
                          </Text>
                        </div>
                      </Space>
                    </Card>
                  </HoverCard>
                </Col>
                <Col xs={24} md={12}>
                  <HoverCard>
                    <Card
                      title="Mocking with Moq"
                      style={{ height: '100%', borderRadius: '12px' }}
                    >
                      <CodeSnippet
                        code={`// Setup mock behavior
var mockRepo = new Mock<IUserRepository>();
mockRepo.Setup(r => r.GetById(1))
  .ReturnsAsync(new User { Id = 1, Name = "John" });

// Setup for void methods
mockRepo.Setup(r => r.Update(It.IsAny<User>()))
  .Verifies();

// Verify method calls
mockRepo.Verify(r => r.GetById(1), Times.Once);`}
                        language="csharp"
                      />
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Testing Best Practices</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <Space direction="vertical" size="small">
                  <Text>• Test one thing at a time (Single Responsibility for tests)</Text>
                  <Text>• Use descriptive test names that explain what is being tested</Text>
                  <Text>• Test both happy path and edge cases</Text>
                  <Text>• Mock external dependencies, don't test them</Text>
                  <Text>• Keep tests fast and independent</Text>
                </Space>
              </Card>
            </ScrollReveal>
          </section>

          {/* Security Compliance */}
          <section id="security" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <SyncOutlined style={{ marginRight: '8px' }} />
                Security Compliance
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Implement security best practices to protect your application and data from common vulnerabilities.
              </Paragraph>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #0033A0'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#0033A0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <GlobalOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>HTTPS & Security Headers</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Always use HTTPS and implement security headers like HSTS, CSP, and X-Frame-Options.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00A3E0'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#00A3E0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <BookOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>Input Validation</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Validate and sanitize all inputs to prevent injection attacks and data corruption.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={8}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00B894'
                      }}
                      bodyStyle={{ padding: '32px' }}
                    >
                      <div style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '50%',
                        backgroundColor: '#00B894',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px auto'
                      }}>
                        <HeartOutlined style={{ fontSize: '32px', color: '#ffffff' }} />
                      </div>
                      <Title level={4} style={{ marginBottom: '16px' }}>Secrets Management</Title>
                      <Paragraph style={{ color: '#666666', lineHeight: '1.6' }}>
                        Store secrets securely using Azure Key Vault, AWS Secrets Manager, or similar services.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Security Checklist</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <Space direction="vertical" size="small">
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Use HTTPS by default</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Store secrets in secure vaults</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Validate and sanitize all inputs</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Use authentication and authorization middleware</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Keep dependencies up to date</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Implement proper error handling</Text>
                  <Text>• <CheckCircleOutlined style={{ color: '#16a34a', marginRight: '8px' }} />Use parameterized queries to prevent SQL injection</Text>
                </Space>
              </Card>
            </ScrollReveal>
          </section>

          {/* Performance Improvements */}
          <section id="performance" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                <DeploymentUnitOutlined style={{ marginRight: '8px' }} />
                Optional: Performance Improvements
              </Title>
              <Paragraph style={{ color: '#374151', marginBottom: '24px', fontSize: '16px' }}>
                Implement performance optimizations to ensure your application scales effectively and provides a good user experience.
              </Paragraph>

              <Row gutter={[24, 24]}>
                <Col xs={24} md={6}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #0033A0'
                      }}
                      bodyStyle={{ padding: '24px' }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        backgroundColor: '#0033A0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px auto'
                      }}>
                        <SyncOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                      </div>
                      <Title level={5} style={{ marginBottom: '12px' }}>Caching</Title>
                      <Paragraph style={{ color: '#666666', fontSize: '14px', lineHeight: '1.5' }}>
                        Use Redis or in-memory caching for frequently accessed data.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={6}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00A3E0'
                      }}
                      bodyStyle={{ padding: '24px' }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        backgroundColor: '#00A3E0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px auto'
                      }}>
                        <ApartmentOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                      </div>
                      <Title level={5} style={{ marginBottom: '12px' }}>Async/Await</Title>
                      <Paragraph style={{ color: '#666666', fontSize: '14px', lineHeight: '1.5' }}>
                        Use async/await for all I/O operations to avoid blocking threads.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={6}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #00B894'
                      }}
                      bodyStyle={{ padding: '24px' }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        backgroundColor: '#00B894',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px auto'
                      }}>
                        <GlobalOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                      </div>
                      <Title level={5} style={{ marginBottom: '12px' }}>Compression</Title>
                      <Paragraph style={{ color: '#666666', fontSize: '14px', lineHeight: '1.5' }}>
                        Enable response compression to reduce payload sizes.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>

                <Col xs={24} md={6}>
                  <HoverCard>
                    <Card
                      style={{
                        height: '100%',
                        textAlign: 'center',
                        borderRadius: '12px',
                        border: '2px solid #F39C12'
                      }}
                      bodyStyle={{ padding: '24px' }}
                    >
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        backgroundColor: '#F39C12',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 16px auto'
                      }}>
                        <BookOutlined style={{ fontSize: '24px', color: '#ffffff' }} />
                      </div>
                      <Title level={5} style={{ marginBottom: '12px' }}>Monitoring</Title>
                      <Paragraph style={{ color: '#666666', fontSize: '14px', lineHeight: '1.5' }}>
                        Profile and monitor with Application Insights or similar tools.
                      </Paragraph>
                    </Card>
                  </HoverCard>
                </Col>
              </Row>

              <Title level={3} style={{ color: '#111827', marginBottom: '16px', marginTop: '32px' }}>Performance Best Practices</Title>
              <Card style={{ backgroundColor: '#f9fafb', borderRadius: '12px' }}>
                <Space direction="vertical" size="small">
                  <Text>• Use Redis for caching (StackExchange.Redis)</Text>
                  <Text>• Use async/await for I/O operations</Text>
                  <Text>• Enable response compression</Text>
                  <Text>• Profile and monitor with Application Insights</Text>
                  <Text>• Implement proper indexing on database queries</Text>
                  <Text>• Use pagination for large data sets</Text>
                  <Text>• Consider using CDN for static assets</Text>
                </Space>
              </Card>
            </ScrollReveal>
          </section>

          {/* Quick Reference Links */}
          <section id="quick-reference-links" style={{ marginBottom: '48px' }}>
            <ScrollReveal>
              <Title level={2} style={{ color: '#111827', marginBottom: '24px' }}>
                📚 Quick Reference Links
              </Title>

              <Row gutter={[24, 24]}>
                <Col xs={24} sm={12} lg={6}>
                  <Link to="/coding-standard" style={{ textDecoration: 'none' }}>
                    <Card hoverable style={{ height: '100%', textAlign: 'center' }}>
                      <BookOutlined style={{ fontSize: '32px', color: '#3b82f6', marginBottom: '12px' }} />
                      <Title level={4} style={{ marginBottom: '8px' }}>Detailed Guide</Title>
                      <Text type="secondary">Complete coding standards</Text>
                    </Card>
                  </Link>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                  <a href="https://docs.fluentvalidation.net/" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
                    <Card hoverable style={{ height: '100%', textAlign: 'center' }}>
                      <CheckCircleOutlined style={{ fontSize: '32px', color: '#10b981', marginBottom: '12px' }} />
                      <Title level={4} style={{ marginBottom: '8px' }}>FluentValidation</Title>
                      <Text type="secondary">Official documentation</Text>
                    </Card>
                  </a>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                  <a href="https://github.com/jbogard/MediatR" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
                    <Card hoverable style={{ height: '100%', textAlign: 'center' }}>
                      <ApiOutlined style={{ fontSize: '32px', color: '#f59e0b', marginBottom: '12px' }} />
                      <Title level={4} style={{ marginBottom: '8px' }}>MediatR</Title>
                      <Text type="secondary">GitHub repository</Text>
                    </Card>
                  </a>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                  <a href="https://docs.microsoft.com/en-us/dotnet/architecture/modern-web-apps-azure/" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
                    <Card hoverable style={{ height: '100%', textAlign: 'center' }}>
                      <GlobalOutlined style={{ fontSize: '32px', color: '#8b5cf6', marginBottom: '12px' }} />
                      <Title level={4} style={{ marginBottom: '8px' }}>Clean Architecture</Title>
                      <Text type="secondary">Microsoft docs</Text>
                    </Card>
                  </a>
                </Col>
              </Row>

              <Card style={{ marginTop: '24px', backgroundColor: '#fef3c7', borderLeft: '4px solid #f59e0b' }}>
                <Title level={4} style={{ color: '#92400e', marginBottom: '12px' }}>
                  💡 Remember
                </Title>
                <Paragraph style={{ color: '#78350f', marginBottom: 0 }}>
                  Choose one approach per project and apply it consistently. When in doubt, refer to existing code patterns 
                  in your project and follow the established conventions.
                </Paragraph>
              </Card>
            </ScrollReveal>
          </section>
            </div>
          </Col>

          {/* Sidebar */}
          <Col xs={24} lg={6}>
            <div style={{ position: 'sticky', top: '96px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
              <TableOfContents contentRef={contentRef} />

              {/* Quick Links - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }} disableHover>
                <div>
                  <Title level={4} style={{ marginBottom: '16px', color: '#0033A0' }}>
                    <LinkOutlined style={{ marginRight: '8px' }} />
                    Quick Links
                  </Title>
                  <Space direction="vertical" style={{ width: '100%' }}>
                    <Link to="/dotnet-developer-guideline">
                      <Button type="text" icon={<BookOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        .NET Developer Guideline
                      </Button>
                    </Link>
                    <Link to="/coding-standard">
                      <Button type="text" icon={<CodeOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                        Coding Standard Guide
                      </Button>
                    </Link>
                    <Button type="text" icon={<GlobalOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://docs.microsoft.com/en-us/dotnet/architecture/modern-web-apps-azure/" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        Microsoft Architecture Docs
                      </a>
                    </Button>
                    <Button type="text" icon={<HeartOutlined />} style={{ width: '100%', textAlign: 'left' }}>
                      <a href="https://github.com/jasontaylordev/CleanArchitecture" target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                        Clean Architecture Template
                      </a>
                    </Button>
                  </Space>
                </div>
              </HoverCard>

              {/* Technology Stack - sticky and hoverable */}
              <HoverCard style={{ borderRadius: '12px' }}>
                <div>
                  <Title level={4}>Technology Stack</Title>
                  <Space wrap style={{ marginTop: '12px' }}>
                    <Tag color="geekblue">.NET 8.0</Tag>
                    <Tag color="geekblue">ASP.NET Core</Tag>
                    <Tag color="geekblue">Entity Framework</Tag>
                    <Tag color="geekblue">MediatR</Tag>
                    <Tag color="geekblue">FluentValidation</Tag>
                    <Tag color="geekblue">Clean Architecture</Tag>
                    <Tag color="geekblue">SOLID Principles</Tag>
                    <Tag color="geekblue">DDD</Tag>
                  </Space>
                </div>
              </HoverCard>
            </div>
          </Col>
        </Row>
      </div>
    </Layout>
    </PageTransition>
  );
};

export default CleanArchitecturePage;