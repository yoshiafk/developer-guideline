import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Row, Col, Card, Typography, Button, Space, Tag, Breadcrumb, Select, Input, Empty } from 'antd';
import { HomeOutlined, SearchOutlined, BookOutlined, TagOutlined, ArrowRightOutlined, FileTextOutlined, CodeOutlined } from '@ant-design/icons';
import Layout from '../components/Layout';
import PageTransition from '../components/PageTransition';
import ScrollReveal from '../components/ScrollReveal';
import PageHero from '../components/PageHero';
import FeatureCard from '../components/FeatureCard';
import ContentSection from '../components/ContentSection';
import { searchContent, getCategories, getSearchSuggestions, SearchResult } from '../utils/advancedSearch';

const { Title, Text, Paragraph } = Typography;
const { Option } = Select;
const { Search } = Input;

const SearchResultsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState<string>(searchParams.get('q') || '');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState<boolean>(false);

  // Initialize categories on component mount
  useEffect(() => {
    setCategories(getCategories());
  }, []);

  // Update suggestions as user types
  useEffect(() => {
    if (query.length > 1) {
      try {
        const newSuggestions = getSearchSuggestions(query);
        setSuggestions(newSuggestions);
        setShowSuggestions(newSuggestions.length > 0);
      } catch (error) {
        console.error('Failed to get suggestions:', error);
        setSuggestions([]);
        setShowSuggestions(false);
      }
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [query]);

  // Real search logic using the comprehensive search index
  useEffect(() => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      const results = searchContent(query, selectedCategory);
      setSearchResults(results);
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
    }
  }, [query, selectedCategory]);

  const handleSearch = (value: string) => {
    setQuery(value);
    setSearchParams({ q: value });
    setShowSuggestions(false);
  };

  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
  };

  const handleSuggestionClick = (suggestion: string) => {
    try {
      setQuery(suggestion);
      setSearchParams({ q: suggestion });
      setShowSuggestions(false);
      // Trigger search immediately
      const results = searchContent(suggestion, selectedCategory);
      setSearchResults(results);
    } catch (error) {
      console.error('Failed to search on suggestion click:', error);
      setSearchResults([]);
    }
  };

  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    setSearchParams({ q: value });
  };

  const highlightText = (text: string, terms: string[]) => {
    if (!terms || !terms.length) return text;
    let highlightedText = text;
    terms.forEach(term => {
      const regex = new RegExp(`(${term})`, 'gi');
      highlightedText = highlightedText.replace(regex, '<mark>$1</mark>');
    });
    return highlightedText;
  };

  return (
    <Layout>
      <PageTransition>
        {/* Modern Page Hero */}
        <PageHero
          title="Search Results"
          subtitle="Find documentation, guides, and best practices"
          breadcrumbs={[
            { label: 'Home', href: '/' },
            { label: 'Search Results' }
          ]}
        />

        {/* Search Controls Section */}
        <ContentSection 
          title="" 
          background="gray"
          className="search-controls-section"
        >
          <Row gutter={[16, 16]} align="middle" className="search-controls">
            <Col xs={24} sm={24} md={17} lg={18} xl={19}>
              <div className="search-input-container">
                <Search
                  placeholder="Search documentation, guides, and best practices..."
                  value={query}
                  onChange={handleSearchInputChange}
                  onSearch={handleSearch}
                  size="large"
                  enterButton={<SearchOutlined />}
                  onFocus={() => query.length > 1 && setShowSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                />
                {showSuggestions && suggestions.length > 0 && (
                  <div className="search-suggestions">
                    {suggestions.map((suggestion, index) => (
                      <div
                        key={index}
                        className="suggestion-item"
                        onMouseDown={() => handleSuggestionClick(suggestion)}
                      >
                        <SearchOutlined className="suggestion-icon" />
                        {suggestion}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Col>
            <Col xs={24} sm={24} md={7} lg={6} xl={5}>
              <Select
                value={selectedCategory}
                onChange={handleCategoryChange}
                size="large"
                style={{ width: '100%' }}
                placeholder="Filter by category"
              >
                {categories.map(cat => (
                  <Option key={cat} value={cat}>{cat}</Option>
                ))}
              </Select>
            </Col>
          </Row>
        </ContentSection>

        {/* Main Content */}
        <div className="page-container">
          <Row gutter={[32, 32]}>
            <Col xs={24} xl={19}>
              <ScrollReveal>
                {/* Search Summary */}
                {query && (
                  <ContentSection title="" background="white" className="search-summary">
                    <div className="search-results-summary">
                      <Title level={3} className="summary-title">
                        {searchResults.length > 0
                          ? `Found ${searchResults.length} result${searchResults.length === 1 ? '' : 's'} for "${query}"`
                          : `No results found for "${query}"`
                        }
                      </Title>
                      {selectedCategory !== 'All' && (
                        <Text type="secondary" className="category-filter">
                          in category: {selectedCategory}
                        </Text>
                      )}
                    </div>
                  </ContentSection>
                )}

                {/* Search Results */}
                {query && searchResults.length > 0 && (
                  <ContentSection title="" background="white" className="search-results">
                    <div className="results-container">
                      {searchResults.map((result, index) => (
                        <div key={result.id} className="search-result-card">
                          <div className="result-header">
                            <Link to={result.url} className="result-title-link">
                              <Title level={4} className="result-title">
                                <span dangerouslySetInnerHTML={{
                                  __html: highlightText(result.title, result.matchedTerms)
                                }} />
                              </Title>
                            </Link>
                            <div className="result-tags">
                              <Tag color="blue" className="category-tag">{result.category}</Tag>
                              {result.tags.slice(0, 3).map(tag => (
                                <Tag key={tag} icon={<TagOutlined />} className="content-tag">
                                  <span dangerouslySetInnerHTML={{
                                    __html: highlightText(tag, result.matchedTerms)
                                  }} />
                                </Tag>
                              ))}
                            </div>
                          </div>

                          <div className="result-content">
                            <Paragraph className="result-excerpt">
                              <span dangerouslySetInnerHTML={{
                                __html: highlightText(result.excerpt, result.matchedTerms)
                              }} />
                            </Paragraph>
                          </div>

                          <div className="result-footer">
                            <Text type="secondary" className="relevance-score">
                              Relevance: {Math.round(result.score)}%
                            </Text>
                            <Link to={result.url} className="read-more-link">
                              <Text className="read-more-text">
                                Read More <ArrowRightOutlined />
                              </Text>
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ContentSection>
                )}

                {/* No Results */}
                {query && searchResults.length === 0 && (
                  <ContentSection title="" background="white" className="no-results">
                    <div className="no-results-container">
                      <Empty 
                        image={Empty.PRESENTED_IMAGE_SIMPLE} 
                        description="No results found"
                        className="no-results-empty"
                      />
                    </div>
                  </ContentSection>
                )}
              </ScrollReveal>
            </Col>

            {/* Sidebar */}
            <Col xs={24} xl={5}>
              <div className="search-sidebar">
                {/* Quick Links */}
                <FeatureCard
                  icon={<BookOutlined />}
                  title="Quick Links"
                  description="Access our main developer guides and documentation"
                  hoverable={false}
                />
                <div className="quick-links-list">
                  <Link to="/clean-architecture" className="modern-link-card">
                    <div className="link-card-content">
                      <CodeOutlined className="link-icon" />
                      <span className="link-text">Clean Architecture Standards</span>
                      <ArrowRightOutlined className="link-arrow" />
                    </div>
                  </Link>
                  <Link to="/coding-standard" className="modern-link-card">
                    <div className="link-card-content">
                      <FileTextOutlined className="link-icon" />
                      <span className="link-text">Coding Standard Guide</span>
                      <ArrowRightOutlined className="link-arrow" />
                    </div>
                  </Link>
                  <Link to="/dotnet-developer-guideline" className="modern-link-card">
                    <div className="link-card-content">
                      <CodeOutlined className="link-icon" />
                      <span className="link-text">.NET Developer Guideline</span>
                      <ArrowRightOutlined className="link-arrow" />
                    </div>
                  </Link>
                </div>

                {/* Technology Stack */}
                <FeatureCard
                  icon={<CodeOutlined />}
                  title="Technology Stack"
                  description="Technologies and frameworks we use in our development process"
                  hoverable={false}
                />
                <div className="tech-stack-grid">
                  <Tag color="blue" className="tech-tag">.NET 8.0</Tag>
                  <Tag color="blue" className="tech-tag">C# 12</Tag>
                  <Tag color="blue" className="tech-tag">Entity Framework</Tag>
                  <Tag color="blue" className="tech-tag">FluentValidation</Tag>
                  <Tag color="blue" className="tech-tag">MediatR</Tag>
                  <Tag color="blue" className="tech-tag">Clean Architecture</Tag>
                  <Tag color="blue" className="tech-tag">DDD</Tag>
                  <Tag color="blue" className="tech-tag">PostgreSQL</Tag>
                </div>
              </div>
            </Col>
          </Row>
        </div>
      </PageTransition>
    </Layout>
  );
};

export default SearchResultsPage;

