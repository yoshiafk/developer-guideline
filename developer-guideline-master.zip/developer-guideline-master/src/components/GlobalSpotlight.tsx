import React, { useEffect, useRef } from 'react';

/**
 * GlobalSpotlight
 * A small, performant spotlight effect that follows the mouse cursor.
 * - Desktop-only (pointer: fine)
 * - Respects prefers-reduced-motion
 * - Uses requestAnimationFrame + lerp for smooth movement
 */
const isDesktop = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(pointer: fine)').matches;
const prefersReducedMotion = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const lerp = (a: number, b: number, n = 0.18) => (1 - n) * a + n * b;

const GlobalSpotlight: React.FC = () => {
  const elRef = useRef<HTMLDivElement | null>(null);
  const target = useRef({ x: -100, y: -100 });
  const current = useRef({ x: -100, y: -100 });
  const visibleRef = useRef(false);
  const rafRef = useRef<number | null>(null);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => {
    if (!isDesktop() || prefersReducedMotion()) return;

    const el = elRef.current!;

    const onMove = (e: MouseEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;

      // show
      if (!visibleRef.current) {
        visibleRef.current = true;
        el.style.opacity = '1';
      }

      // reset fadeout timer
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
      timeoutRef.current = window.setTimeout(() => {
        visibleRef.current = false;
        el.style.opacity = '0';
      }, 800);
    };

    const animate = () => {
      const dx = target.current.x - current.current.x;
      const dy = target.current.y - current.current.y;
      const dist = Math.hypot(dx, dy);

      // dynamic smoothing: increase interpolation when pointer moves fast/large distance
      let t = 0.18; // default (smooth)
      if (dist > 160) t = 0.9; // almost snap to pointer on very fast moves
      else if (dist > 80) t = 0.5; // quicker catch-up
      else if (dist > 32) t = 0.28; // slightly faster for small moves

      current.current.x = lerp(current.current.x, target.current.x, t);
      current.current.y = lerp(current.current.y, target.current.y, t);

      el.style.setProperty('--gs-x', `${current.current.x}px`);
      el.style.setProperty('--gs-y', `${current.current.y}px`);
      rafRef.current = requestAnimationFrame(animate);
    };

    document.addEventListener('mousemove', onMove);
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener('mousemove', onMove);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    };
  }, []);

  return (
    <div
      aria-hidden
      ref={elRef}
      className="global-spotlight"
      style={{ opacity: 0, pointerEvents: 'none' }}
    />
  );
};

export default GlobalSpotlight;
