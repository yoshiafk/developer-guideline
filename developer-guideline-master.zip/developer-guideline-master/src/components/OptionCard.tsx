import React from 'react';
import { Card, Typography } from 'antd';
import { motion } from 'framer-motion';
import CodeSnippet from './CodeSnippet';

const { Title, Text } = Typography;

interface OptionCardProps {
  optionNumber: number;
  title: string;
  code: string;
  codeLanguage?: string;
  useWhen: string[];
  compact?: boolean;
}

const OptionCard: React.FC<OptionCardProps> = ({
  optionNumber,
  title,
  code,
  codeLanguage = 'csharp',
  useWhen,
  compact = false
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.4, delay: optionNumber * 0.1 }}
      whileHover={{ y: -4 }}
      style={{ height: '100%' }}
    >
      <Card
        className="option-card"
        bordered={false}
        style={{
          height: '100%',
          borderRadius: '12px',
          border: '1px solid var(--neutral-200)',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
          transition: 'all 0.3s ease',
          position: 'relative'
        }}
      >
        {/* Option badge */}
        <div
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'var(--neutral-500)',
            color: '#ffffff',
            padding: '2px 8px',
            borderRadius: '8px',
            fontSize: '11px',
            fontWeight: 600
          }}
        >
          #{optionNumber}
        </div>

        <Title 
          level={4} 
          style={{ 
            marginBottom: '16px',
            paddingRight: '40px',
            fontSize: compact ? '16px' : '18px'
          }}
        >
          {title}
        </Title>

        <div style={{ marginBottom: '12px' }}>
          <CodeSnippet
            code={code}
            language={codeLanguage}
            showLineNumbers={false}
          />
        </div>

        <div style={{ 
          marginTop: '12px',
          padding: '12px',
          background: 'var(--neutral-50)',
          borderRadius: '8px',
          borderLeft: '3px solid var(--axa-blue-light)'
        }}>
          <Text strong style={{ display: 'block', marginBottom: '6px', fontSize: '13px' }}>
            ✓ Use when:
          </Text>
          <ul style={{ 
            margin: 0, 
            paddingLeft: '18px',
            color: 'var(--neutral-600)',
            fontSize: compact ? '13px' : '14px'
          }}>
            {useWhen.map((item, index) => (
              <li key={index} style={{ marginBottom: '2px' }}>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </Card>
    </motion.div>
  );
};

export default OptionCard;
