import React from 'react';
import { Link } from 'react-router-dom';
import { GithubOutlined, CodeOutlined } from '@ant-design/icons';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Main Footer Content */}
        <div className="footer-content">
          {/* Brand Section */}
          <div className="footer-section footer-brand">
            <div className="footer-logo">
              <CodeOutlined style={{ fontSize: '20px', color: 'var(--axa-blue-primary)' }} />
              <span className="footer-logo-text">AII Developer Guidelines</span>
            </div>
            <p className="footer-description">
              Modern .NET development standards following Clean Architecture principles.
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-section">
            <h4 className="footer-heading">Documentation</h4>
            <ul className="footer-links">
              <li>
                <Link to="/" className="footer-link">Home</Link>
              </li>
              <li>
                <Link to="/clean-architecture" className="footer-link">Clean Architecture</Link>
              </li>
              <li>
                <Link to="/coding-standard" className="footer-link">Coding Standards</Link>
              </li>
              <li>
                <Link to="/dotnet-developer-guideline" className="footer-link">.NET Developer Guideline</Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="footer-section">
            <h4 className="footer-heading">Resources</h4>
            <ul className="footer-links">
              <li>
                <Link to="/github-axa-usage" className="footer-link">GitHub AII Usage Standards</Link>
              </li>
              <li>
                <Link to="/clean-architecture" className="footer-link">Design Patterns</Link>
              </li>
              <li>
                <Link to="/coding-standard" className="footer-link">Code Examples</Link>
              </li>
              <li>
                <Link to="/dotnet-developer-guideline" className="footer-link">Best Practices</Link>
              </li>
            </ul>
          </div>

          {/* Connect */}
          <div className="footer-section">
            <h4 className="footer-heading">Connect</h4>
            <div className="footer-social">
              <a
                href="https://github.axa.com/aii"
                target="_blank"
                rel="noopener noreferrer"
                className="footer-social-link"
                aria-label="AII GitHub Organization"
              >
                <GithubOutlined />
              </a>
            </div>
            <p className="footer-version">Version 2.0</p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="footer-bottom">
          <p className="footer-copyright">
            © {currentYear} AII Developer Guidelines. All rights reserved.
          </p>
          <div className="footer-bottom-links">
            <a href="#privacy" className="footer-bottom-link">Privacy</a>
            <span className="footer-divider">•</span>
            <a href="#terms" className="footer-bottom-link">Terms</a>
            <span className="footer-divider">•</span>
            <a href="#accessibility" className="footer-bottom-link">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
