import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Tooltip } from 'antd';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOutlined,
  CodeOutlined,
  FileTextOutlined,
  GithubOutlined,
  HomeOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  AppstoreOutlined,
  BranchesOutlined,
  ExperimentOutlined,
  RocketOutlined
} from '@ant-design/icons';

interface NavItem {
  key: string;
  label: string;
  path: string;
  icon: React.ReactNode;
  badge?: string;
  children?: NavItem[];
}

const navigationItems: NavItem[] = [
  {
    key: 'home',
    label: 'Home',
    path: '/',
    icon: <HomeOutlined />,
  },
  {
    key: 'guides',
    label: 'Developer Guides',
    path: '#',
    icon: <BookOutlined />,
    children: [
      {
        key: 'dotnet-developer-guideline',
        label: '.NET Developer Guide',
        path: '/dotnet-developer-guideline',
        icon: <CodeOutlined />,
      },
      {
        key: 'clean-architecture',
        label: 'Clean Architecture',
        path: '/clean-architecture',
        icon: <AppstoreOutlined />,
      },
      {
        key: 'coding-standard',
        label: 'Coding Standards',
        path: '/coding-standard',
        icon: <ExperimentOutlined />,
      },
      {
        key: 'github-axa-usage',
        label: 'GitHub Workflow',
        path: '/github-axa-usage',
        icon: <BranchesOutlined />,
      },
    ],
  },
];

interface SidebarProps {
  className?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ className = '' }) => {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [expandedKeys, setExpandedKeys] = useState<string[]>(['guides']);

  // Save collapsed state to localStorage
  useEffect(() => {
    const savedState = localStorage.getItem('sidebar-collapsed');
    if (savedState !== null) {
      setCollapsed(savedState === 'true');
    }
  }, []);

  // Auto-collapse on scroll
  useEffect(() => {
    let scrollTimeout: number | null = null;
    const handleScroll = () => {
      if (!collapsed) {
        if (scrollTimeout) clearTimeout(scrollTimeout);
        scrollTimeout = window.setTimeout(() => {
          setCollapsed(true);
          localStorage.setItem('sidebar-collapsed', 'true');
        }, 100); // faster collapse delay
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeout) clearTimeout(scrollTimeout);
    };
  }, [collapsed]);

  const handleToggle = () => {
    const newState = !collapsed;
    setCollapsed(newState);
    localStorage.setItem('sidebar-collapsed', newState.toString());
  };

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname === path;
  };

  const isParentActive = (item: NavItem) => {
    if (!item.children) return false;
    return item.children.some((child) => isActive(child.path));
  };

  const toggleExpanded = (key: string) => {
    setExpandedKeys((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const renderNavItem = (item: NavItem, level: number = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedKeys.includes(item.key);
    const active = isActive(item.path);
    const parentActive = isParentActive(item);

    if (hasChildren) {
      const buttonContent = (
        <motion.button
          className={`nav-item nav-parent ${parentActive ? 'active' : ''}`}
          onClick={() => !collapsed && toggleExpanded(item.key)}
          whileHover={{ x: collapsed ? 0 : 2 }}
          whileTap={{ scale: 0.98 }}
          style={{
            display: 'flex',
            alignItems: 'center',
            width: '100%',
            padding: '12px 16px',
            background: parentActive ? '#EFF6FF' : 'transparent',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            margin: '2px 0',
            transition: 'all 0.2s ease',
            position: 'relative',
            color: parentActive ? '#00008F' : '#4B5563'
          }}
        >
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            width: '100%',
            fontSize: '16px'
          }}>
            <span style={{ marginRight: collapsed ? 0 : '12px' }}>
              {item.icon}
            </span>
            
            {!collapsed && (
              <>
                <span style={{ 
                  flex: 1, 
                  textAlign: 'left', 
                  fontSize: '14px',
                  fontWeight: parentActive ? 600 : 500
                }}>
                  {item.label}
                </span>
                <span style={{
                  fontSize: '12px',
                  transform: `rotate(${isExpanded ? 90 : 0}deg)`,
                  transition: 'transform 0.2s ease',
                  opacity: 0.6
                }}>
                  ▶
                </span>
              </>
            )}
          </div>
          
          {parentActive && (
            <div style={{
              position: 'absolute',
              left: 0,
              top: 0,
              bottom: 0,
              width: '3px',
              background: '#00008F',
              borderRadius: '0 2px 2px 0'
            }} />
          )}
        </motion.button>
      );

      return (
        <div key={item.key} style={{ marginBottom: '4px' }}>
          {collapsed ? (
            <Tooltip 
              title={item.label} 
              placement="right"
              overlayStyle={{ fontSize: '12px' }}
            >
              {buttonContent}
            </Tooltip>
          ) : (
            buttonContent
          )}
          
          <AnimatePresence>
            {!collapsed && isExpanded && item.children && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0 }}
                style={{ paddingLeft: '16px', marginTop: '4px' }}
              >
                {item.children.map((child) => (
                  <div key={child.key}>
                    {renderNavItem(child, level + 1)}
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      );
    }

    const linkContent = (
      <motion.div
        whileHover={{ x: collapsed ? 0 : 2 }}
        whileTap={{ scale: 0.98 }}
      >
        <Link
          to={item.path}
          style={{
            display: 'flex',
            alignItems: 'center',
            padding: level > 0 ? '10px 12px' : '12px 16px',
            background: active ? '#EFF6FF' : 'transparent',
            borderRadius: '8px',
            textDecoration: 'none',
            margin: '2px 0',
            transition: 'all 0.2s ease',
            position: 'relative',
            color: active ? '#00008F' : '#4B5563'
          }}
          onMouseEnter={(e) => {
            if (!active) {
              e.currentTarget.style.background = '#F9FAFB';
              e.currentTarget.style.color = '#00008F';
            }
          }}
          onMouseLeave={(e) => {
            if (!active) {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = '#4B5563';
            }
          }}
        >
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            width: '100%',
            fontSize: level > 0 ? '14px' : '16px'
          }}>
            {item.icon && (
              <span style={{ marginRight: collapsed ? 0 : '12px' }}>
                {item.icon}
              </span>
            )}
            
            {!collapsed && (
              <div style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
                <span style={{ 
                  fontSize: level > 0 ? '13px' : '14px',
                  fontWeight: active ? 600 : 500
                }}>
                  {item.label}
                </span>
                {item.badge && (
                  <span style={{
                    marginLeft: '8px',
                    padding: '2px 6px',
                    background: '#00008F',
                    color: 'white',
                    fontSize: '10px',
                    borderRadius: '10px',
                    fontWeight: 500
                  }}>
                    {item.badge}
                  </span>
                )}
              </div>
            )}
          </div>
          
          {active && (
            <div style={{
              position: 'absolute',
              left: 0,
              top: 0,
              bottom: 0,
              width: '3px',
              background: '#00008F',
              borderRadius: '0 2px 2px 0'
            }} />
          )}
        </Link>
      </motion.div>
    );

    return collapsed ? (
      <Tooltip 
        key={item.key} 
        title={
          <div>
            <div>{item.label}</div>
            {item.badge && (
              <div style={{ fontSize: '10px', opacity: 0.8 }}>{item.badge}</div>
            )}
          </div>
        } 
        placement="right"
        overlayStyle={{ fontSize: '12px' }}
      >
        {linkContent}
      </Tooltip>
    ) : (
      <div key={item.key}>{linkContent}</div>
    );
  };

  const [bottomOffset, setBottomOffset] = useState(0);

  useEffect(() => {
    const footer = document.querySelector('footer');
    if (!footer) return;

    const onScroll = () => {
      const rect = footer.getBoundingClientRect();
      if (rect.top < window.innerHeight) {
        const overlap = Math.max(0, window.innerHeight - rect.top);
        setBottomOffset(overlap);
      } else {
        setBottomOffset(0);
      }
    };

    // run initially and on scroll/resize
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  // Show a backdrop on small screens when sidebar is open; clicking it will close the sidebar
  const [isMobile, setIsMobile] = useState<boolean>(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onResize = () => setIsMobile(window.innerWidth < 768);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return (
    <>
      {!collapsed && isMobile && (
        <div
          className="sidebar-overlay"
          role="button"
          aria-label="Close sidebar"
          tabIndex={0}
          onClick={() => {
            setCollapsed(true);
            localStorage.setItem('sidebar-collapsed', 'true');
          }}
          onKeyDown={(e) => {
            if ((e as React.KeyboardEvent<HTMLDivElement>).key === 'Escape') {
              setCollapsed(true);
              localStorage.setItem('sidebar-collapsed', 'true');
            }
          }}
        />
      )}

    <motion.aside 
      style={{
        width: collapsed ? 72 : 280,
        background: 'rgba(255, 255, 255, 0.94)',
        borderRight: '1px solid rgba(229,231,235,0.9)',
        position: 'fixed',
        top: 'var(--header-height)',
        bottom: `${bottomOffset}px`,
        zIndex: 1002,
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '2px 0 8px rgba(0, 0, 0, 0.04)'
      }}
      animate={{ width: collapsed ? 72 : 280 }}
      transition={{ duration: 0 }}
      className={`modern-sidebar ${collapsed ? 'collapsed' : 'expanded'} ${className}`}
      aria-hidden={false}
      aria-expanded={!collapsed}
    >
      {/* Header */}
      <div style={{
        padding: '16px',
        borderBottom: '1px solid #F3F4F6',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '64px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{
            width: '32px',
            height: '32px',
            background: 'linear-gradient(135deg, #00008F 0%, #0033A0 100%)',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: '16px',
            marginRight: collapsed ? 0 : '12px'
          }}>
            <RocketOutlined />
          </div>
          
          {!collapsed && (
            <div>
              <div style={{ 
                fontSize: '16px', 
                fontWeight: 700, 
                color: '#00008F',
                lineHeight: 1.2
              }}>
                AII Dev Guide
              </div>
              <div style={{ 
                fontSize: '11px', 
                color: '#9CA3AF',
                lineHeight: 1
              }}>
                Version 2.0
              </div>
            </div>
          )}
        </div>

        <motion.button
          onClick={handleToggle}
          className="sidebar-toggle"
          style={{
            width: '32px',
            height: '32px',
            border: 'none',
            background: '#F3F4F6',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: '#6B7280',
            fontSize: '14px',
            zIndex: 1003, /* ensure button can layer above header */
          }}
          whileHover={{ 
            background: '#E5E7EB',
            scale: 1.05 
          }}
          whileTap={{ scale: 0.95 }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#E5E7EB';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = '#F3F4F6';
          }}
        >
          {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
        </motion.button>
      </div>

      {/* Navigation */}
      <div style={{
        flex: 1,
        padding: '16px',
        overflowY: 'auto'
      }}>
        {!collapsed && (
          <div style={{
            fontSize: '11px',
            fontWeight: 600,
            color: '#9CA3AF',
            textTransform: 'uppercase',
            letterSpacing: '0.5px',
            marginBottom: '12px',
            paddingLeft: '4px'
          }}>
            Navigation
          </div>
        )}

        <div>
          {navigationItems.map((item) => (
            <div key={item.key}>
              {renderNavItem(item)}
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div style={{
        padding: '16px',
        borderTop: '1px solid #F3F4F6'
      }}>
        {!collapsed ? (
          <div style={{
            background: 'linear-gradient(135deg, #F9FAFB 0%, #F3F4F6 100%)',
            padding: '12px',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <div style={{
              fontSize: '12px',
              fontWeight: 600,
              color: '#00008F',
              marginBottom: '4px'
            }}>
              AXA Developer Guidelines
            </div>
            <div style={{
              fontSize: '10px',
              color: '#6B7280'
            }}>
              Built with ❤️ for developers
            </div>
          </div>
        ) : (
          <Tooltip title="AXA Developer Guidelines v2.0" placement="right">
            <div style={{
              width: '40px',
              height: '40px',
              background: 'linear-gradient(135deg, #00008F 0%, #0033A0 100%)',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '16px',
              margin: '0 auto'
            }}>
              ❤️
            </div>
          </Tooltip>
        )}
      </div>
    </motion.aside>
    </>
  );
};

export default Sidebar;
