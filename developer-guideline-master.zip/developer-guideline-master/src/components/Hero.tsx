import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Space } from 'antd';
import { RocketOutlined, BookOutlined } from '@ant-design/icons';

const Hero: React.FC = () => {
  return (
    <section className="hero hero-gradient">
      <div className="hero-container">
        <div className="hero-content">
          <h1 className="hero-title">
            AII Developer Guidelines
          </h1>
          <p className="hero-subtitle">
            Modern .NET development standards following Clean Architecture principles
          </p>
          <Space size="middle" className="hero-actions">
            <Link to="/clean-architecture">
              <Button
                type="primary"
                size="large"
                icon={<RocketOutlined />}
                className="hero-button-primary"
              >
                Get Started
              </Button>
            </Link>
            <Link to="/dotnet-developer-guideline">
              <Button
                size="large"
                icon={<BookOutlined />}
                className="hero-button-secondary"
              >
                View Docs
              </Button>
            </Link>
          </Space>
        </div>
      </div>
    </section>
  );
};

export default Hero;