import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Breadcrumb, Input } from 'antd';
import { SearchOutlined } from '@ant-design/icons';

const { Search } = Input;

interface PageHeroProps {
  title: string;
  subtitle?: string;
  breadcrumbs?: Array<{ label: string; href?: string }>;
  showSearch?: boolean;
  compact?: boolean; // New: for even more compact version
}

const PageHero: React.FC<PageHeroProps> = ({ 
  title, 
  subtitle, 
  breadcrumbs = [], 
  showSearch = false,
  compact = false 
}) => {
  const navigate = useNavigate();

  const handleSearch = (value: string) => {
    if (!value.trim()) {
      return;
    }
    navigate(`/search?q=${encodeURIComponent(value)}`);
  };

  const breadcrumbItems = breadcrumbs.map((crumb, index) => ({
    title: crumb.href ? (
      <Link to={crumb.href} style={{ color: 'rgba(255, 255, 255, 0.9)' }}>
        {crumb.label}
      </Link>
    ) : (
      <span style={{ color: 'rgba(255, 255, 255, 0.7)' }}>{crumb.label}</span>
    ),
    key: index
  }));

  return (
    <section 
      className="page-hero hero-gradient"
      style={{
        padding: compact ? '40px 0 32px' : '60px 0 48px'
      }}
    >
      <div className="page-hero-container">
        {/* Breadcrumbs */}
        {breadcrumbs.length > 0 && (
          <div className="page-hero-breadcrumbs">
            <Breadcrumb items={breadcrumbItems} separator="›" />
          </div>
        )}

        {/* Main Content */}
        <div className="page-hero-content">
          <h1 className="page-hero-title">{title}</h1>
          
          {subtitle && (
            <p className="page-hero-subtitle">{subtitle}</p>
          )}

          {/* Optional Search Bar */}
          {showSearch && (
            <div className="page-hero-search">
              <Search
                placeholder="Search this guide..."
                size="large"
                onSearch={handleSearch}
                prefix={<SearchOutlined />}
                className="page-hero-search-input"
              />
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default PageHero;