import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Layout, Menu, Input, Button, Drawer } from 'antd';
import { CodeOutlined, MenuOutlined, SearchOutlined } from '@ant-design/icons';
import ThemeToggle from './ThemeToggle';
import SearchBox from './SearchBox';

const { Header: AntHeader } = Layout;
const { Search } = Input;

const Header: React.FC = () => {
  const [mobileMenuVisible, setMobileMenuVisible] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleSearch = (value: string) => {
    if (!value.trim()) {
      return;
    }
    navigate(`/search?q=${encodeURIComponent(value)}`);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('.header-search input') as HTMLInputElement;
        if (searchInput) {
          searchInput.focus();
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    setMobileMenuVisible(false);
  }, [location]);

  const menuItems = [
    { key: 'home', label: <Link to="/">Home</Link> },
    {
      key: 'dev-guides',
      label: 'Developer Guides',
      children: [
        { key: 'dotnet-developer-guideline', label: <Link to="/dotnet-developer-guideline">.NET Developer Guide</Link> },
        { key: 'clean-architecture', label: <Link to="/clean-architecture">Clean Architecture</Link> },
        { key: 'coding-standard', label: <Link to="/coding-standard">Coding Standards</Link> },
        { key: 'github-axa-usage', label: <Link to="/github-axa-usage">GitHub Guide</Link> },
      ]
    }
  ];

  const mobileMenuItems = [
    { key: 'home', label: <Link to="/" onClick={() => setMobileMenuVisible(false)}>Home</Link> },
    { key: 'clean-architecture', label: <Link to="/clean-architecture" onClick={() => setMobileMenuVisible(false)}>Clean Architecture Standards</Link> },
    { key: 'coding-standard', label: <Link to="/coding-standard" onClick={() => setMobileMenuVisible(false)}>Coding Standard Guide</Link> },
    { key: 'dotnet-developer-guideline', label: <Link to="/dotnet-developer-guideline" onClick={() => setMobileMenuVisible(false)}>.NET Developer Guideline</Link> },
    { key: 'github-axa-usage', label: <Link to="/github-axa-usage" onClick={() => setMobileMenuVisible(false)}>GitHub AXA Usage Guidelines</Link> },
  ];

  const getCurrentKey = () => {
    if (location.pathname === '/') return 'home';
    return location.pathname.substring(1);
  };

  return (
    <>
      <AntHeader
        style={{
          background: '#FFFFFF',
          boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)',
          padding: '0 24px',
          position: 'sticky',
          top: 0,
          zIndex: 1000,
          height: '64px',
          lineHeight: '64px',
          borderBottom: '1px solid #E5E7EB',
        }}
      >
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          maxWidth: '1280px', 
          margin: '0 auto', 
          height: '64px',
          width: '100%'
        }}>
          {/* Left: Logo */}
          <div style={{ flex: '0 0 auto' }}>
            <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '12px', textDecoration: 'none' }}>
              <CodeOutlined style={{ fontSize: '20px', color: '#00008F' }} />
              <span style={{ fontSize: '16px', fontWeight: 600, color: '#00008F', whiteSpace: 'nowrap' }}>AII Developer Guidelines</span>
            </Link>
          </div>

          {/* Center: Navigation Menu */}
          <div style={{ flex: '1 1 auto', display: 'flex', justifyContent: 'center' }}>
            <Menu 
              mode="horizontal" 
              selectedKeys={[getCurrentKey()]} 
              items={menuItems} 
              style={{ 
                border: 'none', 
                background: 'transparent', 
                fontSize: '14px', 
                fontWeight: '500', 
                minWidth: 'auto',
                justifyContent: 'center'
              }} 
              className="desktop-menu" 
            />
          </div>

          {/* Right: Search + Theme Toggle + Mobile Menu */}
          <div style={{ 
            flex: '0 0 auto', 
            display: 'flex', 
            alignItems: 'center', 
            gap: '16px' 
          }}>
            <div style={{ position: 'relative', minWidth: 140 }}>
              {/* New centered SearchBox component */}
              <SearchBox />
            </div>
            <ThemeToggle />
            <Button 
              type="text" 
              icon={<MenuOutlined />} 
              onClick={() => setMobileMenuVisible(true)} 
              style={{ color: '#00008F', display: 'none' }} 
              className="mobile-menu-button" 
            />
          </div>
        </div>
      </AntHeader>
      <Drawer title={<div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><CodeOutlined style={{ color: '#00008F' }} /><span style={{ color: '#00008F', fontWeight: 600 }}>AII Developer Guidelines</span></div>} placement="right" onClose={() => setMobileMenuVisible(false)} open={mobileMenuVisible} styles={{ body: { padding: 0 } }}>
        <div style={{ padding: '16px' }}>
          <Search placeholder="Search documentation..." onSearch={handleSearch} style={{ width: '100%', marginBottom: '16px' }} enterButton={<SearchOutlined />} />
          <Menu mode="vertical" selectedKeys={[getCurrentKey()]} items={mobileMenuItems} style={{ border: 'none' }} />
        </div>
      </Drawer>
    </>
  );
};

export default Header;
