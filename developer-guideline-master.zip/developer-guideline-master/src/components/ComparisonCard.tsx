import React from 'react';
import { Card, Typography } from 'antd';
import { motion } from 'framer-motion';
import CodeSnippet from './CodeSnippet';

const { Title, Text } = Typography;

interface ComparisonCardProps {
  optionNumber: number;
  title: string;
  code?: string;
  codeLanguage?: string;
  useWhen: string[];
  variant?: 'primary' | 'secondary';
}

const ComparisonCard: React.FC<ComparisonCardProps> = ({
  optionNumber,
  title,
  code,
  codeLanguage = 'text',
  useWhen,
  variant = 'primary'
}) => {
  const isPrimary = variant === 'primary';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -4 }}
      style={{ height: '100%' }}
    >
      <Card
        className="comparison-card"
        bordered={false}
        style={{
          height: '100%',
          borderRadius: '16px',
          border: isPrimary 
            ? '2px solid var(--axa-blue-primary)' 
            : '2px solid var(--axa-blue-secondary)',
          boxShadow: isPrimary
            ? '0 8px 24px rgba(0, 51, 160, 0.12)'
            : '0 8px 24px rgba(0, 51, 160, 0.08)',
          background: isPrimary
            ? 'linear-gradient(135deg, #ffffff 0%, #f0f7ff 100%)'
            : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        {/* Option badge */}
        <div
          style={{
            position: 'absolute',
            top: '16px',
            right: '16px',
            background: isPrimary 
              ? 'linear-gradient(135deg, var(--axa-blue-primary), var(--axa-blue-light))'
              : 'linear-gradient(135deg, var(--axa-blue-secondary), var(--axa-blue-primary))',
            color: '#ffffff',
            padding: '4px 12px',
            borderRadius: '12px',
            fontSize: '12px',
            fontWeight: 600,
            zIndex: 1
          }}
        >
          Option {optionNumber}
        </div>

        <div style={{ paddingTop: '8px' }}>
          <Title 
            level={3} 
            style={{ 
              marginBottom: '16px',
              paddingRight: '80px',
              color: isPrimary ? 'var(--axa-blue-primary)' : 'var(--axa-blue-secondary)'
            }}
          >
            {title}
          </Title>

          {code && (
            <div style={{ marginBottom: '16px' }}>
              <CodeSnippet
                code={code}
                language={codeLanguage}
                showLineNumbers={false}
              />
            </div>
          )}

          <div style={{ 
            marginTop: '16px',
            padding: '16px',
            background: isPrimary ? 'rgba(0, 51, 160, 0.04)' : 'rgba(0, 51, 160, 0.03)',
            borderRadius: '12px',
            borderLeft: `4px solid ${isPrimary ? 'var(--axa-blue-primary)' : 'var(--axa-blue-secondary)'}`
          }}>
            <Text strong style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
              ✓ Use when:
            </Text>
            <ul style={{ 
              margin: 0, 
              paddingLeft: '20px',
              color: 'var(--neutral-600)'
            }}>
              {useWhen.map((item, index) => (
                <li key={index} style={{ marginBottom: '4px' }}>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom accent */}
        <div style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: '4px',
          background: isPrimary 
            ? 'linear-gradient(90deg, var(--axa-blue-primary), var(--axa-blue-light))'
            : 'linear-gradient(90deg, var(--axa-blue-secondary), var(--axa-blue-primary))'
        }} />
      </Card>
    </motion.div>
  );
};

export default ComparisonCard;
