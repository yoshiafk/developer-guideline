import React from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';
import BackToTop from './BackToTop';
import GlobalSpotlight from './GlobalSpotlight';

interface LayoutProps {
  children: React.ReactNode;
  showSidebar?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, showSidebar = true }) => {
  const location = useLocation();
  
  // Show sidebar on all pages except homepage
  const shouldShowSidebar = showSidebar && location.pathname !== '/';

  return (
    <div className="site-container">
      <Header />
      <div style={{ display: 'flex', minHeight: 'calc(100vh - 64px)' }}>
        {shouldShowSidebar && <Sidebar />}
        <div 
          className="site-main-content"
          style={{ 
            flex: 1, 
            minWidth: 0, // Allows flex item to shrink below content size
            transition: 'margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
          }}
        >
          {children}
        </div>
      </div>
      <Footer />
      <BackToTop />
      <GlobalSpotlight />
    </div>
  );
};

export default Layout;