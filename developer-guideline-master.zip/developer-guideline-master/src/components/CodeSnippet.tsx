import React, { useState, useRef, useEffect, useCallback } from 'react';
import hljs from 'highlight.js/lib/core';
import { CopyOutlined, CheckOutlined, CodeOutlined, FontSizeOutlined } from '@ant-design/icons';
import { Button, Tooltip, Space, message } from 'antd';
import 'highlight.js/styles/github.css';
import 'highlight.js/styles/github-dark.css';

// Import specific languages
import csharp from 'highlight.js/lib/languages/csharp';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import sql from 'highlight.js/lib/languages/sql';
import bash from 'highlight.js/lib/languages/bash';
import json from 'highlight.js/lib/languages/json';
import xml from 'highlight.js/lib/languages/xml';

// Add responsive styles
const responsiveStyles = `
  .code-snippet-enhanced {
    margin: 20px 0;
  }
  .code-snippet-enhanced pre {
    overflow-x: auto;
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f8fafc;
  }
  .code-snippet-enhanced pre::-webkit-scrollbar {
    height: 8px;
  }
  .code-snippet-enhanced pre::-webkit-scrollbar-track {
    background: #f8fafc;
    border-radius: 4px;
  }
  .code-snippet-enhanced pre::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  .code-snippet-enhanced pre::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  @media (max-width: 768px) {
    .code-snippet-enhanced {
      margin: 16px 0;
    }
    .code-snippet-enhanced pre {
      padding: 16px !important;
      font-size: 13px !important;
      line-height: 1.5 !important;
    }
    .code-snippet-enhanced .code-snippet-header {
      padding: 12px 16px !important;
    }
  }
  @media (max-width: 480px) {
    .code-snippet-enhanced pre {
      padding: 12px !important;
      font-size: 12px !important;
    }
    .code-snippet-enhanced .code-snippet-header {
      padding: 10px 12px !important;
    }
  }
`;

// Inject styles
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = responsiveStyles;
  document.head.appendChild(styleSheet);
}

// Register languages
hljs.registerLanguage('csharp', csharp);
hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('typescript', typescript);
hljs.registerLanguage('sql', sql);
hljs.registerLanguage('bash', bash);
hljs.registerLanguage('json', json);
hljs.registerLanguage('xml', xml);

interface CodeSnippetProps {
  code: string;
  language?: string;
  showLineNumbers?: boolean;
  showCopyButton?: boolean;
  showWordWrapToggle?: boolean;
  className?: string;
  theme?: 'light' | 'dark' | 'auto';
  maxHeight?: string | number;
  title?: string;
}

const CodeSnippet: React.FC<CodeSnippetProps> = ({
  code,
  language = 'csharp',
  showLineNumbers = false,
  showCopyButton = true,
  showWordWrapToggle = false,
  className = '',
  theme = 'dark',
  maxHeight,
  title
}) => {
  const [highlightedCode, setHighlightedCode] = useState<string>('');
  const [copied, setCopied] = useState(false);
  // Determine if word wrap should be enabled by default for certain languages
  const shouldWrapByDefault = ['bash', 'shell', 'powershell', 'sql', 'csharp'].includes(language.toLowerCase());
  const [wordWrap, setWordWrap] = useState(shouldWrapByDefault);
  const [error, setError] = useState<string | null>(null);
  const codeRef = useRef<HTMLDivElement>(null);

  // Highlight code on mount and when code/language changes
  useEffect(() => {
    try {
      const result = hljs.highlight(code, { language: language });
      setHighlightedCode(result.value);
      setError(null);
    } catch (err) {
      console.error('Syntax highlighting error:', err);
      setError('Syntax highlighting failed');
      setHighlightedCode(code); // Fallback to plain text
    }
  }, [code, language]);

  // Copy to clipboard
  const copyToClipboard = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      message.success('Code copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = code;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        message.success('Code copied to clipboard!');
        setTimeout(() => setCopied(false), 2000);
      } catch (fallbackErr) {
        message.error('Failed to copy code');
      }
      document.body.removeChild(textArea);
    }
  }, [code]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'c' && document.activeElement === codeRef.current) {
          copyToClipboard();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [copyToClipboard]);

  const containerStyle: React.CSSProperties = {
    position: 'relative',
    margin: '20px 0',
    borderRadius: '8px', // Reduced from 16px for consistency
    overflow: 'hidden',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)', // Subtle shadow
    border: '1px solid #e5e7eb',
    backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
    maxWidth: '100%',
    width: '100%',
    boxSizing: 'border-box',
  };

  const headerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '12px 20px', // Reduced padding
    backgroundColor: theme === 'dark' ? '#111827' : '#f9fafb',
    borderBottom: '1px solid #e5e7eb',
  };

  const languageBadgeStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: '4px 10px', // More compact
    backgroundColor: theme === 'dark' ? '#374151' : '#e5e7eb',
    color: theme === 'dark' ? '#f3f4f6' : '#374151',
    borderRadius: '4px', // Reduced from 8px
    fontSize: '12px', // Smaller font
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
  };

  const codeContainerStyle: React.CSSProperties = {
    position: 'relative',
    maxHeight: maxHeight || 'none',
    overflow: maxHeight ? 'auto' : 'visible',
    maxWidth: '100%',
    width: '100%',
    boxSizing: 'border-box',
  };

  const preStyle: React.CSSProperties = {
    margin: 0,
    padding: '20px',
    paddingLeft: showLineNumbers ? '56px' : '20px',
    borderRadius: 0,
    fontSize: '14px',
    lineHeight: '1.6',
    overflow: 'visible', // Always visible to prevent horizontal scroll
    whiteSpace: wordWrap ? 'pre-wrap' : 'pre',
    wordBreak: wordWrap ? 'break-word' : 'normal',
    fontFamily: '"JetBrains Mono", "Fira Code", "Monaco", "Consolas", monospace',
    backgroundColor: 'transparent',
    scrollbarWidth: 'thin',
    scrollbarColor: theme === 'dark' ? '#4b5563 #1f2937' : '#d1d5db #f9fafb',
    maxWidth: '100%',
    width: '100%',
    boxSizing: 'border-box',
    display: 'block',
  };

  const codeStyle: React.CSSProperties = {
    fontSize: '14px',
    lineHeight: '1.6',
    fontFamily: '"JetBrains Mono", "Fira Code", "Monaco", "Consolas", monospace',
    backgroundColor: 'transparent',
    whiteSpace: wordWrap ? 'pre-wrap' : 'pre',
    wordBreak: wordWrap ? 'break-word' : 'normal',
    overflowWrap: wordWrap ? 'break-word' : 'normal',
    maxWidth: '100%',
    width: '100%',
    display: 'block',
  };

  if (error) {
    return (
      <div style={containerStyle} className={className}>
        <div style={headerStyle}>
          <div style={languageBadgeStyle}>
            <CodeOutlined />
            {language}
          </div>
        </div>
        <div style={{ padding: '20px', color: '#dc2626', fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          Error: {error}
          <pre style={{ marginTop: '8px', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{code}</pre>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={codeRef}
      style={containerStyle}
      className={`code-snippet-enhanced ${className}`}
      tabIndex={0}
      role="region"
      aria-label={`Code snippet in ${language}`}
    >
      {/* Header */}
      <div style={headerStyle} className="code-snippet-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={languageBadgeStyle}>
            <CodeOutlined />
            {language}
          </div>
          {title && (
            <span style={{
              fontSize: '15px',
              fontWeight: '500',
              color: theme === 'dark' ? '#f3f4f6' : '#374151'
            }}>
              {title}
            </span>
          )}
        </div>

        <Space size="small">
          {showWordWrapToggle && (
            <Tooltip title={wordWrap ? 'Disable word wrap' : 'Enable word wrap'}>
              <Button
                type="text"
                size="small"
                icon={<FontSizeOutlined />}
                onClick={() => setWordWrap(!wordWrap)}
                style={{
                  color: wordWrap ? '#3b82f6' : (theme === 'dark' ? '#9ca3af' : '#6b7280')
                }}
              />
            </Tooltip>
          )}

          {showCopyButton && (
            <Tooltip title="Copy to clipboard (Ctrl+C)">
              <Button
                type="text"
                size="small"
                icon={copied ? <CheckOutlined /> : <CopyOutlined />}
                onClick={copyToClipboard}
                style={{
                  color: copied ? '#16a34a' : (theme === 'dark' ? '#9ca3af' : '#6b7280')
                }}
              />
            </Tooltip>
          )}
        </Space>
      </div>

      {/* Code Content */}
      <div style={codeContainerStyle}>
        <div style={{ position: 'relative', maxWidth: '100%', overflow: 'hidden', width: '100%', boxSizing: 'border-box' }}>
          {showLineNumbers && (
            <div style={{
              position: 'absolute',
              left: '20px',
              top: '20px',
              bottom: '20px',
              width: '36px',
              textAlign: 'right',
              userSelect: 'none',
              opacity: 0.5,
              fontSize: '13px',
              color: theme === 'dark' ? '#6b7280' : '#9ca3af',
              fontFamily: '"JetBrains Mono", "Fira Code", "Monaco", "Consolas", monospace',
              lineHeight: '1.6',
              zIndex: 1,
            }}>
              {code.split('\n').map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>
          )}
          <pre style={preStyle}>
            <code
              style={codeStyle}
              className={`hljs ${theme === 'dark' ? 'hljs-dark' : ''}`}
              dangerouslySetInnerHTML={{ __html: highlightedCode }}
            />
          </pre>
        </div>
      </div>
    </div>
  );
};

export default CodeSnippet;