import React from 'react';
import { BulbOutlined, BulbFilled } from '@ant-design/icons';
import { Button, Tooltip } from 'antd';
import { useTheme } from '../contexts/ThemeContext';

const ThemeToggle: React.FC = () => {
  const { isDark, toggleTheme } = useTheme();

  return (
    <Tooltip title={isDark ? 'Switch to light mode' : 'Switch to dark mode'} placement="bottom">
      <Button
        type="text"
        icon={isDark ? <BulbFilled style={{ color: '#FDB813' }} /> : <BulbOutlined />}
        onClick={toggleTheme}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '40px',
          height: '40px',
          borderRadius: '8px',
          transition: 'all 0.2s ease',
        }}
        aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      />
    </Tooltip>
  );
};

export default ThemeToggle;
